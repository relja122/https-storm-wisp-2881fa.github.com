'use strict';
/* ==================================================================
   STORM ROYALE — HUD, match flow, input
   ================================================================== */

let slotsDirty = true;
let slotRefs = [];
let flashTimer = null;
let muted = false;
let lockerTab = 'outfit';
let lockerBack = 'menu';
let shopBack = 'menu';
let shopTimer = null;
let bannerTimer = null;
let emotePreviewTimer = null;
let escHeld = false;
let escStart = 0;
let escTimer = null;
const LEAVE_HOLD_MS = 5000;
let emoteOpen = false;
let emoteSel = 0;
let emoteCards = [];

const hc = { hp: '', sh: '', alive: '', kills: '', wood: '', ammo: '', storm: '', poi: '', pots: '', meds: '', mag: '' };

/* ----------------------------- helpers --------------------------- */
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function toast(text, kind) {
  const el = document.createElement('div');
  el.className = 'toast ' + (kind || '');
  el.textContent = text;
  ui.toasts.appendChild(el);
  while (ui.toasts.children.length > 4) ui.toasts.firstChild.remove();
  setTimeout(() => {
    el.style.transition = 'opacity .45s ease, transform .45s ease';
    el.style.opacity = '0';
    el.style.transform = 'translateY(-14px)';
    setTimeout(() => el.remove(), 480);
  }, 1500);
}

function addFeed(a, b, mine) {
  const el = document.createElement('div');
  el.className = 'feed' + (mine ? ' mine' : '');
  el.innerHTML = '<b>' + escapeHtml(a) + '</b> <i>eliminated</i> <b>' + escapeHtml(b) + '</b>';
  ui.killfeed.prepend(el);
  while (ui.killfeed.children.length > 5) ui.killfeed.lastChild.remove();
  setTimeout(() => {
    el.style.transition = 'opacity .5s';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 520);
  }, 5200);
}

function flashDamage() {
  ui.vignette.style.opacity = '1';
  clearTimeout(flashTimer);
  flashTimer = setTimeout(() => { ui.vignette.style.opacity = '0'; }, 130);
}

function hitMarker() {
  game.hitT = 0.14;
}

/* --------------------------- interaction ------------------------- */
function findInteractable() {
  if (!player || !player.alive || game.state !== 'playing') return null;
  let best = null, bestD = 86;

  for (const ch of world.chests) {
    if (ch.opened) continue;
    const d = dist(player.x, player.y, ch.x, ch.y);
    if (d < bestD) { bestD = d; best = { type: 'chest', obj: ch, label: ch.isSupply ? 'Open Supply Drop' : 'Open Chest' }; }
  }
  for (const s of world.supplies) {
    if (s.opened) continue;
    const d = dist(player.x, player.y, s.x, s.y);
    if (d < bestD) { bestD = d; best = { type: 'chest', obj: s, label: 'Open Supply Drop' }; }
  }
  for (const c of world.crates) {
    if (c.opened) continue;
    const d = dist(player.x, player.y, c.x, c.y);
    if (d < bestD) { bestD = d; best = { type: 'crate', obj: c, label: 'Break Crate (+' + c.wood + ' wood)' }; }
  }
  for (const l of world.loot) {
    const d = dist(player.x, player.y, l.x, l.y);
    if (d < bestD - 10) {
      const it = l.item;
      let label;
      if (it.type === 'weapon') label = 'Pick up ' + RARITY[it.rarity].name + ' ' + WEAPONS[it.kind].name;
      else if (it.type === 'shield') label = 'Pick up Shield Potion';
      else if (it.type === 'med') label = 'Pick up Medkit';
      else label = 'Pick up ' + it.amount + ' Wood';
      bestD = d;
      best = { type: 'loot', obj: l, label };
    }
  }
  return best;
}

function updatePrompt() {
  const it = findInteractable();
  game.interact = it;
  if (it) {
    ui.promptText.textContent = it.label;
    ui.prompt.classList.remove('hidden');
  } else {
    ui.prompt.classList.add('hidden');
  }
}

function doInteract() {
  const it = game.interact || findInteractable();
  if (!it) return;
  if (it.type === 'chest') openChest(it.obj);
  else if (it.type === 'crate') openCrate(it.obj);
  else if (it.type === 'loot') pickupLoot(it.obj);
  updatePrompt();
}

function pickupLoot(l) {
  const it = l.item;
  const idx = world.loot.indexOf(l);
  if (idx >= 0) world.loot.splice(idx, 1);

  if (it.type === 'weapon') {
    let slot = player.weapons.findIndex((w) => !w);
    if (slot < 0) slot = player.slot;
    const old = player.weapons[slot];
    if (old) {
      world.loot.push({
        x: player.x + rnd(-22, 22), y: player.y + rnd(-22, 22),
        item: makeWeapon(old.kind, old.rarity, old.ammo), bob: rnd(0, TAU)
      });
    }
    player.weapons[slot] = makeWeapon(it.kind, it.rarity, it.ammo == null ? WEAPONS[it.kind].mag : it.ammo);
    player.slot = slot;
    slotsDirty = true;
    const rar = RARITY[it.rarity];
    toast(rar.name.toUpperCase() + ' ' + WEAPONS[it.kind].name.toUpperCase(), rar.color);
    sfx('pickup');
  } else if (it.type === 'shield') {
    player.shieldPots = Math.min(5, player.shieldPots + 1);
    toast('SHIELD POTION +1', 'blue');
    sfx('pickup');
  } else if (it.type === 'med') {
    player.medkits = Math.min(3, player.medkits + 1);
    toast('MEDKIT +1', 'blue');
    sfx('pickup');
  } else if (it.type === 'wood') {
    player.wood = Math.min(999, player.wood + it.amount);
    toast('+' + it.amount + ' WOOD', 'gold');
    sfx('pickup');
  }
}

function useConsumable(type) {
  if (!player || !player.alive || player.useT > 0) return;
  if (type === 'shield') {
    if (player.shieldPots <= 0) { toast('NO SHIELD POTIONS', 'red'); sfx('error'); return; }
    if (player.shield >= 100) { toast('SHIELD ALREADY FULL', 'red'); return; }
    player.useT = player.useDur = 1.8;
    player.useType = 'shield';
  } else {
    if (player.medkits <= 0) { toast('NO MEDKITS', 'red'); sfx('error'); return; }
    if (player.hp >= 100) { toast('HEALTH ALREADY FULL', 'red'); return; }
    player.useT = player.useDur = 2.6;
    player.useType = 'med';
  }
}

function finishUse() {
  if (!player) return;
  const t = player.useType;
  if (t === 'shield') {
    player.shieldPots--;
    player.shield = Math.min(100, player.shield + 50);
    toast('+50 SHIELD', 'blue');
    sfx('pickup');
  } else if (t === 'med') {
    player.medkits--;
    player.hp = Math.min(100, player.hp + 75);
    toast('+75 HEALTH', 'gold');
    sfx('pickup');
  }
  player.useType = null;
  player.useT = 0;
}

/* ----------------------------- slots ----------------------------- */
function buildSlots() {
  ui.slots.innerHTML = '';
  slotRefs = [];
  if (!player) return;
  // slots 0..WEAPON_SLOTS-1 are guns; the last card is the always-available pickaxe
  for (let i = 0; i <= WEAPON_SLOTS; i++) {
    const isPick = i === WEAPON_SLOTS;
    const w = isPick ? null : player.weapons[i];
    const el = document.createElement('div');
    el.className = 'slot';
    if (isPick) el.classList.add('pick');

    const key = document.createElement('span');
    key.className = 'key';
    key.textContent = i + 1;
    el.appendChild(key);

    const name = document.createElement('span');
    name.className = 'name';
    const ammo = document.createElement('span');
    ammo.className = 'ammo';

    if (w) {
      const rar = RARITY[w.rarity];
      name.textContent = WEAPONS[w.kind].short;
      name.style.color = rar.color;
      el.appendChild(name);
      el.appendChild(ammo);
      const bar = document.createElement('i');
      bar.className = 'rarity';
      bar.style.background = rar.color;
      el.appendChild(bar);
      el.style.borderColor = hexA(rar.color, 0.45);
      el.style.boxShadow = 'inset 0 -22px 26px -22px ' + rar.color;
    } else if (isPick) {
      const tool = TOOL_BY_ID[player.tool] || TOOLS[0];
      name.textContent = tool.short || 'PICKAXE';
      name.style.color = '#ffd08a';
      el.appendChild(name);
      el.style.borderColor = 'rgba(255,208,138,.42)';
      el.style.boxShadow = 'inset 0 -22px 26px -22px rgba(255,208,138,.65)';
    } else {
      el.classList.add('empty');
      name.textContent = '—';
      el.appendChild(name);
    }
    slotRefs.push({ el, ammo: w ? ammo : null, pick: isPick });
    ui.slots.appendChild(el);
  }
  slotsDirty = false;
}

/* Mouse wheel cycles through the guns you own, then the pickaxe. */
function cycleWeapon(dir) {
  if (!player) return;
  const owned = [];
  for (let i = 0; i < WEAPON_SLOTS; i++) if (player.weapons[i]) owned.push(i);
  if (!owned.length) { player.melee = true; slotsDirty = true; return; }
  const cur = player.melee ? -1 : owned.indexOf(player.slot);
  let next;
  if (cur < 0) next = dir > 0 ? 0 : owned.length - 1;
  else next = (cur + (dir > 0 ? 1 : -1) + owned.length) % owned.length;
  player.slot = owned[next];
  player.melee = false;
  slotsDirty = true;
}

/* ------------------------------- HUD ----------------------------- */
function nearestZone() {
  if (!player) return 'THE SAVANNA';
  let best = null, bestD = 1e9;
  for (const z of world.zones) {
    const d = dist(player.x, player.y, z.x, z.y);
    if (d < bestD) { bestD = d; best = z; }
  }
  if (best && bestD < best.r * 1.45) return best.name;
  return 'THE SAVANNA';
}

function updateHUD() {
  if (!player) return;

  const hp = Math.max(0, Math.round(player.hp));
  const sh = Math.max(0, Math.round(player.shield));

  if (hc.hp !== hp) { ui.healthFill.style.width = hp + '%'; ui.healthText.textContent = hp; hc.hp = hp; }
  if (hc.sh !== sh) { ui.shieldFill.style.width = sh + '%'; ui.shieldText.textContent = sh; hc.sh = sh; }

  if (hc.alive !== game.alive) { ui.aliveNum.textContent = game.alive; hc.alive = game.alive; }
  if (hc.kills !== player.kills) { ui.elimsNum.textContent = player.kills; hc.kills = player.kills; }
  if (hc.wood !== player.wood) { ui.woodNum.textContent = player.wood; hc.wood = player.wood; }
  if (hc.pots !== player.shieldPots) { ui.shieldPots.textContent = player.shieldPots; hc.pots = player.shieldPots; }
  if (hc.meds !== player.medkits) { ui.medKits.textContent = player.medkits; hc.meds = player.medkits; }

  if (slotsDirty) buildSlots();
  for (let i = 0; i < slotRefs.length; i++) {
    const ref = slotRefs[i];
    const w = ref.pick ? null : player.weapons[i];
    ref.el.classList.toggle('active', ref.pick ? !!player.melee : (!!w && player.slot === i && !player.melee));
    if (w && ref.ammo) ref.ammo.textContent = w.ammo + '/' + WEAPONS[w.kind].mag;
  }

  const cur = player.weapons[player.slot];
  const mag = player.melee ? '∞' : (cur ? cur.ammo : 0);
  if (hc.mag !== mag) { ui.ammoMag.textContent = mag; hc.mag = mag; }
  ui.ammoMag.style.color = cur && mag === 0 ? '#ff6b78' : '#fff';
  ui.ammoRes.textContent = cur ? '/ ∞' : '—';

  // storm
  const label = storm.state === 'shrink' ? 'STORM SHRINKING' : (storm.phase >= PHASES.length - 1 ? 'FINAL CIRCLES' : 'STORM CLOSING IN');
  if (hc.storm !== label) { ui.stormLabel.textContent = label; hc.storm = label; }
  ui.stormTimer.textContent = fmtTime(storm.timer || 0);

  const poi = nearestZone();
  if (hc.poi !== poi) { ui.poiLabel.textContent = poi; hc.poi = poi; }

  // prompts + crosshair
  updatePrompt();

  const active = game.state === 'playing' || game.state === 'drop';
  const third = game.view === 'third';
  if (third) {
    ui.crosshair.style.left = (viewW / 2) + 'px';
    ui.crosshair.style.top = (viewH / 2) + 'px';
  } else {
    ui.crosshair.style.left = mouse.x + 'px';
    ui.crosshair.style.top = mouse.y + 'px';
  }
  ui.crosshair.classList.toggle('hit', (game.hitT || 0) > 0);

  const scoped = active && mouse.right && cur && cur.kind === 'sniper';
  ui.scope.classList.toggle('hidden', !scoped);
  ui.crosshair.style.opacity = scoped ? '0' : (active ? '1' : '0');

  // frozen mouse cursor: third-person aim stays pinned to the middle of the screen
  ui.fixedCursor.classList.toggle('show', active && third && !scoped && !emoteOpen);
  ui.fixedCursor.classList.toggle('hit', (game.hitT || 0) > 0);

  ui.lowHealth.style.opacity = player.hp < 36 && player.alive ? '1' : '0';

  updateLeaveHold();
}

/* ----------------------------- locker ---------------------------- */
function itemsOf(kind) {
  if (kind === 'outfit') {
    return SKINS.map((s, i) => ({
      kind: kind, id: 'o:' + i, index: i, name: s.name,
      rarity: s.rarity || 'common', price: s.price || 0,
      free: i < BASE_SKIN_COUNT, pass: !!s.pass, gold: !!s.gold, collab: !!s.collab, skin: s
    }));
  }
  if (kind === 'backbling') {
    return BACKBLINGS.map((b) => ({
      kind: kind, id: 'b:' + b.id, name: b.name,
      rarity: b.rarity, price: b.price, free: !!b.free, pass: !!b.pass, gold: !!b.gold, bb: b
    }));
  }
  if (kind === 'emote') {
    return EMOTES.map((e) => ({
      kind: kind, id: 'e:' + e.id, name: e.name,
      rarity: e.rarity, price: e.price, free: !!e.free, pass: !!e.pass, gold: !!e.gold, emote: e
    }));
  }
  if (kind === 'tool') {
    return TOOLS.map((t) => ({
      kind: kind, id: 'p:' + t.id, name: t.name,
      rarity: t.rarity, price: t.price, free: !!t.free, collab: !!t.collab, tool: t
    }));
  }
  return GLIDERS.map((g) => ({
    kind: kind, id: 'g:' + g.id, name: g.name,
    rarity: g.rarity, price: g.price, free: !!g.free, pass: !!g.pass, gold: !!g.gold, glider: g
  }));
}

function priceHtml(p) {
  return '<span class="coin">T</span>' + p;
}

function bbIcon(bb) {
  const c = bb.color;
  if (bb.style === 'cape') {
    return '<svg viewBox="0 0 60 60"><path d="M18 12h24l6 42H12z" fill="' + c + '"/>' +
      '<path d="M24 12v42M36 12v42" stroke="rgba(0,0,0,.22)" stroke-width="2"/></svg>';
  }
  if (bb.style === 'wings') {
    return '<svg viewBox="0 0 60 60"><path d="M28 32C18 20 6 22 4 36c10 2 18 8 24 16z" fill="' + c + '"/>' +
      '<path d="M32 32c10-12 22-10 24 4-10 2-18 8-24 16z" fill="' + c + '"/></svg>';
  }
  if (bb.style === 'reactor') {
    return '<svg viewBox="0 0 60 60"><rect x="16" y="10" width="28" height="40" rx="9" fill="#26304a"/>' +
      '<circle cx="30" cy="30" r="11" fill="' + c + '"/><circle cx="30" cy="30" r="4.5" fill="#fff"/></svg>';
  }
  if (bb.style === 'llama') {
    return '<svg viewBox="0 0 60 60"><ellipse cx="30" cy="40" rx="15" ry="13" fill="' + c + '"/>' +
      '<circle cx="30" cy="22" r="10" fill="' + c + '"/>' +
      '<path d="M22 14l-4-7 7 4zM38 14l4-7-7 4z" fill="' + c + '"/>' +
      '<circle cx="26" cy="21" r="1.7" fill="#2a1d00"/><circle cx="34" cy="21" r="1.7" fill="#2a1d00"/></svg>';
  }
  if (bb.style === 'shark') {
    return '<svg viewBox="0 0 60 60"><path d="M28 6C18 24 12 36 12 45c0 6 8 10 18 10s18-4 18-10c0-9-6-21-20-39z" fill="' + c + '"/>' +
      '<path d="M30 20v24" stroke="rgba(0,0,0,.22)" stroke-width="2"/></svg>';
  }
  if (bb.style === 'canteen') {
    return '<svg viewBox="0 0 60 60"><rect x="20" y="18" width="20" height="34" rx="7" fill="' + c + '"/>' +
      '<rect x="25" y="10" width="10" height="9" rx="2" fill="#d9c9a0"/>' +
      '<path d="M22 26h16" stroke="rgba(0,0,0,.25)" stroke-width="3"/>' +
      '<circle cx="30" cy="38" r="6" fill="rgba(255,255,255,.3)"/></svg>';
  }
  if (bb.style === 'binos') {
    return '<svg viewBox="0 0 60 60"><rect x="10" y="20" width="18" height="26" rx="8" fill="' + c + '"/>' +
      '<rect x="32" y="20" width="18" height="26" rx="8" fill="' + c + '"/>' +
      '<rect x="26" y="27" width="8" height="7" rx="2" fill="#7b8a5a"/>' +
      '<circle cx="19" cy="42" r="6" fill="#a8d8e8" opacity=".8"/>' +
      '<circle cx="41" cy="42" r="6" fill="#a8d8e8" opacity=".8"/></svg>';
  }
  if (bb.style === 'idol') {
    return '<svg viewBox="0 0 60 60"><path d="M30 7l14 10v14L30 53 16 31V17z" fill="' + c + '"/>' +
      '<circle cx="24" cy="26" r="2.4" fill="#2a1d00"/><circle cx="36" cy="26" r="2.4" fill="#2a1d00"/>' +
      '<path d="M24 36h12" stroke="rgba(0,0,0,.3)" stroke-width="2.4" stroke-linecap="round"/></svg>';
  }
  if (bb.style === 'vault') {
    return '<svg viewBox="0 0 60 60"><rect x="12" y="16" width="36" height="34" rx="5" fill="' + c + '"/>' +
      '<rect x="12" y="16" width="36" height="11" rx="4" fill="rgba(0,0,0,.22)"/>' +
      '<circle cx="30" cy="37" r="7" fill="#ffe999"/>' +
      '<path d="M30 32v10M25 37h10" stroke="#8a651a" stroke-width="2"/></svg>';
  }
  return '<svg viewBox="0 0 60 60"><rect x="17" y="14" width="26" height="36" rx="8" fill="' + c + '"/>' +
    '<rect x="22" y="8" width="6" height="11" rx="3" fill="#3c4a66"/>' +
    '<rect x="32" y="8" width="6" height="11" rx="3" fill="#3c4a66"/></svg>';
}

function itemIcon(it) {
  if (it.kind === 'outfit') {
    const s = it.skin;
    return '<svg viewBox="0 0 60 60"><circle cx="30" cy="19" r="10" fill="' + s.skin + '"/>' +
      '<path d="M12 56c0-13 8-21 18-21s18 8 18 21z" fill="' + s.outfit + '"/>' +
      '<rect x="27" y="33" width="6" height="23" fill="' + s.accent + '"/>' +
      '<path d="M15 40l-3 10M45 40l3 10" stroke="' + s.outfit + '" stroke-width="6" stroke-linecap="round"/></svg>';
  }
  if (it.kind === 'backbling') return bbIcon(it.bb);
  if (it.kind === 'emote') {
    return '<svg viewBox="0 0 60 60"><path d="M26 8v32a9 9 0 1 1-7-8.7V19l23-6v19a9 9 0 1 1-7-8.7V14z" fill="' + ITEM_RARITY[it.rarity].color + '"/></svg>';
  }
  if (it.kind === 'tool') {
    if (it.tool.style === 'books') {
      return '<svg viewBox="0 0 60 60">' +
        '<rect x="27" y="14" width="6" height="40" rx="3" fill="#7a5433"/>' +
        '<g transform="rotate(-9 30 22)">' +
        '<rect x="8" y="8" width="44" height="9" rx="2.5" fill="#d0453f"/>' +
        '<rect x="11" y="19" width="38" height="9" rx="2.5" fill="#3f6fc9"/>' +
        '<rect x="14" y="30" width="32" height="9" rx="2.5" fill="#e8b93a"/>' +
        '<path d="M8 12h44M11 23h38M14 34h32" stroke="rgba(255,255,255,.55)" stroke-width="1.6"/>' +
        '<path d="M8 8v9M11 19v9M14 30v9" stroke="rgba(0,0,0,.28)" stroke-width="2.4"/>' +
        '</g></svg>';
    }
    return '<svg viewBox="0 0 60 60"><rect x="27" y="14" width="6" height="40" rx="3" fill="#7a5433"/>' +
      '<path d="M12 15q18-11 36 0l-5 8q-13-8-26 0z" fill="#c9d3de"/></svg>';
  }
  const g = it.glider;
  return '<svg viewBox="0 0 60 60"><path d="M4 28a26 20 0 0 1 52 0z" fill="' + g.canopy + '"/>' +
    '<path d="M13 28a17 13 0 0 1 34 0z" fill="' + g.stripe + '" opacity=".7"/>' +
    '<path d="M30 28v18M30 46l-8 9M30 46l8 9" stroke="' + g.stripe + '" stroke-width="2" fill="none"/></svg>';
}

function isEquipped(it) {
  const e = profile.equipped;
  if (it.kind === 'outfit') return e.outfit === it.index;
  if (it.kind === 'backbling') return e.backbling === it.bb.id;
  if (it.kind === 'emote') return e.emote === it.emote.id;
  if (it.kind === 'tool') return e.tool === it.tool.id;
  return e.glider === it.glider.id;
}

function equipItem(it) {
  const e = profile.equipped;
  if (it.kind === 'outfit') e.outfit = it.index;
  else if (it.kind === 'backbling') e.backbling = it.bb.id;
  else if (it.kind === 'emote') e.emote = it.emote.id;
  else if (it.kind === 'tool') e.tool = it.tool.id;
  else e.glider = it.glider.id;
  saveProfile();
  refreshPreviews();
  if (!ui.locker.classList.contains('hidden')) buildLockerGrid();
}

function updateWallet() {
  const t = profile.tokens;
  [ui.menuTokens, ui.lobbyTokens, ui.lockerTokens, ui.shopTokens, ui.ownerBalance, ui.passTokens].forEach((el) => {
    if (el) el.textContent = t.toLocaleString();
  });
}

function showBanner(text, kind) {
  if (!ui.banner) return;
  ui.banner.textContent = text;
  ui.banner.className = 'banner show' + (kind === 'error' ? ' error' : '');
  clearTimeout(bannerTimer);
  bannerTimer = setTimeout(() => ui.banner.classList.remove('show'), 2600);
}

/* --------------------------- battle pass ------------------------- */
function passTierFromXp(xp) {
  return Math.min(SEASON.tiers, 1 + Math.floor(Math.max(0, xp) / SEASON.xpPerTier));
}

function passXpForMatch(won, kills, chests, placement) {
  let xp = 40 + kills * 30 + chests * 10;
  if (won) xp += 120;
  else if (placement > 0 && placement <= 10) xp += 40;
  return xp;
}

function addPassXp(amount) {
  amount = Math.max(0, Math.floor(Number(amount) || 0));
  const before = passTierFromXp(profile.season.xp);
  profile.season.xp += amount;
  const after = passTierFromXp(profile.season.xp);
  saveProfile();
  if (after > before) {
    toast('BATTLE PASS TIER ' + after + ' UNLOCKED', 'gold');
    sfx('win');
  }
  return { xp: amount, tier: after, leveled: after > before };
}

function passRewardIcon(def) {
  const r = def.reward;
  if (r.type === 'tokens') {
    return '<span class="pass-coin"><span class="coin">T</span></span>';
  }
  const id = r.id;
  if (id.indexOf('o:') === 0) return itemIcon(itemsOf('outfit')[Number(id.slice(2))]);
  if (id.indexOf('b:') === 0) return itemIcon(itemsOf('backbling').find((x) => x.id === id));
  if (id.indexOf('e:') === 0) return itemIcon(itemsOf('emote').find((x) => x.id === id));
  return itemIcon(itemsOf('glider').find((x) => x.id === id));
}

/* free vs gold track helpers */
let passTab = 'free';

function passTiersFor(track) {
  return track === 'gold' ? GOLD_PASS_TIERS : PASS_TIERS;
}

function passClaimedFor(track) {
  return track === 'gold' ? profile.season.goldClaimed : profile.season.claimed;
}

function renderPass() {
  if (!ui.passGrid) return;
  const xp = profile.season.xp || 0;
  const tier = passTierFromXp(xp);
  const intoTier = tier >= SEASON.tiers ? 0 : xp % SEASON.xpPerTier;
  const toNext = tier >= SEASON.tiers ? 0 : SEASON.xpPerTier - intoTier;

  const track = passTab;
  const goldOwned = !!profile.season.gold;
  const tiers = passTiersFor(track);
  const claimedList = passClaimedFor(track);

  if (ui.passTierText) ui.passTierText.textContent = tier;
  if (ui.passXpFill) {
    const pct = tier >= SEASON.tiers ? 100 : Math.round((intoTier / SEASON.xpPerTier) * 100);
    ui.passXpFill.style.width = pct + '%';
  }
  if (ui.passXpText) {
    ui.passXpText.textContent = tier >= SEASON.tiers
      ? (xp.toLocaleString() + ' XP · MAX TIER')
      : (intoTier + ' / ' + SEASON.xpPerTier + ' XP · ' + toNext + ' TO TIER ' + (tier + 1));
  }
  if (ui.passXpNote) {
    ui.passXpNote.textContent = track === 'gold'
      ? (goldOwned ? 'GOLD TRACK · SAME TIERS · BIGGER REWARDS' : 'GOLD TRACK · UNLOCK FOR ' + SEASON.goldPrice + ' TOKENS')
      : 'EARN XP FROM MATCHES · 40 + 30/KILL + 10/CHEST';
  }

  if (ui.passTabFree) ui.passTabFree.classList.toggle('active', track === 'free');
  if (ui.passTabGold) ui.passTabGold.classList.toggle('active', track === 'gold');
  if (ui.passGoldTag) {
    ui.passGoldTag.textContent = goldOwned ? 'OWNED' : SEASON.goldPrice + 'T';
    ui.passGoldTag.classList.toggle('owned', goldOwned);
  }
  if (ui.passGoldCta) {
    ui.passGoldCta.classList.toggle('hidden', goldOwned || track !== 'gold');
    if (ui.passGoldPrice) ui.passGoldPrice.textContent = SEASON.goldPrice;
    if (ui.passGoldBuy) {
      const afford = profile.tokens >= SEASON.goldPrice;
      ui.passGoldBuy.disabled = !afford;
      ui.passGoldBuy.classList.toggle('poor', !afford);
    }
  }
  ui.passGrid.classList.toggle('gold', track === 'gold');

  ui.passGrid.innerHTML = '';
  tiers.forEach((def) => {
    const claimed = claimedList.indexOf(def.tier) >= 0;
    const gated = track === 'gold' && !goldOwned;
    const unlocked = def.tier <= tier && !gated;
    const state = claimed ? 'CLAIMED' : gated ? 'GOLD PASS' : unlocked ? 'READY' : 'LOCKED';
    const btnText = claimed ? 'CLAIMED' : gated ? 'LOCKED' : unlocked ? 'CLAIM' : 'LOCKED';
    const card = document.createElement('div');
    card.className = 'pass-card' + (unlocked ? ' unlocked' : ' locked') +
      (def.tier === tier ? ' current' : '') + (claimed ? ' claimed' : '') +
      (track === 'gold' ? ' gold' : '') + (gated ? ' gated' : '');
    card.innerHTML =
      '<div class="pass-card-top"><span class="pass-tag">TIER ' + def.tier + '</span>' +
      '<span class="pass-star' + (claimed ? '' : unlocked ? ' ready' : ' locked') + '">' + state + '</span></div>' +
      '<span class="pass-art">' + passRewardIcon(def) + '</span>' +
      '<span class="pass-name">' + def.reward.label + '</span>' +
      '<button class="pass-claim"' + (claimed || !unlocked ? ' disabled' : '') + '>' + btnText + '</button>';
    card.querySelector('.pass-claim').addEventListener('click', () => claimPass(def.tier, track));
    ui.passGrid.appendChild(card);
  });
}

function claimPass(tier, track) {
  track = track === 'gold' ? 'gold' : 'free';
  if (track === 'gold' && !profile.season.gold) {
    showBanner('GOLD PASS REQUIRED · ' + SEASON.goldPrice + ' TOKENS', 'error');
    sfx('error');
    return;
  }
  const tiers = passTiersFor(track);
  const def = tiers.find((d) => d.tier === tier);
  if (!def) return;
  if (tier > passTierFromXp(profile.season.xp)) { showBanner('TIER LOCKED', 'error'); sfx('error'); return; }
  const claimedList = passClaimedFor(track);
  if (claimedList.indexOf(tier) >= 0) return;
  claimedList.push(tier);
  const r = def.reward;
  const tag = track === 'gold' ? 'GOLD PASS · ' : 'BATTLE PASS · ';
  if (r.type === 'tokens') {
    profile.tokens += r.amount;
    showBanner(tag + '+' + r.amount + ' TOKENS');
  } else {
    ownItem(r.id);
    showBanner(tag + r.label + ' UNLOCKED');
  }
  saveProfile();
  updateWallet();
  buildSkinGrid();
  refreshPreviews();
  if (!ui.locker.classList.contains('hidden')) buildLockerGrid();
  renderPass();
  sfx('chest');
}

function buyGoldPass() {
  if (profile.season.gold) { showBanner('GOLD PASS ALREADY OWNED'); return; }
  if (profile.tokens < SEASON.goldPrice) {
    showBanner('NEED ' + SEASON.goldPrice + ' TOKENS', 'error');
    sfx('error');
    return;
  }
  profile.tokens -= SEASON.goldPrice;
  profile.season.gold = true;
  saveProfile();
  passTab = 'gold';
  updateWallet();
  renderPass();
  showBanner('GOLD PASS UNLOCKED · CLAIM YOUR REWARDS');
  sfx('win');
}

let passBack = 'menu';

function openPass(from, tab) {
  Sound.init();
  passBack = from || 'menu';
  passTab = tab === 'gold' ? 'gold' : 'free';
  ui.menu.classList.add('hidden');
  ui.lobby.classList.add('hidden');
  ui.locker.classList.add('hidden');
  ui.shop.classList.add('hidden');
  ui.pass.classList.remove('hidden');
  renderPass();
  updateWallet();
}

function closePass() {
  ui.pass.classList.add('hidden');
  if (passBack === 'lobby') {
    ui.lobby.classList.remove('hidden');
    buildSkinGrid();
    refreshPreviews();
    renderQuest();
  } else if (passBack === 'locker') {
    ui.locker.classList.remove('hidden');
    buildLockerGrid();
    refreshPreviews();
  } else {
    ui.menu.classList.remove('hidden');
  }
}

function ownerMaxPass() {
  const target = (SEASON.tiers - 1) * SEASON.xpPerTier;
  const need = target - profile.season.xp;
  if (need > 0) profile.season.xp += need;
  saveProfile();
  renderPass();
  ownerSay('BATTLE PASS MAXED · TIER ' + SEASON.tiers);
  showBanner('OWNER · BATTLE PASS MAXED');
  sfx('win');
}

function ownerUnlockGold() {
  if (profile.season.gold) { ownerSay('GOLD PASS ALREADY UNLOCKED'); return; }
  profile.season.gold = true;
  saveProfile();
  renderPass();
  ownerSay('GOLD PASS UNLOCKED');
  showBanner('OWNER · GOLD PASS UNLOCKED');
  sfx('win');
}

/* ------------------------- owner console ------------------------- */
function addTokens(n) {
  n = Math.floor(Number(n) || 0);
  if (!(n > 0)) return 0;
  profile.tokens = Math.min(99999999, profile.tokens + n);
  saveProfile();
  updateWallet();
  return n;
}

function ownerSay(text, bad) {
  ui.ownerMsg.textContent = text;
  ui.ownerMsg.style.color = bad ? '#ff8794' : '#9dffbe';
}

function openOwner() {
  Sound.init();
  ui.owner.classList.remove('hidden');
  ownerSay('');
  ui.ownerAmount.value = 1000;
  updateWallet();
  sfx('pickup');
}

function closeOwner() {
  ui.owner.classList.add('hidden');
}

function ownerAdd() {
  const amt = Math.floor(Number(ui.ownerAmount.value) || 0);
  if (!(amt > 0)) { ownerSay('ENTER A POSITIVE AMOUNT', true); sfx('error'); return; }
  addTokens(amt);
  ownerSay('+' + amt.toLocaleString() + ' TOKENS ADDED');
  showBanner('OWNER GRANT · +' + amt.toLocaleString() + ' TOKENS');
  sfx('chest');
}

function ownerSet() {
  const amt = Math.floor(Number(ui.ownerAmount.value) || 0);
  if (!(amt >= 0)) { ownerSay('ENTER A VALID BALANCE', true); sfx('error'); return; }
  profile.tokens = Math.min(99999999, amt);
  saveProfile();
  updateWallet();
  ownerSay('BALANCE SET TO ' + profile.tokens.toLocaleString());
  sfx('pickup');
}

function ownerUnlockAll() {
  for (const kind of ['outfit', 'backbling', 'emote', 'glider', 'tool']) {
    for (const it of itemsOf(kind)) ownItem(it.id);
  }
  saveProfile();
  buildSkinGrid();
  if (!ui.locker.classList.contains('hidden')) buildLockerGrid();
  refreshPreviews();
  ownerSay('EVERY ITEM UNLOCKED');
  showBanner('OWNER · EVERY ITEM UNLOCKED');
  sfx('win');
}

function ownerReset() {
  if (!window.confirm('Reset all progress, tokens, items and quests?')) return;
  profile = defaultProfile();
  const grant = syncSeason();
  saveProfile();
  updateWallet();
  buildSkinGrid();
  if (!ui.locker.classList.contains('hidden')) buildLockerGrid();
  refreshPreviews();
  renderQuest();
  renderPass();
  if (ui.sensRange) {
    ui.sensRange.value = profile.sensitivity;
    ui.sensVal.textContent = Number(profile.sensitivity).toFixed(1);
  }
  if (ui.easyToggle) ui.easyToggle.checked = profile.easy !== false;
  ownerSay('PROFILE RESET · SEASON ' + SEASON.number + ' START' + (grant ? ' · +' + grant + ' TOKENS' : ''));
  sfx('error');
}

/* ------------------------- token store --------------------------- */
let pendingPack = null;

function renderTokenPacks() {
  if (!ui.tokenPacks) return;
  ui.tokenPacks.innerHTML = '';
  for (const pack of TOKEN_PACKS) {
    const el = document.createElement('button');
    el.className = 'token-pack';
    el.innerHTML =
      (pack.tag ? '<span class="tp-tag">' + pack.tag + '</span>' : '') +
      '<span class="tp-amount"><span class="coin">T</span>' + pack.tokens.toLocaleString() + '</span>' +
      '<span class="tp-label">TOKENS</span>' +
      '<span class="tp-price">' + pack.price + '</span>';
    el.addEventListener('click', () => openCheckout(pack));
    ui.tokenPacks.appendChild(el);
  }
}

function openCheckout(pack) {
  Sound.init();
  pendingPack = pack;
  ui.checkout.classList.remove('hidden');
  ui.checkoutForm.classList.remove('hidden');
  ui.checkoutDone.classList.add('hidden');
  ui.ccError.textContent = '';
  ui.ccName.value = '';
  ui.ccNum.value = '';
  ui.ccExp.value = '';
  ui.ccCvc.value = '';
  ui.checkoutPack.textContent = pack.tokens.toLocaleString() + ' TOKEN PACK';
  ui.checkoutPrice.textContent = pack.price;
  ui.checkoutTokens.textContent = pack.tokens.toLocaleString();
  ui.ccPay.disabled = false;
  ui.ccPay.querySelector('span').textContent = 'PAY NOW';
  sfx('pickup');
}

function closeCheckout() {
  ui.checkout.classList.add('hidden');
  pendingPack = null;
  for (const k in keys) keys[k] = false;
}

function luhnOk(num) {
  let sum = 0, alt = false;
  for (let i = num.length - 1; i >= 0; i--) {
    let d = parseInt(num[i], 10);
    if (isNaN(d)) return false;
    if (alt) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
    alt = !alt;
  }
  return sum % 10 === 0;
}

function payCheckout() {
  if (!pendingPack || ui.ccPay.disabled) return;
  const name = ui.ccName.value.trim();
  const num = ui.ccNum.value.replace(/\D/g, '');
  const exp = ui.ccExp.value.trim();
  const cvc = ui.ccCvc.value.replace(/\D/g, '');
  let err = '';

  if (name.length < 2) {
    err = 'ENTER THE NAME ON THE CARD';
  } else if (num.length < 13 || num.length > 19 || !luhnOk(num)) {
    err = 'INVALID CARD NUMBER · TEST CARD 4242 4242 4242 4242';
  } else {
    const m = /^(\d{2})\s*\/\s*(\d{2})$/.exec(exp);
    if (!m) {
      err = 'EXPIRY MUST BE MM/YY';
    } else {
      const mm = Number(m[1]), yy = 2000 + Number(m[2]);
      const now = new Date();
      if (mm < 1 || mm > 12) err = 'INVALID EXPIRY MONTH';
      else if (yy < now.getFullYear() || (yy === now.getFullYear() && mm < now.getMonth() + 1)) err = 'CARD IS EXPIRED';
    }
    if (!err && (cvc.length < 3 || cvc.length > 4)) err = 'INVALID CVC';
  }

  if (err) {
    ui.ccError.textContent = err;
    sfx('error');
    return;
  }

  ui.ccError.textContent = '';
  ui.ccPay.disabled = true;
  ui.ccPay.querySelector('span').textContent = 'PROCESSING…';
  sfx('reload');
  setTimeout(() => {
    if (!pendingPack || ui.checkout.classList.contains('hidden')) return;
    ui.checkoutForm.classList.add('hidden');
    ui.checkoutDone.classList.remove('hidden');
    ui.checkoutGain.textContent = '+' + pendingPack.tokens.toLocaleString();
    sfx('chest');
  }, 1300);
}

function collectPurchase() {
  if (!pendingPack) return;
  const pack = pendingPack;
  addTokens(pack.tokens);
  showBanner('+' + pack.tokens.toLocaleString() + ' TOKENS ADDED');
  sfx('pickup');
  closeCheckout();
}

/* --------------------------- free skin quest --------------------- */
function questDoneCount() {
  let n = 0;
  for (const st of QUEST_STEPS) if ((profile.quest[st.key] || 0) >= st.need) n++;
  return n;
}

function questAllDone() {
  return QUEST_STEPS.every((st) => (profile.quest[st.key] || 0) >= st.need);
}

function renderQuest() {
  if (!ui.questSteps) return;
  const claimed = !!profile.quest.claimed;
  ui.questSteps.innerHTML = '';
  for (const st of QUEST_STEPS) {
    const cur = Math.min(profile.quest[st.key] || 0, st.need);
    const pct = Math.round((cur / st.need) * 100);
    const row = document.createElement('div');
    row.className = 'quest-step' + (cur >= st.need ? ' done' : '');
    row.innerHTML =
      '<div class="quest-step-top"><span>' + st.label + '</span><b>' +
      (cur >= st.need ? 'DONE' : cur + ' / ' + st.need) + '</b></div>' +
      '<div class="quest-bar"><i style="width:' + pct + '%"></i></div>';
    ui.questSteps.appendChild(row);
  }
  const btn = ui.questClaim;
  if (claimed) {
    btn.disabled = true;
    btn.classList.add('claimed');
    btn.textContent = 'SKIN CLAIMED · OWNED';
  } else {
    btn.disabled = !questAllDone();
    btn.classList.remove('claimed');
    btn.textContent = 'CLAIM FREE SKIN';
  }
}

function questAdd(key, n) {
  if (!profile || !profile.quest || profile.quest.claimed) return;
  const before = questDoneCount();
  profile.quest[key] = (profile.quest[key] || 0) + (n || 1);
  saveProfile();
  renderQuest();
  if (questDoneCount() > before) {
    if (questAllDone()) {
      showBanner('QUEST COMPLETE · CLAIM YOUR FREE SKIN');
      toast('FREE SKIN READY TO CLAIM', 'gold');
      sfx('win');
    } else {
      toast('QUEST OBJECTIVE COMPLETE', 'blue');
      sfx('pickup');
    }
  }
}

function claimQuest() {
  if (profile.quest.claimed || !questAllDone()) return;
  profile.quest.claimed = true;
  ownItem('o:' + QUEST_SKIN_INDEX);
  profile.equipped.outfit = QUEST_SKIN_INDEX;
  saveProfile();
  refreshPreviews();
  buildSkinGrid();
  if (!ui.locker.classList.contains('hidden')) buildLockerGrid();
  renderQuest();
  showBanner('FREE SKIN UNLOCKED · STORM RIDER');
  sfx('win');
}

/* --------------------------- settings ---------------------------- */
function initSettings() {
  if (ui.sensRange) {
    ui.sensRange.value = profile.sensitivity;
    ui.sensVal.textContent = Number(profile.sensitivity).toFixed(1);
    ui.sensRange.addEventListener('input', () => {
      profile.sensitivity = clamp(Number(ui.sensRange.value) || 1.2, 0.4, 2.6);
      ui.sensVal.textContent = profile.sensitivity.toFixed(1);
      saveProfile();
    });
  }
  if (ui.easyToggle) {
    ui.easyToggle.checked = profile.easy !== false;
    ui.easyToggle.addEventListener('change', () => {
      profile.easy = ui.easyToggle.checked;
      saveProfile();
      showBanner(profile.easy ? 'EASY CONTROLS ON' : 'EASY CONTROLS OFF');
    });
  }
}

/* -------------------------- svg previews ------------------------- */
function svgBackbling(bb) {
  if (bb.style === 'cape') {
    return '<path d="M78 112 C56 180 54 272 66 326 L154 326 C166 272 164 180 142 112 Z" fill="' + bb.color + '" opacity=".92"/>' +
      '<path d="M110 128v190" stroke="rgba(0,0,0,.18)" stroke-width="4"/>';
  }
  if (bb.style === 'wings') {
    return '<path d="M84 132 C44 118 16 150 18 208 C46 200 70 176 86 152 Z" fill="' + bb.color + '" opacity=".9"/>' +
      '<path d="M136 132 C176 118 204 150 202 208 C174 200 150 176 134 152 Z" fill="' + bb.color + '" opacity=".9"/>';
  }
  if (bb.style === 'reactor') {
    return '<rect x="66" y="118" width="88" height="112" rx="22" fill="#1c2436"/>' +
      '<circle cx="110" cy="152" r="34" fill="' + bb.color + '" opacity=".35"/>' +
      '<circle cx="110" cy="152" r="20" fill="' + bb.color + '"/>' +
      '<circle cx="110" cy="152" r="8" fill="#fff" opacity=".85"/>';
  }
  if (bb.style === 'llama') {
    return '<ellipse cx="74" cy="172" rx="26" ry="36" fill="' + bb.color + '"/>' +
      '<circle cx="78" cy="132" r="19" fill="' + bb.color + '"/>' +
      '<path d="M64 116l-5-13 10 7zM92 116l5-13-10 7z" fill="' + bb.color + '"/>' +
      '<circle cx="71" cy="130" r="3" fill="#2a1d00"/><circle cx="85" cy="130" r="3" fill="#2a1d00"/>';
  }
  if (bb.style === 'shark') {
    return '<path d="M150 108 C168 78 182 66 190 62 C184 90 180 116 174 140 Z" fill="' + bb.color + '"/>';
  }
  if (bb.style === 'canteen') {
    return '<rect x="76" y="128" width="68" height="150" rx="26" fill="' + bb.color + '"/>' +
      '<rect x="94" y="108" width="32" height="26" rx="6" fill="#d9c9a0"/>' +
      '<path d="M82 172h56" stroke="rgba(0,0,0,.25)" stroke-width="8"/>' +
      '<circle cx="110" cy="222" r="20" fill="rgba(255,255,255,.28)"/>';
  }
  if (bb.style === 'binos') {
    return '<rect x="60" y="140" width="40" height="62" rx="18" fill="' + bb.color + '"/>' +
      '<rect x="120" y="140" width="40" height="62" rx="18" fill="' + bb.color + '"/>' +
      '<rect x="98" y="158" width="24" height="20" rx="5" fill="#7b8a5a"/>';
  }
  if (bb.style === 'idol') {
    return '<path d="M110 58l46 30v54l-46 46-46-46V88z" fill="' + bb.color + '" opacity=".95"/>' +
      '<circle cx="94" cy="130" r="7" fill="#2a1d00"/><circle cx="126" cy="130" r="7" fill="#2a1d00"/>' +
      '<path d="M94 158h32" stroke="rgba(0,0,0,.3)" stroke-width="7" stroke-linecap="round"/>';
  }
  if (bb.style === 'vault') {
    return '<rect x="64" y="112" width="92" height="122" rx="12" fill="' + bb.color + '"/>' +
      '<rect x="64" y="112" width="92" height="34" rx="10" fill="rgba(0,0,0,.22)"/>' +
      '<circle cx="110" cy="196" r="20" fill="#ffe999"/>' +
      '<path d="M110 182v28M96 196h28" stroke="#8a651a" stroke-width="6"/>';
  }
  return '';
}

function setSvgSkin(svg, i) {
  const s = SKINS[i];
  svg.style.setProperty('--outfit', s.outfit);
  svg.style.setProperty('--accent', s.accent);
  svg.style.setProperty('--skin', s.skin);
  svg.style.setProperty('--hair', s.hair);
  svg.style.setProperty('--pants', s.pants);
  svg.classList.toggle('hair-spiky', s.hairStyle === 'spiky');
  const ids = equippedStyleIds(i);
  svg.classList.toggle('has-patch', ids.indexOf('patch') >= 0);
  svg.classList.toggle('mode-robot', ids.indexOf('robot') >= 0);
}

function buildStyleChips() {
  const i = profile.equipped.outfit;
  const list = skinEditStyles(i);
  const active = equippedStyleIds(i);
  [ui.lobbyStyles, ui.lockerStyles].forEach((row) => {
    if (!row) return;
    row.innerHTML = '';
    row.classList.toggle('hidden', !list.length);
    if (!list.length) return;
    const label = document.createElement('span');
    label.className = 'style-label';
    label.textContent = 'EDIT STYLES';
    row.appendChild(label);
    list.forEach((st) => {
      const on = st.id === 'default' ? active.length === 0 : active.indexOf(st.id) >= 0;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'style-chip' + (on ? ' active' : '');
      btn.dataset.style = st.id;
      btn.title = st.hint || st.name;
      btn.innerHTML = '<i class="style-dot ' + st.id + '"></i>' + st.name;
      btn.addEventListener('click', () => {
        if (st.id === 'default') {
          if (!active.length) return;
          clearEquippedStyles(i);
        } else {
          toggleEquippedStyle(i, st.id);
        }
        refreshPreviews();
        sfx('pickup');
        const now = equippedStyleIds(i).map((id) => skinEditStyles(i).find((x) => x.id === id).name);
        showBanner(now.length ? 'STYLE · ' + now.join(' + ') : 'STYLE · DEFAULT');
      });
      row.appendChild(btn);
    });
  });
}

function refreshPreviews() {
  const i = profile.equipped.outfit;
  const bb = BACKBLING_BY_ID[profile.equipped.backbling] || BACKBLINGS[0];
  const em = EMOTE_BY_ID[profile.equipped.emote] || EMOTES[0];
  const gl = GLIDER_BY_ID[profile.equipped.glider] || GLIDERS[0];
  const tl = TOOL_BY_ID[profile.equipped.tool] || TOOLS[0];

  [ui.charSvg, ui.lockerSvg].forEach((svg) => {
    if (!svg) return;
    setSvgSkin(svg, i);
    svg.classList.toggle('tool-books', tl.style === 'books');
    const layer = svg.querySelector('.bb-layer');
    if (layer) layer.innerHTML = svgBackbling(bb);
  });

  if (ui.skinName) ui.skinName.textContent = SKINS[i].name;
  if (ui.lockerOutfitName) ui.lockerOutfitName.textContent = SKINS[i].name;
  if (ui.lockerItemName) ui.lockerItemName.textContent = bb.name + ' · ' + em.name + ' · ' + gl.name;
  if (ui.skinGrid) {
    Array.from(ui.skinGrid.children).forEach((el) => {
      el.classList.toggle('active', Number(el.dataset.index) === i);
    });
  }
  buildStyleChips();
  updateWallet();
}

function buildSkinGrid() {
  ui.skinGrid.innerHTML = '';
  SKINS.forEach((s, i) => {
    if (!hasItem('o:' + i)) return;
    const b = document.createElement('button');
    b.className = 'skin-btn' + (i === profile.equipped.outfit ? ' active' : '');
    b.dataset.index = i;
    b.innerHTML =
      '<span class="skin-swatch" style="background:' + s.outfit + ';border-color:' + s.accent + '">' +
      '<b style="background:' + s.skin + '"></b>' +
      '<i style="background:' + s.accent + '"></i></span>' +
      '<span>' + s.name + '</span>';
    b.addEventListener('click', () => {
      profile.equipped.outfit = i;
      saveProfile();
      refreshPreviews();
      sfx('pickup');
    });
    ui.skinGrid.appendChild(b);
  });
}

function showLobby() {
  Sound.init();
  ui.menu.classList.add('hidden');
  ui.locker.classList.add('hidden');
  ui.shop.classList.add('hidden');
  ui.lobby.classList.remove('hidden');
  buildSkinGrid();
  refreshPreviews();
  renderQuest();
}

/* ----------------------------- locker UI ------------------------- */
function showLocker(from) {
  Sound.init();
  lockerBack = from || 'menu';
  ui.menu.classList.add('hidden');
  ui.lobby.classList.add('hidden');
  ui.shop.classList.add('hidden');
  ui.locker.classList.remove('hidden');
  buildLockerGrid();
  refreshPreviews();
}

function closeLocker() {
  ui.locker.classList.add('hidden');
  if (lockerBack === 'lobby') {
    ui.lobby.classList.remove('hidden');
    buildSkinGrid();
    refreshPreviews();
  } else {
    ui.menu.classList.remove('hidden');
  }
}

function initLockerUI() {
  // share the lobby artwork with the locker stage
  ui.lockerSvg.innerHTML = ui.charSvg.innerHTML;

  ui.lockerTabs.addEventListener('click', (e) => {
    const btn = e.target.closest('.tab');
    if (!btn) return;
    lockerTab = btn.dataset.tab;
    Array.from(ui.lockerTabs.children).forEach((el) => el.classList.toggle('active', el === btn));
    buildLockerGrid();
    sfx('pickup');
  });
  ui.lockerEmoteBtn.addEventListener('click', playPreviewEmote);

  $('lockerBtn').addEventListener('click', () => showLocker('menu'));
  $('shopBtn').addEventListener('click', () => openShop('menu'));
  $('passBtn').addEventListener('click', () => openPass('menu'));
  $('lobbyPassBtn').addEventListener('click', () => openPass('lobby'));
  ui.passClose.addEventListener('click', closePass);
  if (ui.passTabFree) ui.passTabFree.addEventListener('click', () => { passTab = 'free'; renderPass(); sfx('pickup'); });
  if (ui.passTabGold) ui.passTabGold.addEventListener('click', () => { passTab = 'gold'; renderPass(); sfx('pickup'); });
  if (ui.passGoldBuy) ui.passGoldBuy.addEventListener('click', buyGoldPass);
  $('questBtn').addEventListener('click', () => {
    showLobby();
    setTimeout(() => {
      if (ui.questCard && ui.questCard.scrollIntoView) ui.questCard.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }, 80);
  });
  $('ownerBtn').addEventListener('click', openOwner);
  $('shopOwnerBtn').addEventListener('click', openOwner);
  $('passOwnerBtn').addEventListener('click', openOwner);
  $('ownerClose').addEventListener('click', closeOwner);
  $('ownerAdd').addEventListener('click', ownerAdd);
  $('ownerSet').addEventListener('click', ownerSet);
  $('ownerUnlockAll').addEventListener('click', ownerUnlockAll);
  $('ownerReset').addEventListener('click', ownerReset);
  $('ownerPass').addEventListener('click', ownerMaxPass);
  $('ownerGold').addEventListener('click', ownerUnlockGold);
  Array.from(document.querySelectorAll('[data-owner-amt]')).forEach((b) => {
    b.addEventListener('click', () => {
      ui.ownerAmount.value = b.dataset.ownerAmt;
      ownerAdd();
    });
  });

  ui.questClaim.addEventListener('click', claimQuest);

  $('ccPay').addEventListener('click', payCheckout);
  $('ccCollect').addEventListener('click', collectPurchase);
  $('checkoutClose').addEventListener('click', closeCheckout);
  ui.ccNum.addEventListener('input', () => {
    const d = ui.ccNum.value.replace(/\D/g, '').slice(0, 19);
    ui.ccNum.value = d.replace(/(\d{4})(?=\d)/g, '$1 ');
  });
  ui.ccExp.addEventListener('input', () => {
    const d = ui.ccExp.value.replace(/\D/g, '').slice(0, 4);
    ui.ccExp.value = d.length > 2 ? d.slice(0, 2) + '/' + d.slice(2) : d;
  });
  ui.ccCvc.addEventListener('input', () => {
    ui.ccCvc.value = ui.ccCvc.value.replace(/\D/g, '').slice(0, 4);
  });

  initSettings();
  renderQuest();

  ui.lobbyLockerBtn.addEventListener('click', () => showLocker('lobby'));
  ui.lockerClose.addEventListener('click', closeLocker);
  ui.shopClose.addEventListener('click', closeShop);

  clearInterval(shopTimer);
  shopTimer = setInterval(updateShopReset, 30000);

  buildSkinGrid();
  refreshPreviews();
  renderPass();
}

function buildLockerGrid() {
  ui.lockerGrid.innerHTML = '';
  const list = itemsOf(lockerTab);
  for (const it of list) {
    const owned = hasItem(it.id);
    const eq = isEquipped(it);
    const rar = ITEM_RARITY[it.rarity] || ITEM_RARITY.common;
    const isQuest = !!(it.skin && it.skin.quest);
    const isPass = !!it.pass;
    const isGold = !!it.gold;
    const card = document.createElement('button');
    card.className = 'item-card' + (eq ? ' equipped' : '') + (owned ? '' : ' locked') + (isGold ? ' gold' : '');
    card.innerHTML =
      '<span class="item-art">' + itemIcon(it) + '</span>' +
      '<span class="item-name">' + it.name + '</span>' +
      '<span class="item-rarity" style="color:' + rar.color + '">' + rar.name + '</span>' +
      (owned
        ? '<span class="item-state">' + (eq ? 'EQUIPPED' : 'EQUIP') + '</span>'
        : isQuest
          ? '<span class="item-price">QUEST</span>'
          : isPass
            ? '<span class="item-price' + (isGold ? ' gold' : ' pass') + '">' + (isGold ? 'GOLD PASS' : 'BATTLE PASS') + '</span>'
            : '<span class="item-price">' + priceHtml(it.price) + '</span>');
    card.addEventListener('click', () => {
      if (hasItem(it.id)) {
        equipItem(it);
        sfx('pickup');
      } else if (isQuest) {
        showBanner('FREE SKIN QUEST · CHECK THE LOBBY', 'error');
        sfx('error');
      } else if (isPass) {
        openPass('locker', isGold ? 'gold' : 'free');
        sfx('pickup');
      } else {
        openShop('locker', it.id);
      }
    });
    ui.lockerGrid.appendChild(card);
  }
}

function playPreviewEmote() {
  const id = profile.equipped.emote;
  if (!id || id === 'none') {
    showBanner('EQUIP AN EMOTE FIRST', 'error');
    sfx('error');
    return;
  }
  const cls = 'emote-' + id;
  ui.lockerSvg.classList.remove('emote-wave', 'emote-floss', 'emote-robot', 'emote-groove', 'emote-victory', 'emote-safari', 'emote-gold');
  void ui.lockerSvg.offsetWidth;
  ui.lockerSvg.classList.add(cls);
  clearTimeout(emotePreviewTimer);
  emotePreviewTimer = setTimeout(() => ui.lockerSvg.classList.remove(cls), 3400);
  sfx('pickup');
}

/* ------------------------------ shop ----------------------------- */
function daySeed() {
  const s = localDayKey();
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function dailyPicks(all) {
  let seed = daySeed();
  const pool = all.slice();
  const picks = [];
  const n = Math.min(4, pool.length);
  for (let i = 0; i < n; i++) {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    picks.push(pool.splice(seed % pool.length, 1)[0]);
  }
  return picks;
}

function shopCard(it, featured) {
  const owned = hasItem(it.id);
  const eq = isEquipped(it);
  const rar = ITEM_RARITY[it.rarity] || ITEM_RARITY.common;
  const card = document.createElement('div');
  card.className = 'item-card' + (featured ? ' featured' : '');
  card.dataset.id = it.id;
  card.innerHTML =
    (featured ? '<span class="item-featured">DAILY</span>' : '') +
    (it.collab ? '<span class="item-collab">COLLAB</span>' : '') +
    '<span class="item-art">' + itemIcon(it) + '</span>' +
    '<span class="item-name">' + it.name + '</span>' +
    '<span class="item-rarity" style="color:' + rar.color + '">' + rar.name + '</span>' +
    (owned
      ? '<button class="item-buy owned" disabled>' + (eq ? 'EQUIPPED' : 'OWNED') + '</button>'
      : '<button class="item-buy">' + priceHtml(it.price) + '</button>');
  if (!owned) {
    const btn = card.querySelector('.item-buy');
    btn.addEventListener('click', () => buyItem(it));
  }
  return card;
}

function buyItem(it) {
  if (hasItem(it.id)) return;
  if (profile.tokens < it.price) {
    showBanner('NOT ENOUGH TOKENS', 'error');
    sfx('error');
    return;
  }
  profile.tokens -= it.price;
  ownItem(it.id);
  equipItem(it);
  saveProfile();
  buildShop();
  if (!ui.locker.classList.contains('hidden')) buildLockerGrid();
  updateWallet();
  showBanner('PURCHASED · ' + it.name);
  sfx('pickup');
}

function buildShop(focusId) {
  const all = [];
  for (const kind of ['outfit', 'backbling', 'emote', 'glider', 'tool']) {
    for (const it of itemsOf(kind)) {
      if (!it.free && it.price > 0) all.push(it);
    }
  }
  const collab = all.filter((it) => it.collab);
  const regular = all.filter((it) => !it.collab);
  const daily = dailyPicks(regular);
  const dailyIds = new Set(daily.map((d) => d.id));

  if (ui.shopGridCollab) {
    ui.shopGridCollab.innerHTML = '';
    collab.forEach((it) => ui.shopGridCollab.appendChild(shopCard(it, false)));
  }

  ui.shopGrid.innerHTML = '';
  daily.forEach((it) => ui.shopGrid.appendChild(shopCard(it, true)));

  ui.shopGridAll.innerHTML = '';
  regular.forEach((it) => {
    if (dailyIds.has(it.id)) return;
    ui.shopGridAll.appendChild(shopCard(it, false));
  });

  if (focusId) {
    const el = ui.shopGrid.querySelector('[data-id="' + focusId + '"]') ||
      (ui.shopGridCollab && ui.shopGridCollab.querySelector('[data-id="' + focusId + '"]')) ||
      ui.shopGridAll.querySelector('[data-id="' + focusId + '"]');
    if (el) {
      el.classList.add('flash');
      if (el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
    }
  }
}

function updateShopReset() {
  const now = new Date();
  const mid = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  const ms = mid - now;
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  ui.shopReset.textContent = 'RESETS IN ' + h + 'H ' + String(m).padStart(2, '0') + 'M';
}

function openShop(from, focusId) {
  Sound.init();
  shopBack = from || 'menu';
  ui.menu.classList.add('hidden');
  ui.lobby.classList.add('hidden');
  ui.locker.classList.add('hidden');
  ui.shop.classList.remove('hidden');
  buildShop(focusId);
  updateWallet();
  updateShopReset();
  renderTokenPacks();
}

function closeShop() {
  ui.shop.classList.add('hidden');
  if (shopBack === 'locker') {
    ui.locker.classList.remove('hidden');
    buildLockerGrid();
    refreshPreviews();
  } else if (shopBack === 'lobby') {
    ui.lobby.classList.remove('hidden');
    buildSkinGrid();
    refreshPreviews();
  } else {
    ui.menu.classList.remove('hidden');
  }
}

/* --------------------------- emote wheel ------------------------- */
/* Pressing B opens a wheel so you can pick any emote you own. The
   equipped emote stays highlighted; locked ones show their price. */
function wheelEmotes() {
  return EMOTES.filter((e) => e.id !== 'none');
}

function openEmoteWheel() {
  if (!player || !player.alive) return;
  if (game.state !== 'playing' && game.state !== 'drop') return;
  if (emoteOpen) { closeEmoteWheel(); return; }
  if (player.useT > 0) return;

  emoteOpen = true;
  mouse.down = false;
  mouse.right = false;
  for (const k in keys) keys[k] = false;
  cancelLeaveHold();

  buildEmoteWheel();
  const eq = profile.equipped.emote;
  const idx = wheelEmotes().findIndex((e) => e.id === eq);
  emoteSel = idx >= 0 ? idx : 0;
  paintEmoteSel();

  ui.emoteWheel.classList.remove('hidden');
  document.body.classList.add('emote-open');
  ui.fixedCursor.classList.remove('show');
  sfx('pickup');
}

function closeEmoteWheel() {
  if (!emoteOpen) return;
  emoteOpen = false;
  ui.emoteWheel.classList.add('hidden');
  document.body.classList.remove('emote-open');
  emoteCards = [];
}

function buildEmoteWheel() {
  const list = wheelEmotes();
  ui.emoteRing.innerHTML = '';
  ui.emoteRing.appendChild(ui.emoteHub);
  emoteCards = [];

  const radius = clamp((Math.min(viewW, viewH) - 118) / 2, 96, 126);
  const n = list.length;
  for (let i = 0; i < n; i++) {
    const e = list[i];
    const id = 'e:' + e.id;
    const owned = hasItem(id);
    const rar = ITEM_RARITY[e.rarity] || ITEM_RARITY.common;
    const el = document.createElement('button');
    el.type = 'button';
    el.className = 'ew-seg' + (owned ? '' : ' locked') + (profile.equipped.emote === e.id ? ' equipped' : '');
    el.dataset.idx = String(i);
    const tag = owned
      ? (profile.equipped.emote === e.id ? 'EQUIPPED' : 'OWNED')
      : e.pass
        ? (e.gold ? 'GOLD PASS' : 'BATTLE PASS')
        : 'LOCKED · ' + e.price + 'T';
    el.innerHTML =
      '<span class="ew-name">' + e.name + '</span>' +
      '<span class="ew-tag">' + tag + '</span>' +
      '<span class="ew-bar" style="background:' + rar.color + '"></span>';

    const a = -Math.PI / 2 + (i * TAU) / n;
    el.style.left = 'calc(50% + ' + (Math.cos(a) * radius).toFixed(1) + 'px)';
    el.style.top = 'calc(50% + ' + (Math.sin(a) * radius).toFixed(1) + 'px)';

    el.addEventListener('mouseenter', () => { emoteSel = i; paintEmoteSel(); });
    el.addEventListener('click', (ev) => {
      ev.stopPropagation();
      emoteSel = i;
      paintEmoteSel();
      playSelectedEmote();
    });

    ui.emoteRing.appendChild(el);
    emoteCards.push({ el, emote: e, locked: !owned });
  }
}

function paintEmoteSel() {
  for (let i = 0; i < emoteCards.length; i++) {
    emoteCards[i].el.classList.toggle('sel', i === emoteSel);
  }
  const c = emoteCards[emoteSel];
  ui.emoteHubName.textContent = c ? c.emote.name : '—';
}

function rotateEmoteSel(dir) {
  if (!emoteCards.length) return;
  emoteSel = (emoteSel + dir + emoteCards.length) % emoteCards.length;
  paintEmoteSel();
  sfx('tick');
}

function playSelectedEmote() {
  const c = emoteCards[emoteSel];
  if (!c) return;
  if (c.locked) {
    toast(c.emote.pass ? (c.emote.gold ? 'GOLD PASS REWARD · CHECK THE PASS' : 'BATTLE PASS REWARD · CHECK THE PASS') : 'LOCKED · UNLOCK IN THE SHOP', 'red');
    sfx('error');
    return;
  }
  if (!player || !player.alive) { closeEmoteWheel(); return; }
  player.emote = c.emote.id;
  player.emoteT = 3.4;
  player.emoteTick = 0;
  toast(c.emote.name, 'blue');
  sfx('pickup');
  closeEmoteWheel();
}

/* keep the old name working for any callers */
function playEmote() {
  if (!player || !player.alive) return;
  if (game.state !== 'playing' && game.state !== 'drop') return;
  if (player.useT > 0) return;
  const id = profile.equipped.emote;
  if (!id || id === 'none') { toast('NO EMOTE EQUIPPED', 'red'); return; }
  player.emote = id;
  player.emoteT = 3.4;
  player.emoteTick = 0;
  sfx('pickup');
}

function toggleView() {
  game.view = game.view === 'third' ? 'top' : 'third';
  if (game.view === 'third') {
    document.body.classList.add('playing');
    lockCursor();
  } else {
    document.body.classList.remove('playing');
    ui.fixedCursor.classList.remove('show');
    unlockCursor();
  }
  toast(game.view === 'third' ? 'THIRD-PERSON VIEW' : 'TOP-DOWN VIEW', 'blue');
}

/* --------------------------- match flow -------------------------- */
function startMatch() {
  Sound.init();

  ui.menu.classList.add('hidden');
  ui.lobby.classList.add('hidden');
  ui.dead.classList.add('hidden');
  ui.won.classList.add('hidden');
  ui.pause.classList.add('hidden');
  ui.pass.classList.add('hidden');
  ui.hud.classList.remove('hidden');
  ui.killfeed.innerHTML = '';
  ui.toasts.innerHTML = '';
  ui.confetti.innerHTML = '';
  cancelLeaveHold();
  closeEmoteWheel();
  document.body.classList.add('playing');

  generateWorld();
  initStorm();

  bullets = [];
  particles = [];
  texts = [];
  fighters = [];
  bots = [];
  game.hitT = 0;
  game.shake = 0;
  game.stormTick = 0;
  game.time = 0;
  game.total = 50;
  game.alive = 50;
  game.placement = 0;
  game.questCounted = false;
  game.chests = 0;
  game.yaw = -Math.PI / 2;
  game.pitch = -0.08;

  let px = HALF, py = HALF, ok = false;
  for (let i = 0; i < 80 && !ok; i++) {
    px = HALF + rnd(-600, 600);
    py = HALF + rnd(-600, 600);
    ok = !insideAnyBuilding(px, py, 50) && !nearLake(px, py, 10);
  }

  player = makeFighter(px, py, true);
  player.name = 'YOU';
  const eq = profile.equipped;
  player.skin = SKINS[eq.outfit] || SKINS[0];
  player.editStyles = equippedStyleIds(eq.outfit);
  player.color = player.skin.accent;
  player.backbling = eq.backbling;
  player.glider = GLIDER_BY_ID[eq.glider] || GLIDERS[0];
  player.tool = TOOL_BY_ID[eq.tool] ? eq.tool : 'standard';
  player.emote = eq.emote;
  player.weapons[0] = makeWeapon('pistol', 0);
  player.medkits = 1;
  player.shield = 50;
  player.shieldPots = 2;
  player.melee = false;
  player.swing = 0;
  player.z = 1;
  player.aim = game.yaw;
  fighters.push(player);

  spawnBots(49);

  game.state = 'drop';
  game.camX = player.x;
  game.camY = player.y;
  game.camZoom = 0.6;
  supplyTimer = 55;

  slotsDirty = true;
  hc.hp = hc.sh = hc.alive = hc.kills = hc.wood = hc.mag = hc.storm = hc.poi = hc.pots = hc.meds = '';
  buildSlots();
  updateHUD();

  lockCursor();
  toast('SKYDIVE — STEER WITH WASD', 'blue');
}

function goMenu() {
  game.state = 'menu';
  game.stateBefore = null;
  unlockCursor();
  document.body.classList.remove('playing');
  ui.hud.classList.add('hidden');
  ui.dead.classList.add('hidden');
  ui.won.classList.add('hidden');
  ui.pause.classList.add('hidden');
  ui.lobby.classList.add('hidden');
  ui.locker.classList.add('hidden');
  ui.shop.classList.add('hidden');
  ui.pass.classList.add('hidden');
  ui.menu.classList.remove('hidden');
  ui.crosshair.style.opacity = '0';
  ui.scope.classList.add('hidden');
  ui.fixedCursor.classList.remove('show');
  cancelLeaveHold();
  closeEmoteWheel();
  ui.killfeed.innerHTML = '';
  ui.toasts.innerHTML = '';
  ui.confetti.innerHTML = '';
  for (const k in keys) keys[k] = false;

  player = null;
  fighters = [];
  bots = [];
  bullets = [];
  particles = [];
  texts = [];
  generateWorld();
  initStorm();
  game.camX = HALF;
  game.camY = HALF;
}

function endMatch(won) {
  if (game.state === 'dead' || game.state === 'won') return;
  game.state = won ? 'won' : 'dead';
  document.body.classList.remove('playing');
  unlockCursor();
  ui.hud.classList.add('hidden');
  ui.crosshair.style.opacity = '0';
  ui.scope.classList.add('hidden');
  ui.fixedCursor.classList.remove('show');
  cancelLeaveHold();
  closeEmoteWheel();
  for (const k in keys) keys[k] = false;

  if (!game.questCounted) {
    game.questCounted = true;
    questAdd('matches', 1);
  }

  const kills = player ? player.kills : 0;
  const dmg = player ? Math.round(player.dmgDealt) : 0;
  const time = fmtTime(game.time);
  const chests = game.chests || 0;
  const placement = won ? 1 : (game.placement || 1);
  const passInfo = addPassXp(passXpForMatch(won, kills, chests, placement));
  const xpLine = '+' + passInfo.xp + ' BATTLE PASS XP · TIER ' + passInfo.tier + (passInfo.leveled ? ' · NEW TIER!' : '');

  if (won) {
    ui.wonKills.textContent = kills;
    ui.wonTime.textContent = time;
    ui.wonDmg.textContent = dmg;
    if (ui.wonXp) ui.wonXp.textContent = xpLine;
    ui.won.classList.remove('hidden');
    confetti();
    sfx('win');
  } else {
    ui.deadPlace.textContent = '#' + (game.placement || 1);
    ui.deadKills.textContent = kills;
    ui.deadTime.textContent = time;
    ui.deadDmg.textContent = dmg;
    if (ui.deadXp) ui.deadXp.textContent = xpLine;
    ui.dead.classList.remove('hidden');
    sfx('death');
  }
}

function togglePause() {
  if (game.state === 'playing' || game.state === 'drop') {
    game.stateBefore = game.state;
    game.state = 'paused';
    ui.pause.classList.remove('hidden');
    document.body.classList.remove('playing');
    ui.fixedCursor.classList.remove('show');
    unlockCursor();
    for (const k in keys) keys[k] = false;
    mouse.down = false;
    mouse.right = false;
  } else if (game.state === 'paused') {
    game.state = game.stateBefore || 'playing';
    ui.pause.classList.add('hidden');
    document.body.classList.add('playing');
    lockCursor();
  }
}

/* ---------------------- hold ESC to leave match ------------------- */
/* There is no pause any more. Holding Escape for five seconds returns
   to the main menu; a quick tap does nothing. */
function beginLeaveHold() {
  if (escHeld) return;
  if (game.state !== 'playing' && game.state !== 'drop') return;
  escHeld = true;
  escStart = performance.now();
  ui.leaveHold.classList.remove('hidden');
  ui.leaveFill.style.width = '0%';
  clearTimeout(escTimer);
  escTimer = setTimeout(() => {
    escTimer = null;
    if (!escHeld) return;
    if (game.state !== 'playing' && game.state !== 'drop') { cancelLeaveHold(); return; }
    cancelLeaveHold();
    leaveMatch();
  }, LEAVE_HOLD_MS);
}

function cancelLeaveHold() {
  escHeld = false;
  escStart = 0;
  if (escTimer) { clearTimeout(escTimer); escTimer = null; }
  ui.leaveHold.classList.add('hidden');
  ui.leaveFill.style.width = '0%';
}

function updateLeaveHold() {
  if (!escHeld) return;
  if (game.state !== 'playing' && game.state !== 'drop') { cancelLeaveHold(); return; }
  const p = Math.min(1, (performance.now() - escStart) / LEAVE_HOLD_MS);
  ui.leaveFill.style.width = (p * 100).toFixed(1) + '%';
}

function leaveMatch() {
  if (game.state !== 'playing' && game.state !== 'drop') return;
  goMenu();
  toast('LEFT MATCH', 'red');
}

function confetti() {
  ui.confetti.innerHTML = '';
  const colors = ['#ffc93c', '#43e8ff', '#b14dff', '#57e389', '#ff5566', '#ffffff'];
  for (let i = 0; i < 120; i++) {
    const d = document.createElement('div');
    d.className = 'confetti-piece';
    d.style.left = rnd(0, 100) + '%';
    d.style.background = pick(colors);
    d.style.width = rnd(5, 12) + 'px';
    d.style.height = rnd(9, 20) + 'px';
    d.style.animationDuration = rnd(2.2, 4.8) + 's';
    d.style.animationDelay = rnd(0, 1.6) + 's';
    ui.confetti.appendChild(d);
  }
}

/* ----------------------------- input ----------------------------- */
/* The frozen cursor is drawn by #fixedCursor, so the game intentionally
   does not grab pointer lock: pointer lock swallows the Escape key and
   would break the hold-to-leave gesture. */
function lockCursor() {}

function unlockCursor() {
  if (document.pointerLockElement) { try { document.exitPointerLock(); } catch (e) { /* ignore */ } }
}

function toggleMute() {
  muted = !muted;
  if (Sound.master) Sound.master.gain.value = muted ? 0 : 0.5;
  toast(muted ? 'SOUND OFF' : 'SOUND ON', 'blue');
}

function bindInput() {
  window.addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase();
    if (emoteOpen) {
      const list = wheelEmotes();
      if (k === 'escape' || k === 'b') {
        e.preventDefault();
        closeEmoteWheel();
        return;
      }
      if (k === 'enter' || k === ' ') {
        e.preventDefault();
        if (!e.repeat) playSelectedEmote();
        return;
      }
      if (k === 'a' || k === 'q' || k === 'w' || k === 'arrowleft' || k === 'arrowup') {
        e.preventDefault();
        if (!e.repeat) rotateEmoteSel(-1);
        return;
      }
      if (k === 'd' || k === 'e' || k === 's' || k === 'arrowright' || k === 'arrowdown') {
        e.preventDefault();
        if (!e.repeat) rotateEmoteSel(1);
        return;
      }
      if (/^[1-9]$/.test(k)) {
        e.preventDefault();
        const i = Number(k) - 1;
        if (i < list.length) { emoteSel = i; paintEmoteSel(); playSelectedEmote(); }
        return;
      }
      return;
    }
    if (k === 'escape') {
      e.preventDefault();
      if (!ui.pass.classList.contains('hidden')) { closePass(); return; }
      if (!ui.locker.classList.contains('hidden')) { closeLocker(); return; }
      if (!ui.shop.classList.contains('hidden')) { closeShop(); return; }
      if (!ui.owner.classList.contains('hidden')) { closeOwner(); return; }
      if (!ui.checkout.classList.contains('hidden')) { closeCheckout(); return; }
      if (game.state === 'playing' || game.state === 'drop') { beginLeaveHold(); return; }
      if (game.state === 'paused') togglePause();
      return;
    }
    keys[k] = true;
    if (game.state !== 'playing' && game.state !== 'drop') return;
    if (game.view === 'third') lockCursor();
    if (e.repeat) return;
    if (k === 'r') startReload(player);
    else if (k === 'e') doInteract();
    else if (k === 'f') buildWall();
    else if (k === 'q') useConsumable('shield');
    else if (k === 'h') useConsumable('med');
    else if (k === 'm') toggleMute();
    else if (k === 'b') openEmoteWheel();
    else if (k === 'v') toggleView();
    else if (k === PICK_KEY) {
      if (player) { player.melee = true; slotsDirty = true; }
    }
    else if (/^[1-5]$/.test(k)) {
      const i = Number(k) - 1;
      if (player && player.weapons[i]) { player.slot = i; player.melee = false; slotsDirty = true; }
    }
  });

  window.addEventListener('keyup', (e) => {
    const k = e.key.toLowerCase();
    keys[k] = false;
    if (k === 'escape') cancelLeaveHold();
  });
  window.addEventListener('mousemove', (e) => {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
    mouse.moveX += e.movementX || 0;
    mouse.moveY += e.movementY || 0;
  });

  window.addEventListener('wheel', (e) => {
    if (e.deltaY === 0) return;
    if (emoteOpen) { rotateEmoteSel(e.deltaY > 0 ? 1 : -1); return; }
    if (game.state !== 'playing' && game.state !== 'drop') return;
    if ([...document.querySelectorAll('.screen')].some((s) => !s.classList.contains('hidden'))) return;
    cycleWeapon(e.deltaY > 0 ? 1 : -1);
  }, { passive: true });

  window.addEventListener('mousedown', (e) => {
    if (emoteOpen) return;
    if (e.target && e.target.closest && e.target.closest('.screen')) return;
    if (e.button === 0) {
      mouse.down = true;
      mouse.clicked = true;
      if (game.view === 'third' && (game.state === 'playing' || game.state === 'drop')) lockCursor();
    }
    if (e.button === 2) mouse.right = true;
  });
  window.addEventListener('mouseup', (e) => {
    if (e.button === 0) mouse.down = false;
    if (e.button === 2) mouse.right = false;
  });
  window.addEventListener('contextmenu', (e) => e.preventDefault());
  window.addEventListener('blur', () => {
    mouse.down = false; mouse.right = false;
    for (const k in keys) keys[k] = false;
    cancelLeaveHold();
  });

  $('playBtn').addEventListener('click', showLobby);
  ui.dropBtn.addEventListener('click', startMatch);
  ui.backBtn.addEventListener('click', goMenu);
  $('retryBtn').addEventListener('click', startMatch);
  $('againBtn').addEventListener('click', startMatch);
  $('menuBtn').addEventListener('click', goMenu);
  $('wonMenuBtn').addEventListener('click', goMenu);
  $('quitBtn').addEventListener('click', goMenu);
  $('resumeBtn').addEventListener('click', togglePause);

  document.querySelector('#emoteWheel .ew-backdrop').addEventListener('mousedown', (e) => {
    e.stopPropagation();
    closeEmoteWheel();
  });
  ui.emoteHub.addEventListener('click', (e) => {
    e.stopPropagation();
    playSelectedEmote();
  });

  initLockerUI();
}
