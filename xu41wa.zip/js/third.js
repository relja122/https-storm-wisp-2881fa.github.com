'use strict';
/* ==================================================================
   STORM ROYALE — third-person pseudo-3D renderer
   Camera behind the shoulder, perspective ground, billboard props,
   extruded walls + roofs and detailed humanoid characters.
   ================================================================== */

const T3 = {
  buf: null, bctx: null, img: null, data32: null,
  low: null, lowCtx: null, low32: null, lowKey: null,
  W: 0, H: 0, focalL: 1,
  camX: 0, camY: 0, camZ: 0,
  fx: 0, fy: 0, fz: 0,
  rx: 0, ry: 0,
  ux: 0, uy: 0, uz: 0,
  focal: 1,
  ox: 0, oy: 0,
  list: [],
  sky: null
};

const T3_TS = 512;
const T3_FOG_R = 232, T3_FOG_G = 212, T3_FOG_B = 170;

function thirdShade(hex, amt) {
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  r = clamp(Math.round(r + amt * 255), 0, 255);
  g = clamp(Math.round(g + amt * 255), 0, 255);
  b = clamp(Math.round(b + amt * 255), 0, 255);
  return '#' + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1);
}

function thirdWrap(a) {
  while (a > Math.PI) a -= TAU;
  while (a < -Math.PI) a += TAU;
  return a;
}

/* --------------------------- setup ------------------------------- */
function thirdEnsure() {
  const k = Math.min(1, 380 / Math.max(1, viewH));
  const w = Math.max(2, Math.round(viewW * k));
  const h = Math.max(2, Math.round(viewH * k));

  if (!T3.buf) {
    T3.buf = document.createElement('canvas');
    T3.bctx = T3.buf.getContext('2d');
  }
  if (T3.buf.width !== w || T3.buf.height !== h) {
    T3.buf.width = w; T3.buf.height = h;
    T3.W = w; T3.H = h;
    T3.focalL = h * 0.92;
    T3.img = T3.bctx.createImageData(w, h);
    T3.data32 = new Uint32Array(T3.img.data.buffer);
    T3.sky = new Uint32Array(h);
    for (let y = 0; y < h; y++) {
      const t = y / Math.max(1, h - 1);
      let r, g, b;
      if (t < 0.55) {
        const q = t / 0.55;
        r = 62 + (160 - 62) * q; g = 128 + (196 - 128) * q; b = 190 + (206 - 190) * q;
      } else {
        const q = (t - 0.55) / 0.45;
        r = 160 + (244 - 160) * q; g = 196 + (220 - 196) * q; b = 206 + (168 - 206) * q;
      }
      T3.sky[y] = 0xff000000 | ((b | 0) << 16) | ((g | 0) << 8) | (r | 0);
    }
  }

  if (!T3.low) {
    T3.low = document.createElement('canvas');
    T3.low.width = T3_TS; T3.low.height = T3_TS;
    T3.lowCtx = T3.low.getContext('2d');
  }
  if (T3.lowKey !== terrain) {
    T3.lowCtx.clearRect(0, 0, T3_TS, T3_TS);
    if (terrain) T3.lowCtx.drawImage(terrain, 0, 0, T3_TS, T3_TS);
    const d = T3.lowCtx.getImageData(0, 0, T3_TS, T3_TS).data;
    T3.low32 = new Uint32Array(d.buffer);
    T3.lowKey = terrain;
  }
}

function thirdCamera() {
  const yaw = game.yaw;
  const alt = (game.state === 'drop' && player) ? Math.max(0, player.z) : 0;
  const dist = 245 + alt * 30;
  const camH = 112 + alt * 300;

  T3.camX = player.x - Math.cos(yaw) * dist;
  T3.camY = player.y - Math.sin(yaw) * dist;
  T3.camZ = camH;

  const targetZ = 100 + game.pitch * 190 + alt * 150;
  const tx = player.x + Math.cos(yaw) * 210;
  const ty = player.y + Math.sin(yaw) * 210;

  let fx = tx - T3.camX, fy = ty - T3.camY, fz = targetZ - T3.camZ;
  const fl = Math.hypot(fx, fy, fz) || 1;
  fx /= fl; fy /= fl; fz /= fl;
  T3.fx = fx; T3.fy = fy; T3.fz = fz;

  const hl = Math.hypot(fx, fy) || 0.0001;
  T3.rx = -fy / hl;
  T3.ry = fx / hl;

  // up = forward x right
  T3.ux = -fz * T3.ry;
  T3.uy = fz * T3.rx;
  T3.uz = fx * T3.ry - fy * T3.rx;

  T3.focal = viewH * 0.92;
}

function thirdProject(x, y, z, out) {
  const dx = x - T3.camX, dy = y - T3.camY, dz = z - T3.camZ;
  const cz = dx * T3.fx + dy * T3.fy + dz * T3.fz;
  if (cz < 7) return null;
  const cx = dx * T3.rx + dy * T3.ry;
  const cy = dx * T3.ux + dy * T3.uy + dz * T3.uz;
  const inv = T3.focal / cz;
  out = out || {};
  out.x = viewW / 2 + T3.ox + cx * inv;
  out.y = viewH / 2 + T3.oy - cy * inv;
  out.cz = cz;
  out.s = inv;
  return out;
}

function thirdDepth(x, y) {
  return (x - T3.camX) * T3.fx + (y - T3.camY) * T3.fy;
}

function thirdInView(x, y, cz) {
  const cx = (x - T3.camX) * T3.rx + (y - T3.camY) * T3.ry;
  return Math.abs(cx) < cz * 1.45 + 90;
}

/* ------------------------ ground / sky --------------------------- */
function thirdRenderGround() {
  const W = T3.W, H = T3.H, focal = T3.focalL;
  const data = T3.data32;
  const sky = T3.sky;
  const low = T3.low32;

  const nyH = -T3.fz / (T3.uz || 0.0001);
  const horizon = H / 2 - nyH * focal;
  const yStart = Math.max(0, Math.floor(horizon));
  let i = 0;

  // sky
  for (let y = 0; y < yStart; y++) {
    const col = sky[Math.min(H - 1, Math.max(0, Math.round(y)))];
    for (let x = 0; x < W; x++) data[i++] = col;
  }
  // guard against a negative horizon
  if (horizon > 0) i = Math.floor(horizon) * W;

  const invFocal = 1 / focal;
  const nx0 = -W * 0.5 * invFocal;
  const scale = T3_TS / WORLD;
  const lowMax = T3_TS - 1;
  const maxT = 2500;

  for (let y = Math.max(0, yStart); y < H; y++) {
    const ny = (H * 0.5 - y) * invFocal;
    const dirZ = T3.fz + T3.uz * ny;
    if (dirZ > -0.00002) {
      const col = sky[Math.min(H - 1, y)];
      for (let x = 0; x < W; x++) data[i++] = col;
      continue;
    }
    let t = -T3.camZ / dirZ;
    if (t > maxT * 2) t = maxT * 2;

    let wx = T3.camX + t * (T3.fx + T3.ux * ny) + t * T3.rx * nx0;
    let wy = T3.camY + t * (T3.fy + T3.uy * ny) + t * T3.ry * nx0;
    const stepX = t * T3.rx;
    const stepY = t * T3.ry;

    const fog = 1 - Math.exp(-Math.min(t, maxT) / 1250);
    const inv = 1 - fog;
    const fr = T3_FOG_R * fog, fg = T3_FOG_G * fog, fb = T3_FOG_B * fog;

    for (let x = 0; x < W; x++) {
      let tx = (wx * scale) | 0;
      let ty = (wy * scale) | 0;
      let p;
      if (tx < 0 || ty < 0 || tx > lowMax || ty > lowMax) {
        p = 0xff14222e;
      } else {
        p = low[ty * T3_TS + tx];
      }
      const r = ((p & 255) * inv + fr) | 0;
      const g = (((p >> 8) & 255) * inv + fg) | 0;
      const b = (((p >> 16) & 255) * inv + fb) | 0;
      data[i++] = 0xff000000 | (b << 16) | (g << 8) | r;
      wx += stepX;
      wy += stepY;
    }
  }

  T3.bctx.putImageData(T3.img, 0, 0);
}

/* --------------------------- storm wall -------------------------- */
function thirdDrawStormWall(time) {
  if (!storm) return;
  const segs = 84;
  const top = 540;
  ctx.save();
  for (let i = 0; i < segs; i++) {
    const a0 = (i / segs) * TAU;
    const a1 = ((i + 1) / segs) * TAU;
    const x0 = storm.x + Math.cos(a0) * storm.r;
    const y0 = storm.y + Math.sin(a0) * storm.r;
    const x1 = storm.x + Math.cos(a1) * storm.r;
    const y1 = storm.y + Math.sin(a1) * storm.r;
    const p0 = thirdProject(x0, y0, 0);
    const p1 = thirdProject(x1, y1, 0);
    const p2 = thirdProject(x1, y1, top);
    const p3 = thirdProject(x0, y0, top);
    if (!p0 || !p1 || !p2 || !p3) continue;
    const cz = (p0.cz + p1.cz) * 0.5;
    if (cz > 3400) continue;
    const a = 0.06 + Math.min(0.18, 260 / cz);
    ctx.beginPath();
    ctx.moveTo(p0.x, p0.y);
    ctx.lineTo(p1.x, p1.y);
    ctx.lineTo(p2.x, p2.y);
    ctx.lineTo(p3.x, p3.y);
    ctx.closePath();
    ctx.fillStyle = 'rgba(146,72,226,' + a.toFixed(3) + ')';
    ctx.fill();
  }
  // glowing rim where the storm touches the ground
  ctx.strokeStyle = 'rgba(208,150,255,.55)';
  ctx.lineWidth = 3;
  ctx.beginPath();
  let started = false;
  for (let i = 0; i <= segs; i++) {
    const a = (i / segs) * TAU;
    const p = thirdProject(storm.x + Math.cos(a) * storm.r, storm.y + Math.sin(a) * storm.r, 0);
    if (!p) { started = false; continue; }
    if (!started) { ctx.moveTo(p.x, p.y); started = true; }
    else ctx.lineTo(p.x, p.y);
  }
  ctx.stroke();
  ctx.restore();
}

/* --------------------------- world props ------------------------- */
function thirdDrawTree(tr, time) {
  const base = thirdProject(tr.x, tr.y, 0);
  if (!base) return;
  const s = base.s * (tr.scale || 1);
  const h = 118;
  const sway = Math.sin(time * 1.2 + (tr.seed || 0)) * 3 * s;

  ctx.fillStyle = 'rgba(0,0,0,.22)';
  ctx.beginPath();
  ctx.ellipse(base.x + 8 * s, base.y, 26 * s, 9 * s, 0, 0, TAU);
  ctx.fill();

  // trunk
  ctx.fillStyle = '#6b4a2e';
  ctx.beginPath();
  ctx.moveTo(base.x - 5 * s, base.y);
  ctx.lineTo(base.x - 2.6 * s + sway, base.y - h * s * 0.62);
  ctx.lineTo(base.x + 2.6 * s + sway, base.y - h * s * 0.62);
  ctx.lineTo(base.x + 5 * s, base.y);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = 'rgba(255,220,160,.16)';
  ctx.fillRect(base.x - 1.4 * s, base.y - h * s * 0.6, 1.6 * s, h * s * 0.6);

  // foliage layers
  const layers = [
    { y: 0.58, rx: 24, ry: 17, c: '#2f6d34' },
    { y: 0.74, rx: 29, ry: 20, c: '#3f8b3f' },
    { y: 0.9, rx: 25, ry: 18, c: '#52a34a' },
    { y: 1.02, rx: 18, ry: 13, c: '#66b756' }
  ];
  for (const L of layers) {
    ctx.fillStyle = L.c;
    ctx.beginPath();
    ctx.ellipse(base.x + sway * (L.y - 0.4), base.y - h * s * L.y, L.rx * s, L.ry * s, 0, 0, TAU);
    ctx.fill();
  }
  ctx.fillStyle = 'rgba(180,235,130,.28)';
  ctx.beginPath();
  ctx.ellipse(base.x - 9 * s, base.y - h * s * 0.96, 10 * s, 6 * s, -0.4, 0, TAU);
  ctx.fill();
}

function thirdDrawRock(rk) {
  const base = thirdProject(rk.x, rk.y, 0);
  if (!base) return;
  const s = base.s;
  const h = (rk.r || 26) * 0.75;
  ctx.fillStyle = 'rgba(0,0,0,.22)';
  ctx.beginPath(); ctx.ellipse(base.x + 5 * s, base.y, rk.r * 1.05 * s, rk.r * 0.36 * s, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = '#7d8590';
  ctx.beginPath();
  ctx.moveTo(base.x - rk.r * s, base.y);
  ctx.lineTo(base.x - rk.r * 0.6 * s, base.y - h * s);
  ctx.lineTo(base.x + rk.r * 0.2 * s, base.y - h * 1.12 * s);
  ctx.lineTo(base.x + rk.r * s, base.y - h * 0.35 * s);
  ctx.lineTo(base.x + rk.r * 0.9 * s, base.y);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = 'rgba(210,220,232,.36)';
  ctx.beginPath();
  ctx.moveTo(base.x - rk.r * 0.45 * s, base.y - h * 0.86 * s);
  ctx.lineTo(base.x + rk.r * 0.1 * s, base.y - h * s);
  ctx.lineTo(base.x - rk.r * 0.1 * s, base.y - h * 0.4 * s);
  ctx.closePath(); ctx.fill();
}

function thirdDrawCrate(c) {
  const base = thirdProject(c.x, c.y, 0);
  if (!base) return;
  const s = base.s;
  const w = 22 * s, h = 20 * s;
  ctx.fillStyle = 'rgba(0,0,0,.22)';
  ctx.beginPath(); ctx.ellipse(base.x, base.y, w * 0.7, 5 * s, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = c.opened ? '#6b5b45' : '#a4763f';
  ctx.fillRect(base.x - w / 2, base.y - h, w, h);
  ctx.fillStyle = 'rgba(255,225,160,.25)';
  ctx.fillRect(base.x - w / 2, base.y - h, w, 2 * s);
  ctx.strokeStyle = 'rgba(60,40,20,.5)'; ctx.lineWidth = Math.max(1, 1.4 * s);
  ctx.strokeRect(base.x - w / 2, base.y - h, w, h);
  ctx.beginPath();
  ctx.moveTo(base.x - w / 2, base.y - h); ctx.lineTo(base.x + w / 2, base.y);
  ctx.moveTo(base.x + w / 2, base.y - h); ctx.lineTo(base.x - w / 2, base.y);
  ctx.stroke();
}

function thirdDrawChest(ch, time) {
  const base = thirdProject(ch.x, ch.y, 0);
  if (!base) return;
  const s = base.s;
  const w = 26 * s, h = 18 * s;
  if (!ch.opened) {
    const pulse = 0.22 + Math.sin(time * 3 + ch.pulse) * 0.08;
    const g = ctx.createRadialGradient(base.x, base.y - h * 0.8, 0, base.x, base.y - h * 0.8, 40 * s);
    g.addColorStop(0, 'rgba(255,205,80,' + pulse + ')');
    g.addColorStop(1, 'rgba(255,205,80,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(base.x, base.y - h * 0.8, 40 * s, 0, TAU); ctx.fill();
  }
  ctx.fillStyle = 'rgba(0,0,0,.24)';
  ctx.beginPath(); ctx.ellipse(base.x, base.y, w * 0.6, 4.5 * s, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = ch.opened ? '#6a5533' : '#c79a3f';
  rrect(ctx, base.x - w / 2, base.y - h, w, h, 2.6 * s); ctx.fill();
  ctx.fillStyle = ch.opened ? '#7d6740' : '#e4bd62';
  rrect(ctx, base.x - w / 2, base.y - h, w, h * 0.5, 2.6 * s); ctx.fill();
  ctx.fillStyle = '#4a3216';
  ctx.fillRect(base.x - 1.4 * s, base.y - h * 0.5, 2.8 * s, 4.4 * s);
}

function thirdDrawLoot(it, time) {
  const base = thirdProject(it.x, it.y, 0);
  if (!base) return;
  const s = base.s;
  const bob = Math.sin(time * 3 + (it.bob || 0)) * 5;
  const yOff = (14 + bob) * s;
  const color = itemColor(it.item);
  const g = ctx.createLinearGradient(base.x, base.y, base.x, base.y - 58 * s);
  g.addColorStop(0, hexA(color, 0.50));
  g.addColorStop(1, hexA(color, 0));
  ctx.fillStyle = g;
  ctx.fillRect(base.x - 4.5 * s, base.y - 58 * s, 9 * s, 58 * s);
  ctx.fillStyle = 'rgba(0,0,0,.2)';
  ctx.beginPath(); ctx.ellipse(base.x, base.y, 11 * s, 4 * s, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = color;
  rrect(ctx, base.x - 8 * s, base.y - yOff - 7 * s, 16 * s, 12 * s, 3 * s); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,.65)';
  ctx.fillRect(base.x - 6 * s, base.y - yOff - 5 * s, 5 * s, 2 * s);
}

/* --------------------------- characters -------------------------- */
function thirdDrawPickaxe(f, s, back, held) {
  const books = f.tool === 'books';
  ctx.save();
  if (held) {
    // right hand swing pose
    const swing = f.swing > 0 ? f.swing / 0.22 : 0;
    const rot = -0.5 + Math.sin(swing * Math.PI) * 1.2;
    ctx.translate(7 * s, -22 * s);
    ctx.rotate(rot);
    if (books) {
      // wooden handle with a stack of school books for a head
      ctx.fillStyle = '#6b4a2c';
      rrect(ctx, -1.4 * s, -26 * s, 2.8 * s, 30 * s, 1.4 * s); ctx.fill();
      ctx.fillStyle = '#d0453f';
      rrect(ctx, -13 * s, -38 * s, 26 * s, 7.4 * s, 1.6 * s); ctx.fill();
      ctx.fillStyle = '#3f6fc9';
      rrect(ctx, -11 * s, -30.6 * s, 22 * s, 7 * s, 1.6 * s); ctx.fill();
      ctx.fillStyle = '#e8b93a';
      rrect(ctx, -12 * s, -23.6 * s, 24 * s, 6.6 * s, 1.6 * s); ctx.fill();
      ctx.fillStyle = '#f4edda';
      ctx.fillRect(11.2 * s, -36.6 * s, 1.8 * s, 4.6 * s);
      ctx.fillRect(9.4 * s, -29.4 * s, 1.6 * s, 4.2 * s);
      ctx.fillRect(10.4 * s, -22.6 * s, 1.6 * s, 3.8 * s);
      ctx.fillStyle = 'rgba(0,0,0,.32)';
      ctx.fillRect(-13 * s, -38 * s, 2.2 * s, 7.4 * s);
      ctx.fillRect(-11 * s, -30.6 * s, 2.2 * s, 7 * s);
      ctx.fillRect(-12 * s, -23.6 * s, 2.2 * s, 6.6 * s);
      ctx.strokeStyle = 'rgba(255,255,255,.5)';
      ctx.lineWidth = 0.8 * s;
      ctx.beginPath();
      ctx.moveTo(-8 * s, -34.4 * s); ctx.lineTo(8 * s, -34.4 * s);
      ctx.moveTo(-6 * s, -27 * s); ctx.lineTo(6 * s, -27 * s);
      ctx.stroke();
    } else {
      ctx.fillStyle = '#7a5433';
      rrect(ctx, -1.2 * s, -30 * s, 2.4 * s, 34 * s, 1.2 * s); ctx.fill();
      ctx.fillStyle = '#c9d3de';
      ctx.beginPath();
      ctx.moveTo(-9 * s, -30 * s);
      ctx.quadraticCurveTo(0, -37 * s, 9 * s, -30 * s);
      ctx.lineTo(6 * s, -26 * s);
      ctx.quadraticCurveTo(0, -31 * s, -6 * s, -26 * s);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#8e9aa8';
      ctx.fillRect(-2 * s, -33 * s, 4 * s, 5 * s);
    }
  } else {
    // strapped diagonally on the back
    ctx.save();
    ctx.translate(0, -32 * s);
    ctx.rotate(-0.55);
    if (books) {
      ctx.fillStyle = '#6b4a2c';
      rrect(ctx, -1.2 * s, -15 * s, 2.4 * s, 30 * s, 1.2 * s); ctx.fill();
      ctx.fillStyle = '#d0453f';
      rrect(ctx, -10 * s, -22.4 * s, 20 * s, 6.2 * s, 1.5 * s); ctx.fill();
      ctx.fillStyle = '#3f6fc9';
      rrect(ctx, -8.6 * s, -16.2 * s, 17.2 * s, 6 * s, 1.5 * s); ctx.fill();
      ctx.fillStyle = '#e8b93a';
      rrect(ctx, -9.4 * s, -10.2 * s, 18.8 * s, 5.8 * s, 1.5 * s); ctx.fill();
      ctx.fillStyle = '#f4edda';
      ctx.fillRect(8.4 * s, -21.4 * s, 1.4 * s, 4.2 * s);
      ctx.fillRect(7.2 * s, -15.2 * s, 1.4 * s, 4 * s);
      ctx.fillRect(8 * s, -9.2 * s, 1.4 * s, 3.8 * s);
      ctx.fillStyle = 'rgba(0,0,0,.3)';
      ctx.fillRect(-10 * s, -22.4 * s, 1.8 * s, 6.2 * s);
      ctx.fillRect(-8.6 * s, -16.2 * s, 1.8 * s, 6 * s);
      ctx.fillRect(-9.4 * s, -10.2 * s, 1.8 * s, 5.8 * s);
    } else {
      ctx.fillStyle = '#7a5433';
      rrect(ctx, -1.1 * s, -15 * s, 2.2 * s, 30 * s, 1.1 * s); ctx.fill();
      ctx.fillStyle = '#b9c4d0';
      ctx.beginPath();
      ctx.moveTo(-8 * s, -16 * s);
      ctx.quadraticCurveTo(0, -22 * s, 8 * s, -16 * s);
      ctx.lineTo(5.4 * s, -12.5 * s);
      ctx.quadraticCurveTo(0, -17 * s, -5.4 * s, -12.5 * s);
      ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }
  ctx.restore();
}

function thirdDrawRifle(f, s, back) {
  const w = f.weapons && f.weapons[f.slot];
  const acc = w ? RARITY[w.rarity].color : '#9aa7bd';
  ctx.save();
  ctx.translate((back ? -4 : 2) * s, -31 * s);
  ctx.rotate(back ? 0.42 : -0.12);
  ctx.fillStyle = '#1b2130';
  rrect(ctx, -14 * s, -2.6 * s, 30 * s, 5.2 * s, 1.8 * s); ctx.fill();
  ctx.fillStyle = '#2e384c';
  rrect(ctx, -14 * s, -2.6 * s, 12 * s, 5.2 * s, 1.8 * s); ctx.fill();
  ctx.fillStyle = acc;
  rrect(ctx, -2 * s, -3.4 * s, 3.6 * s, 6.8 * s, 1.2 * s); ctx.fill();
  ctx.fillStyle = '#12161f';
  rrect(ctx, 2 * s, 1.4 * s, 5 * s, 6 * s, 1.2 * s); ctx.fill();
  ctx.fillStyle = '#3c4a66';
  rrect(ctx, 5 * s, -2.6 * s, 9 * s, 1.6 * s, 0.8 * s); ctx.fill();
  ctx.restore();
}

function thirdDrawBackbling(f, s) {
  const bb = BACKBLING_BY_ID[f.backbling] || BACKBLINGS[0];
  const c = bb.color;
  ctx.save();
  if (bb.style === 'cape') {
    ctx.fillStyle = c;
    ctx.beginPath();
    ctx.moveTo(-11 * s, -43 * s);
    ctx.quadraticCurveTo(-16 * s, -24 * s, -12 * s, -8 * s);
    ctx.lineTo(12 * s, -8 * s);
    ctx.quadraticCurveTo(16 * s, -24 * s, 11 * s, -43 * s);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,.18)';
    ctx.fillRect(-1.4 * s, -41 * s, 2.8 * s, 32 * s);
    ctx.fillStyle = 'rgba(255,255,255,.16)';
    ctx.beginPath();
    ctx.moveTo(-10 * s, -41 * s);
    ctx.quadraticCurveTo(-13 * s, -28 * s, -11 * s, -14 * s);
    ctx.lineTo(-6 * s, -14 * s);
    ctx.quadraticCurveTo(-8 * s, -28 * s, -6 * s, -41 * s);
    ctx.closePath(); ctx.fill();
  } else if (bb.style === 'wings') {
    ctx.fillStyle = c;
    ctx.globalAlpha = 0.92;
    ctx.beginPath();
    ctx.moveTo(-8 * s, -41 * s);
    ctx.quadraticCurveTo(-30 * s, -48 * s, -30 * s, -22 * s);
    ctx.quadraticCurveTo(-18 * s, -25 * s, -7 * s, -33 * s);
    ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(8 * s, -41 * s);
    ctx.quadraticCurveTo(30 * s, -48 * s, 30 * s, -22 * s);
    ctx.quadraticCurveTo(18 * s, -25 * s, 7 * s, -33 * s);
    ctx.closePath(); ctx.fill();
    ctx.globalAlpha = 1;
    ctx.fillStyle = 'rgba(255,255,255,.3)';
    ctx.beginPath(); ctx.ellipse(-19 * s, -34 * s, 7 * s, 3 * s, -0.5, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(19 * s, -34 * s, 7 * s, 3 * s, 0.5, 0, TAU); ctx.fill();
  } else if (bb.style === 'reactor') {
    ctx.fillStyle = '#222b42';
    rrect(ctx, -8.5 * s, -43 * s, 17 * s, 20 * s, 4 * s); ctx.fill();
    const g = ctx.createRadialGradient(0, -33 * s, 0, 0, -33 * s, 11 * s);
    g.addColorStop(0, c); g.addColorStop(1, hexA(c, 0));
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(0, -33 * s, 11 * s, 0, TAU); ctx.fill();
    ctx.fillStyle = c;
    ctx.beginPath(); ctx.arc(0, -33 * s, 4 * s, 0, TAU); ctx.fill();
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.arc(0, -33 * s, 1.6 * s, 0, TAU); ctx.fill();
  } else if (bb.style === 'llama') {
    ctx.fillStyle = c;
    ctx.beginPath(); ctx.ellipse(7 * s, -38 * s, 7 * s, 9 * s, 0, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(7 * s, -47 * s, 5 * s, 0, TAU); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(4 * s, -51 * s); ctx.lineTo(2 * s, -56 * s); ctx.lineTo(6 * s, -52 * s); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#2a1d00';
    ctx.beginPath(); ctx.arc(5.4 * s, -47 * s, 1 * s, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(9 * s, -47 * s, 1 * s, 0, TAU); ctx.fill();
  } else if (bb.style === 'shark') {
    ctx.fillStyle = c;
    ctx.beginPath();
    ctx.moveTo(-2 * s, -44 * s);
    ctx.quadraticCurveTo(8 * s, -52 * s, 15 * s, -58 * s);
    ctx.quadraticCurveTo(12 * s, -46 * s, 12 * s, -38 * s);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.3)';
    ctx.beginPath(); ctx.arc(0, -36 * s, 6 * s, 0, TAU); ctx.fill();
  } else {
    ctx.fillStyle = c;
    rrect(ctx, -8 * s, -43 * s, 16 * s, 21 * s, 4 * s); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.16)';
    rrect(ctx, -5.5 * s, -40 * s, 5 * s, 14 * s, 2 * s); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,.22)';
    rrect(ctx, 0.5 * s, -41 * s, 2.4 * s, 17 * s, 1.2 * s); ctx.fill();
    ctx.fillStyle = '#2c3648';
    rrect(ctx, -5 * s, -46 * s, 4 * s, 4 * s, 1.6 * s); ctx.fill();
    rrect(ctx, 1 * s, -46 * s, 4 * s, 4 * s, 1.6 * s); ctx.fill();
  }
  ctx.restore();
}

function thirdDrawChar(f, time) {
  const alt = (f.isPlayer && game.state === 'drop') ? Math.max(0, f.z) : 0;
  const foot = thirdProject(f.x, f.y, alt * 260);
  if (!foot) return;
  const s = foot.s;
  if (s < 0.24) return;
  const sk = f.skin || SKINS[0];
  const rel = thirdWrap(f.aim - game.yaw);
  const back = Math.cos(rel) >= 0;
  const mirror = Math.sin(rel) < 0 ? -1 : 1;
  const melee = f.isPlayer ? player.melee : false;

  // shadow
  if (alt < 0.02) {
    ctx.fillStyle = 'rgba(0,0,0,.26)';
    ctx.beginPath();
    ctx.ellipse(foot.x, foot.y, 13 * s, 5 * s, 0, 0, TAU);
    ctx.fill();
  }

  ctx.save();
  ctx.translate(foot.x, foot.y);
  ctx.scale(s * mirror, s);

  // emote groove
  if (f.emoteT > 0 && f.emote && f.emote !== 'none') {
    const p = (3.4 - f.emoteT) * 7;
    if (f.emote === 'floss') ctx.translate(Math.sin(p) * 2.6, 0);
    else if (f.emote === 'groove' || f.emote === 'victory') {
      ctx.translate(0, -Math.abs(Math.sin(p)) * 4);
    } else if (f.emote === 'safari') {
      ctx.translate(Math.sin(p * 0.5) * 2.4, -Math.abs(Math.sin(p * 0.8)) * 3);
    } else if (f.emote === 'gold') {
      ctx.translate(Math.sin(p * 0.45) * 3, -Math.abs(Math.sin(p * 0.95)) * 3.4);
    }
  }

  const outfit = sk.outfit;
  const accent = sk.accent;
  const skin = sk.skin;
  const hair = sk.hair;
  const pants = sk.pants;
  const oLight = thirdShade(outfit, 0.16);
  const oDark = thirdShade(outfit, -0.2);
  const pDark = thirdShade(pants, -0.16);
  const sDark = thirdShade(skin, -0.12);

  // walking cycle
  const amp = f.walkAmp || 0;
  const gait = Math.sin((f.walkT || 0) * 13) * amp;
  const liftL = Math.max(0, gait) * 3.4;
  const liftR = Math.max(0, -gait) * 3.4;
  const bob = Math.abs(gait) * 1.2;

  // legs (alternate lift while walking)
  ctx.save();
  ctx.translate(-0.2, -liftL);
  ctx.fillStyle = pants;
  rrect(ctx, -7.4, -23, 6.8, 19, 3); ctx.fill();
  ctx.fillStyle = pDark;
  rrect(ctx, -7.4, -14, 6.8, 10, 2.6); ctx.fill();
  ctx.fillStyle = '#262b34';
  rrect(ctx, -8.2, -5.4, 7.6, 5.4, 2.4); ctx.fill();
  ctx.fillStyle = accent;
  rrect(ctx, -8.2, -6.2, 7.6, 1.6, 0.8); ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.translate(0.8, -liftR);
  ctx.fillStyle = pants;
  rrect(ctx, 0.6, -23, 6.8, 19, 3); ctx.fill();
  ctx.fillStyle = pDark;
  rrect(ctx, 0.6, -14, 6.8, 10, 2.6); ctx.fill();
  ctx.fillStyle = '#262b34';
  rrect(ctx, 0.6, -5.4, 7.6, 5.4, 2.4); ctx.fill();
  ctx.fillStyle = accent;
  rrect(ctx, 0.6, -6.2, 7.6, 1.6, 0.8); ctx.fill();
  ctx.restore();

  // upper body bobs gently with the stride
  ctx.save();
  ctx.translate(0, -bob);

  // torso (jacket)
  const tg = ctx.createLinearGradient(-11, -45, 11, -22);
  tg.addColorStop(0, oLight);
  tg.addColorStop(0.55, outfit);
  tg.addColorStop(1, oDark);
  ctx.fillStyle = tg;
  ctx.beginPath();
  ctx.moveTo(-9, -45);
  ctx.quadraticCurveTo(-12.5, -44, -12, -38);
  ctx.lineTo(-9, -22);
  ctx.quadraticCurveTo(-8, -19.5, -4, -19.5);
  ctx.lineTo(4, -19.5);
  ctx.quadraticCurveTo(8, -19.5, 9, -22);
  ctx.lineTo(12, -38);
  ctx.quadraticCurveTo(12.5, -44, 9, -45);
  ctx.quadraticCurveTo(0, -47.5, -9, -45);
  ctx.closePath();
  ctx.fill();

  // belt + buckle
  ctx.fillStyle = pDark;
  rrect(ctx, -8.6, -24, 17.2, 4.4, 1.8); ctx.fill();
  ctx.fillStyle = accent;
  rrect(ctx, -2.4, -24.2, 4.8, 4.8, 1.5); ctx.fill();

  if (fighterHasStyle(f, 'robot')) {
    // mech chassis the pilot sits inside
    const mg = ctx.createLinearGradient(-12, -46, 12, -20);
    mg.addColorStop(0, '#8fa1aa');
    mg.addColorStop(0.5, '#66767e');
    mg.addColorStop(1, '#45525a');
    ctx.fillStyle = mg;
    ctx.beginPath();
    ctx.moveTo(-11, -46);
    ctx.quadraticCurveTo(-14.5, -44, -14, -37);
    ctx.lineTo(-11, -21);
    ctx.quadraticCurveTo(-9.5, -18, -4.5, -18);
    ctx.lineTo(4.5, -18);
    ctx.quadraticCurveTo(9.5, -18, 11, -21);
    ctx.lineTo(14, -37);
    ctx.quadraticCurveTo(14.5, -44, 11, -46);
    ctx.quadraticCurveTo(0, -49, -11, -46);
    ctx.closePath(); ctx.fill();
    // chest vent + trim
    ctx.fillStyle = '#3b4750';
    rrect(ctx, -5.5, -37, 11, 8, 2.4); ctx.fill();
    ctx.fillStyle = accent;
    rrect(ctx, -4.5, -36, 9, 2.4, 1.2); ctx.fill();
    // shoulder pauldrons
    ctx.fillStyle = '#7c8d96';
    ctx.beginPath(); ctx.ellipse(-11.6, -44, 5.4, 4.2, -0.2, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(11.6, -44, 5.4, 4.2, 0.2, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.22)';
    ctx.beginPath(); ctx.ellipse(-12.2, -45.4, 3, 1.8, -0.3, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(11, -45.4, 3, 1.8, 0.3, 0, TAU); ctx.fill();
  }

  if (back) {
    thirdDrawBackbling(f, s);
    // jacket back seam + collar
    ctx.strokeStyle = 'rgba(0,0,0,.22)';
    ctx.lineWidth = 1.1;
    ctx.beginPath(); ctx.moveTo(0, -43); ctx.lineTo(0, -25); ctx.stroke();
    ctx.fillStyle = oDark;
    ctx.beginPath();
    ctx.moveTo(-8, -45); ctx.lineTo(0, -39.5); ctx.lineTo(8, -45);
    ctx.lineTo(7, -47); ctx.lineTo(0, -42); ctx.lineTo(-7, -47);
    ctx.closePath(); ctx.fill();
  } else {
    // jacket opening + zipper
    ctx.fillStyle = oLight;
    ctx.beginPath();
    ctx.moveTo(-2.4, -45); ctx.lineTo(-7.6, -42);
    ctx.lineTo(-6.4, -27); ctx.lineTo(-1.6, -25);
    ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(2.4, -45); ctx.lineTo(7.6, -42);
    ctx.lineTo(6.4, -27); ctx.lineTo(1.6, -25);
    ctx.closePath(); ctx.fill();
    ctx.strokeStyle = accent;
    ctx.lineWidth = 1.3;
    ctx.beginPath(); ctx.moveTo(0, -42); ctx.lineTo(0, -25); ctx.stroke();
    // chest emblem
    ctx.fillStyle = accent;
    ctx.beginPath(); ctx.arc(-4.6, -37, 2.4, 0, TAU); ctx.fill();
  }

  // arms
  ctx.strokeStyle = outfit;
  ctx.lineWidth = 5.6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(-9.5, -42); ctx.quadraticCurveTo(-13.5, -34, -13, -26);
  ctx.moveTo(9.5, -42); ctx.quadraticCurveTo(13.4, -34, 13, -27);
  ctx.stroke();
  ctx.strokeStyle = oLight;
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(-11, -38); ctx.quadraticCurveTo(-12.6, -33, -12.4, -29);
  ctx.moveTo(11, -38); ctx.quadraticCurveTo(12.6, -33, 12.4, -29);
  ctx.stroke();
  // hands
  ctx.fillStyle = sDark;
  ctx.beginPath(); ctx.arc(-13, -24.5, 2.9, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.arc(13, -25.5, 2.9, 0, TAU); ctx.fill();
  // gloves
  ctx.fillStyle = '#2b313c';
  ctx.beginPath(); ctx.arc(-13, -24.5, 2.2, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.arc(13, -25.5, 2.2, 0, TAU); ctx.fill();

  if (fighterHasStyle(f, 'robot')) {
    // mech arms + elbows over the pilot's arms
    ctx.strokeStyle = '#66767e';
    ctx.lineWidth = 6.8; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-9.5, -42); ctx.quadraticCurveTo(-13.5, -34, -13, -26);
    ctx.moveTo(9.5, -42); ctx.quadraticCurveTo(13.4, -34, 13, -27);
    ctx.stroke();
    ctx.fillStyle = '#3b4750';
    ctx.beginPath(); ctx.arc(-13, -33, 2.4, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(13, -33.4, 2.4, 0, TAU); ctx.fill();
    ctx.fillStyle = '#8fa1aa';
    ctx.beginPath(); ctx.arc(-13, -24.5, 3.4, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(13, -25.5, 3.4, 0, TAU); ctx.fill();
    // control levers in the cockpit
    if (!back) {
      ctx.strokeStyle = '#2f3a40'; ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(-4, -28); ctx.lineTo(-2.2, -34.4);
      ctx.moveTo(4, -28); ctx.lineTo(2.2, -34.4);
      ctx.stroke();
      ctx.fillStyle = accent;
      ctx.beginPath(); ctx.arc(-2.2, -34.6, 1.3, 0, TAU); ctx.fill();
      ctx.beginPath(); ctx.arc(2.2, -34.6, 1.3, 0, TAU); ctx.fill();
    }
  }

  // neck + head
  ctx.fillStyle = sDark;
  rrect(ctx, -3.2, -49, 6.4, 5, 2); ctx.fill();
  const hg = ctx.createRadialGradient(-2.4, -58, 1, 0, -55.5, 10);
  hg.addColorStop(0, thirdShade(skin, 0.12));
  hg.addColorStop(0.7, skin);
  hg.addColorStop(1, sDark);
  ctx.fillStyle = hg;
  ctx.beginPath(); ctx.ellipse(0, -55.5, 8.2, 9, 0, 0, TAU); ctx.fill();
  // ears
  ctx.fillStyle = sDark;
  ctx.beginPath(); ctx.ellipse(-8.1, -55, 1.7, 2.6, 0, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(8.1, -55, 1.7, 2.6, 0, 0, TAU); ctx.fill();

  if (back) {
    // hair from behind
    ctx.fillStyle = hair;
    ctx.beginPath();
    ctx.ellipse(0, -56.6, 8.6, 9.4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-8.2, -56);
    ctx.quadraticCurveTo(-7.4, -48.5, -3.4, -47.2);
    ctx.lineTo(3.4, -47.2);
    ctx.quadraticCurveTo(7.4, -48.5, 8.2, -56);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.14)';
    ctx.beginPath(); ctx.ellipse(-3, -60, 4, 3.4, -0.5, 0, TAU); ctx.fill();
    if (sk.hairStyle === 'spiky') {
      ctx.fillStyle = hair;
      ctx.beginPath();
      ctx.moveTo(-8.4, -58);
      ctx.lineTo(-7.2, -68.4); ctx.lineTo(-4.4, -62);
      ctx.lineTo(-2.2, -69.6); ctx.lineTo(0.6, -63);
      ctx.lineTo(3.4, -68.8); ctx.lineTo(5.2, -62.4);
      ctx.lineTo(8.4, -67.2); ctx.lineTo(8.6, -57.6);
      ctx.closePath(); ctx.fill();
    }
    if (fighterHasStyle(f, 'patch')) {
      ctx.strokeStyle = '#22262b';
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(-8.2, -57.4);
      ctx.quadraticCurveTo(0, -54.6, 8.2, -57.4);
      ctx.stroke();
    }
  } else {
    // face
    ctx.fillStyle = hair;
    ctx.beginPath();
    ctx.moveTo(-8.4, -57);
    ctx.quadraticCurveTo(-7.5, -66, 0, -65.5);
    ctx.quadraticCurveTo(7.5, -66, 8.4, -57);
    ctx.quadraticCurveTo(5.5, -61, 0, -61.6);
    ctx.quadraticCurveTo(-5.5, -61, -8.4, -57);
    ctx.closePath(); ctx.fill();
    if (sk.hairStyle === 'spiky') {
      ctx.beginPath();
      ctx.moveTo(-8.4, -60);
      ctx.lineTo(-7.6, -69); ctx.lineTo(-4.6, -63.2);
      ctx.lineTo(-2.6, -70.4); ctx.lineTo(0.4, -64);
      ctx.lineTo(3.2, -69.8); ctx.lineTo(5.2, -63);
      ctx.lineTo(8.4, -67.4); ctx.lineTo(8.4, -58.6);
      ctx.quadraticCurveTo(4, -63.6, 0, -63.4);
      ctx.quadraticCurveTo(-4.6, -63.4, -8.4, -58.6);
      ctx.closePath(); ctx.fill();
    }
    // brows
    ctx.strokeStyle = thirdShade(hair, -0.15);
    ctx.lineWidth = 1.2;
    ctx.beginPath(); ctx.moveTo(-5.4, -57.6); ctx.lineTo(-2.2, -58); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(2.2, -58); ctx.lineTo(5.4, -57.6); ctx.stroke();
    // eyes
    ctx.fillStyle = '#1d2634';
    ctx.beginPath(); ctx.ellipse(-3.8, -55.6, 1.5, 1.7, 0, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(3.8, -55.6, 1.5, 1.7, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.8)';
    ctx.beginPath(); ctx.arc(-4.3, -56.2, 0.5, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(3.3, -56.2, 0.5, 0, TAU); ctx.fill();
    if (fighterHasStyle(f, 'patch')) {
      // strap around the head + patch over the left eye
      ctx.strokeStyle = '#22262b';
      ctx.lineWidth = 1.3;
      ctx.beginPath(); ctx.moveTo(-8.2, -58.6); ctx.lineTo(-4.4, -55.8); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-3.2, -55.8); ctx.lineTo(7.9, -58.4); ctx.stroke();
      ctx.fillStyle = '#1c2025';
      ctx.beginPath(); ctx.ellipse(-3.8, -55.6, 3.5, 3.1, -0.1, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.22)';
      ctx.beginPath(); ctx.ellipse(-4.6, -56.6, 1.1, 0.8, -0.3, 0, TAU); ctx.fill();
    }
    // nose + mouth
    ctx.strokeStyle = sDark;
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(0, -55.4); ctx.lineTo(-0.7, -52.8); ctx.stroke();
    ctx.strokeStyle = thirdShade(skin, -0.34);
    ctx.beginPath(); ctx.moveTo(-2.4, -50.8); ctx.quadraticCurveTo(0, -49.6, 2.4, -50.8); ctx.stroke();
    // jaw light
    ctx.fillStyle = 'rgba(255,255,255,.10)';
    ctx.beginPath(); ctx.ellipse(2.8, -58.8, 2.2, 1.4, -0.4, 0, TAU); ctx.fill();
  }

  if (fighterHasStyle(f, 'robot')) {
    // cockpit glass dome over the pilot
    ctx.strokeStyle = 'rgba(207,221,229,.92)';
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(0, -55.5, 10.7, 0, TAU); ctx.stroke();
    ctx.strokeStyle = 'rgba(120,215,255,.6)';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(0, -55.5, 9.6, -2.3, -0.8); ctx.stroke();
  }

  // pickaxe + weapon
  thirdDrawPickaxe(f, s, back, f.isPlayer && melee);
  if (!(f.isPlayer && melee)) thirdDrawRifle(f, s, back);

  // shoulder pads
  ctx.fillStyle = accent;
  ctx.beginPath(); ctx.ellipse(-9.4, -43.6, 3.4, 2.4, -0.35, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.ellipse(9.4, -43.6, 3.4, 2.4, 0.35, 0, TAU); ctx.fill();
  ctx.restore();

  // hit flash
  if (f.hitFlash > 0) {
    ctx.globalAlpha = Math.min(0.5, f.hitFlash * 3.2);
    ctx.fillStyle = '#fff';
    rrect(ctx, -13, -63, 26, 60, 8); ctx.fill();
    ctx.globalAlpha = 1;
  }
  ctx.restore();

  // glider above skydiving player
  if (alt > 0.02) {
    const gl = f.glider || GLIDERS[0];
    const gy = foot.y - 68 * s - alt * 40 * s;
    ctx.save();
    ctx.fillStyle = gl.canopy;
    ctx.beginPath(); ctx.ellipse(foot.x, gy, 46 * s, 15 * s, 0, Math.PI, TAU); ctx.fill();
    ctx.strokeStyle = gl.stripe; ctx.lineWidth = Math.max(1, 2 * s);
    ctx.beginPath(); ctx.ellipse(foot.x, gy, 46 * s, 15 * s, 0, Math.PI, TAU); ctx.stroke();
    ctx.strokeStyle = 'rgba(230,240,255,.65)';
    ctx.lineWidth = Math.max(1, 1.2 * s);
    ctx.beginPath();
    ctx.moveTo(foot.x - 38 * s, gy); ctx.lineTo(foot.x - 10 * s, foot.y - 62 * s);
    ctx.moveTo(foot.x + 38 * s, gy); ctx.lineTo(foot.x + 10 * s, foot.y - 62 * s);
    ctx.stroke();
    ctx.restore();
  }

  // nameplate
  if (!f.isPlayer && player && s > 0.55) {
    const d = dist(f.x, f.y, player.x, player.y);
    if (d < 850) {
      const ty = foot.y - 69 * s;
      ctx.textAlign = 'center';
      ctx.font = '700 11px "Segoe UI", system-ui, sans-serif';
      ctx.fillStyle = 'rgba(0,0,0,.55)';
      ctx.fillText(f.name, foot.x + 1, ty + 1);
      ctx.fillStyle = 'rgba(230,240,255,.92)';
      ctx.fillText(f.name, foot.x, ty);
      if (f.hp < 100 || f.shield > 0) {
        const bw = 42, bx = foot.x - bw / 2, by = ty + 4;
        ctx.fillStyle = 'rgba(0,0,0,.55)';
        ctx.fillRect(bx - 1, by - 1, bw + 2, 6);
        ctx.fillStyle = '#4be07a';
        ctx.fillRect(bx, by, bw * clamp(f.hp / 100, 0, 1), 4);
        if (f.shield > 0) {
          ctx.fillStyle = '#4fb7ff';
          ctx.fillRect(bx, by - 4, bw * clamp(f.shield / 100, 0, 1), 2.5);
        }
      }
    }
  }
}

/* --------------------------- scene list -------------------------- */
function thirdCollect(time) {
  const list = T3.list;
  list.length = 0;

  // fighters
  for (const f of fighters) {
    if (!f.alive) continue;
    const cz = thirdDepth(f.x, f.y);
    if (cz < 12 || cz > 1700 || !thirdInView(f.x, f.y, cz)) continue;
    list.push({ kind: 'fighter', f: f, cz: cz });
  }

  // trees / rocks
  for (const tr of world.trees) {
    if (tr.dead) continue;
    const cz = thirdDepth(tr.x, tr.y);
    if (cz < 15 || cz > 1550 || !thirdInView(tr.x, tr.y, cz)) continue;
    list.push({ kind: 'tree', o: tr, cz: cz });
  }
  for (const rk of world.rocks) {
    const cz = thirdDepth(rk.x, rk.y);
    if (cz < 15 || cz > 1350 || !thirdInView(rk.x, rk.y, cz)) continue;
    list.push({ kind: 'rock', o: rk, cz: cz });
  }
  for (const c of world.crates) {
    if (c.opened) continue;
    const cz = thirdDepth(c.x, c.y);
    if (cz < 15 || cz > 1150 || !thirdInView(c.x, c.y, cz)) continue;
    list.push({ kind: 'crate', o: c, cz: cz });
  }
  for (const ch of world.chests) {
    const cz = thirdDepth(ch.x, ch.y);
    if (cz < 15 || cz > 1250 || !thirdInView(ch.x, ch.y, cz)) continue;
    list.push({ kind: 'chest', o: ch, cz: cz });
  }
  for (const sp of world.supplies) {
    const cz = thirdDepth(sp.x, sp.y);
    if (cz < 15 || cz > 1600 || !thirdInView(sp.x, sp.y, cz)) continue;
    list.push({ kind: 'chest', o: sp, cz: cz });
  }
  for (const it of world.loot) {
    const cz = thirdDepth(it.x, it.y);
    if (cz < 14 || cz > 900 || !thirdInView(it.x, it.y, cz)) continue;
    list.push({ kind: 'loot', o: it, cz: cz });
  }

  // walls
  for (const w of world.walls) {
    if (w.dead) continue;
    const mx = (w.ax + w.bx) * 0.5, my = (w.ay + w.by) * 0.5;
    const cz = thirdDepth(mx, my);
    if (cz < 14 || cz > 1750 || !thirdInView(mx, my, cz)) continue;
    const h = w.kind === 'built' ? 70 : 86;
    const a0 = thirdProject(w.ax, w.ay, 0);
    const b0 = thirdProject(w.bx, w.by, 0);
    const a1 = thirdProject(w.ax, w.ay, h);
    const b1 = thirdProject(w.bx, w.by, h);
    if (!a0 || !b0 || !a1 || !b1) continue;
    const axial = Math.abs(w.ax - w.bx) < Math.abs(w.ay - w.by);
    list.push({
      kind: 'wall', cz: (a0.cz + b0.cz) * 0.5, h: h, axial: axial,
      x0: a0.x, y0: a0.y, x1: b0.x, y1: b0.y,
      x2: b1.x, y2: b1.y, x3: a1.x, y3: a1.y
    });
  }

  // roofs
  for (const b of world.buildings) {
    const cz = thirdDepth(b.cx, b.cy);
    if (cz < 20 || cz > 1900 || !thirdInView(b.cx, b.cy, cz)) continue;
    const inside = player && player.alive && insideAnyBuilding(player.x, player.y, 0);
    const z = 90;
    const p0 = thirdProject(b.x0, b.y0, z);
    const p1 = thirdProject(b.x1, b.y0, z);
    const p2 = thirdProject(b.x1, b.y1, z);
    const p3 = thirdProject(b.x0, b.y1, z);
    if (!p0 || !p1 || !p2 || !p3) continue;
    list.push({
      kind: 'roof', cz: cz, alpha: inside ? 0.16 : 0.94, color: b.color,
      pts: [p0, p1, p2, p3]
    });
  }

  list.sort((a, b) => b.cz - a.cz);

  for (const it of list) {
    if (it.kind === 'fighter') thirdDrawChar(it.f, time);
    else if (it.kind === 'tree') thirdDrawTree(it.o, time);
    else if (it.kind === 'rock') thirdDrawRock(it.o);
    else if (it.kind === 'crate') thirdDrawCrate(it.o);
    else if (it.kind === 'chest') thirdDrawChest(it.o, time);
    else if (it.kind === 'loot') thirdDrawLoot(it.o, time);
    else if (it.kind === 'wall') thirdDrawWallQuad(it);
    else if (it.kind === 'roof') thirdDrawRoof(it);
  }
}

function thirdDrawWallQuad(q) {
  const base = q.axial ? '#8b7a63' : '#7d6d58';
  if (q.h < 80) {
    ctx.fillStyle = '#a97b45';
  } else {
    ctx.fillStyle = base;
  }
  ctx.beginPath();
  ctx.moveTo(q.x0, q.y0);
  ctx.lineTo(q.x1, q.y1);
  ctx.lineTo(q.x2, q.y2);
  ctx.lineTo(q.x3, q.y3);
  ctx.closePath();
  ctx.fill();
  // top + base trim
  ctx.strokeStyle = q.h < 80 ? '#c99a5a' : '#b9a88c';
  ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(q.x3, q.y3); ctx.lineTo(q.x2, q.y2); ctx.stroke();
  ctx.strokeStyle = 'rgba(0,0,0,.28)';
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(q.x0, q.y0); ctx.lineTo(q.x1, q.y1); ctx.stroke();
  // faint windows
  ctx.fillStyle = 'rgba(28,40,60,.35)';
  const mx0 = (q.x0 + q.x1) * 0.5, mx1 = (q.x3 + q.x2) * 0.5;
  const my0 = (q.y0 + q.y1) * 0.5, my1 = (q.y3 + q.y2) * 0.5;
  ctx.beginPath();
  ctx.ellipse(mx0, (my0 + my1) * 0.52, Math.max(2, Math.abs(mx1 - mx0) * 0.16), Math.max(2, Math.abs(my1 - my0) * 0.16), 0, 0, TAU);
  ctx.fill();
}

function thirdDrawRoof(r) {
  const p = r.pts;
  ctx.globalAlpha = r.alpha;
  ctx.fillStyle = thirdShade(r.color, 0.18);
  ctx.beginPath();
  ctx.moveTo(p[0].x, p[0].y);
  for (let i = 1; i < p.length; i++) ctx.lineTo(p[i].x, p[i].y);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = 'rgba(30,22,14,.45)';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.fillStyle = 'rgba(255,240,210,.18)';
  ctx.beginPath();
  ctx.moveTo(p[0].x, p[0].y); ctx.lineTo(p[1].x, p[1].y);
  ctx.lineTo(p[1].x + (p[2].x - p[1].x) * 0.12, p[1].y + (p[2].y - p[1].y) * 0.12);
  ctx.lineTo(p[0].x + (p[3].x - p[0].x) * 0.12, p[0].y + (p[3].y - p[0].y) * 0.12);
  ctx.closePath(); ctx.fill();
  ctx.globalAlpha = 1;
}

/* ------------------------- bullets / FX -------------------------- */
function thirdDrawBullets() {
  for (const b of bullets) {
    const p = thirdProject(b.x, b.y, 42);
    if (!p || p.cz > 1400) continue;
    const p2 = thirdProject(b.x - b.vx * 0.022, b.y - b.vy * 0.022, 42);
    ctx.strokeStyle = b.color;
    ctx.lineWidth = Math.min(4, Math.max(1.4, 1.9 * p.s));
    ctx.globalAlpha = 0.85;
    ctx.beginPath();
    if (p2) { ctx.moveTo(p2.x, p2.y); ctx.lineTo(p.x, p.y); }
    else { ctx.moveTo(p.x - 4, p.y); ctx.lineTo(p.x + 4, p.y); }
    ctx.stroke();
    ctx.globalAlpha = 1;
    ctx.fillStyle = b.color;
    ctx.beginPath(); ctx.arc(p.x, p.y, Math.min(5, 1.7 * p.s), 0, TAU); ctx.fill();
  }
}

function thirdDrawParticles() {
  for (const pa of particles) {
    const p = thirdProject(pa.x, pa.y, pa.z != null ? pa.z : 26);
    if (!p || p.cz > 1200) continue;
    ctx.globalAlpha = Math.max(0, pa.life / pa.max);
    ctx.fillStyle = pa.color;
    const r = Math.max(1, pa.size * p.s * 0.55);
    ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, TAU); ctx.fill();
  }
  ctx.globalAlpha = 1;
}

function thirdDrawTexts() {
  for (const t of texts) {
    const p = thirdProject(t.x, t.y, 74);
    if (!p || p.cz > 900) continue;
    ctx.globalAlpha = Math.max(0, Math.min(1, t.life / t.max * 1.6));
    ctx.textAlign = 'center';
    ctx.font = '800 ' + Math.round(clamp(t.size * p.s * 0.9, 10, 26)) + 'px "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = 'rgba(0,0,0,.6)';
    ctx.fillText(t.text, p.x + 1, p.y + 2);
    ctx.fillStyle = t.color;
    ctx.fillText(t.text, p.x, p.y);
  }
  ctx.globalAlpha = 1;
}

/* ----------------------------- entry ----------------------------- */
function renderThirdPerson(time) {
  thirdEnsure();
  thirdCamera();

  const sh = game.shake || 0;
  T3.ox = sh ? rnd(-sh, sh) * 0.6 : 0;
  T3.oy = sh ? rnd(-sh, sh) * 0.6 : 0;

  thirdRenderGround();

  ctx.save();
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(T3.buf, T3.ox, T3.oy, viewW, viewH);
  ctx.restore();

  ctx.save();
  ctx.translate(T3.ox, T3.oy);
  thirdDrawStormWall(time);
  thirdCollect(time);
  thirdDrawBullets();
  thirdDrawParticles();
  thirdDrawTexts();
  ctx.restore();
}
