'use strict';
/* ==================================================================
   STORM ROYALE — camera + all drawing
   ================================================================== */

function hexA(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
}

function rrect(c, x, y, w, h, r) {
  c.beginPath();
  if (c.roundRect) { c.roundRect(x, y, w, h, r); return; }
  c.moveTo(x + r, y);
  c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r);
  c.closePath();
}

/* ----------------------------- camera ---------------------------- */
function updateCamera(dt) {
  if (game.state === 'menu') {
    game.menuT += dt;
    game.camX = HALF + Math.sin(game.menuT * 0.07) * 320;
    game.camY = HALF + Math.cos(game.menuT * 0.055) * 260;
    game.camZoom = Math.max(0.5, Math.max(viewW, viewH) / WORLD) * 0.92;
    clampCamera();
    return;
  }
  if (!player) return;

  let target = 1;
  if (game.state === 'drop') {
    target = Math.max(0.56, Math.max(viewW, viewH) / WORLD * 1.04);
  } else if (mouse.right) {
    const w = player.weapons[player.slot];
    target = w && w.kind === 'sniper' ? 1.34 : 1.12;
  }
  const k = 1 - Math.pow(0.0006, dt);
  game.camZoom = lerp(game.camZoom, target, k);

  const lookX = game.state === 'drop' ? 0 : clamp((mouse.x - viewW / 2) / Math.max(0.4, game.camZoom) * 0.16, -140, 140);
  const lookY = game.state === 'drop' ? 0 : clamp((mouse.y - viewH / 2) / Math.max(0.4, game.camZoom) * 0.16, -140, 140);
  const follow = 1 - Math.pow(0.00008, dt);
  game.camX = lerp(game.camX, player.x + lookX, follow);
  game.camY = lerp(game.camY, player.y + lookY, follow);
  clampCamera();
}

function clampCamera() {
  const hw = viewW / (2 * game.camZoom);
  const hh = viewH / (2 * game.camZoom);
  game.camX = hw * 2 >= WORLD ? HALF : clamp(game.camX, hw, WORLD - hw);
  game.camY = hh * 2 >= WORLD ? HALF : clamp(game.camY, hh, WORLD - hh);
}

/* ----------------------------- render ---------------------------- */
function render() {
  const w = viewW, h = viewH;
  const time = performance.now() / 1000;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  if (game.view === 'third' && player && game.state !== 'menu') {
    renderThirdPerson(time);
    if (storm && player && player.alive) {
      const d = dist(player.x, player.y, storm.x, storm.y);
      if (d > storm.r) {
        const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.22, w / 2, h / 2, Math.max(w, h) * 0.72);
        g.addColorStop(0, 'rgba(120,30,200,.05)');
        g.addColorStop(1, 'rgba(120,30,200,.44)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, w, h);
      }
    }
    if (storm) drawMinimap();
    return;
  }

  const sh = game.shake || 0;
  const shx = sh ? rnd(-sh, sh) : 0;
  const shy = sh ? rnd(-sh, sh) : 0;

  ctx.save();
  ctx.translate(w / 2 + shx, h / 2 + shy);
  ctx.scale(game.camZoom, game.camZoom);
  ctx.translate(-game.camX, -game.camY);

  const view = {
    x0: game.camX - w / (2 * game.camZoom) - 120,
    y0: game.camY - h / (2 * game.camZoom) - 120,
    x1: game.camX + w / (2 * game.camZoom) + 120,
    y1: game.camY + h / (2 * game.camZoom) + 120
  };

  if (terrain) ctx.drawImage(terrain, 0, 0, WORLD, WORLD);
  else { ctx.fillStyle = '#3d8a4b'; ctx.fillRect(0, 0, WORLD, WORLD); }

  drawFloors(view);
  drawGroundLoot(view, time);
  drawWalls(view);
  drawDepth(view, time);
  drawBullets();
  drawParticles();
  if (storm) drawStormOverlay(view, time);
  drawTexts();

  ctx.restore();

  // storm tint when the player is outside the circle
  if (storm && player && player.alive && game.state !== 'menu') {
    const d = dist(player.x, player.y, storm.x, storm.y);
    if (d > storm.r) {
      const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.25, w / 2, h / 2, Math.max(w, h) * 0.72);
      g.addColorStop(0, 'rgba(120,30,200,0)');
      g.addColorStop(1, 'rgba(120,30,200,.4)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
    }
  }

  if (storm && player && game.state !== 'menu') drawMinimap();
}

/* --------------------------- buildings --------------------------- */
function drawFloors(view) {
  for (const b of world.buildings) {
    if (b.x1 < view.x0 || b.x0 > view.x1 || b.y1 < view.y0 || b.y0 > view.y1) continue;
    ctx.fillStyle = b.color;
    rrect(ctx, b.x0, b.y0, b.x1 - b.x0, b.y1 - b.y0, 8); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 4; ctx.stroke();
    ctx.fillStyle = 'rgba(0,0,0,.12)';
    rrect(ctx, b.x0 + 14, b.y0 + 14, b.x1 - b.x0 - 28, b.y1 - b.y0 - 28, 4); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,.07)'; ctx.lineWidth = 2;
    for (let y = b.y0 + 34; y < b.y1 - 10; y += 34) {
      ctx.beginPath(); ctx.moveTo(b.x0 + 14, y); ctx.lineTo(b.x1 - 14, y); ctx.stroke();
    }
  }
}

function drawWalls(view) {
  ctx.lineCap = 'round';
  for (const w of world.walls) {
    if (w.dead) continue;
    if (w.maxX < view.x0 || w.minX > view.x1 || w.maxY < view.y0 || w.minY > view.y1) continue;
    const thick = w.r * 2;
    ctx.beginPath(); ctx.moveTo(w.ax, w.ay); ctx.lineTo(w.bx, w.by);
    ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = thick + 7; ctx.stroke();

    let col;
    if (w.kind === 'built') {
      const ratio = clamp(w.hp / w.maxHp, 0, 1);
      col = 'hsl(28, 52%, ' + (26 + ratio * 22) + '%)';
    } else {
      col = '#b6a184';
    }
    ctx.beginPath(); ctx.moveTo(w.ax, w.ay); ctx.lineTo(w.bx, w.by);
    ctx.strokeStyle = col; ctx.lineWidth = thick; ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,.13)'; ctx.lineWidth = thick * 0.34; ctx.stroke();

    if (w.kind === 'built') {
      ctx.strokeStyle = 'rgba(30,18,8,.35)';
      ctx.lineWidth = 2;
      const len = dist(w.ax, w.ay, w.bx, w.by);
      const ux = (w.bx - w.ax) / len, uy = (w.by - w.ay) / len;
      for (let d = 12; d < len; d += 26) {
        ctx.beginPath();
        ctx.moveTo(w.ax + ux * d, w.ay + uy * d);
        ctx.lineTo(w.ax + ux * d + ux * 6, w.ay + uy * d + uy * 6);
        ctx.stroke();
      }
    }
    if (w.hitFlash > 0) {
      ctx.beginPath(); ctx.moveTo(w.ax, w.ay); ctx.lineTo(w.bx, w.by);
      ctx.strokeStyle = 'rgba(255,255,255,' + Math.min(0.8, w.hitFlash * 5) + ')';
      ctx.lineWidth = thick; ctx.stroke();
    }
  }
}

/* -------------------------- depth layer -------------------------- */
function drawDepth(view, time) {
  const list = [];
  const inView = (x, y, pad) => x > view.x0 - pad && x < view.x1 + pad && y > view.y0 - pad && y < view.y1 + pad;

  for (const o of world.trees) {
    if (o.dead) continue;
    if (!inView(o.x, o.y, 70)) continue;
    list.push({ y: o.y, t: 0, o });
  }
  for (const o of world.rocks) {
    if (!inView(o.x, o.y, 70)) continue;
    list.push({ y: o.y, t: 1, o });
  }
  for (const o of world.crates) {
    if (!inView(o.x, o.y, 60)) continue;
    list.push({ y: o.y, t: 2, o });
  }
  for (const o of world.chests) {
    if (!inView(o.x, o.y, 70)) continue;
    list.push({ y: o.y, t: 3, o });
  }
  for (const o of world.supplies) {
    if (!inView(o.x, o.y, 120)) continue;
    list.push({ y: o.y, t: 4, o });
  }
  for (const f of fighters) {
    if (!f.alive) continue;
    if (!inView(f.x, f.y, 120)) continue;
    list.push({ y: f.y, t: 5, o: f });
  }
  list.sort((a, b) => a.y - b.y);

  for (const item of list) {
    if (item.t === 0) drawTree(item.o, time);
    else if (item.t === 1) drawRock(item.o);
    else if (item.t === 2) drawCrate(item.o);
    else if (item.t === 3) drawChest(item.o, time);
    else if (item.t === 4) drawSupply(item.o, time);
    else drawFighter(item.o, time);
  }
}

function drawTree(o, time) {
  const sway = Math.sin(time * 1.3 + o.seed) * 2.2;
  const r = o.r * o.scale;
  ctx.fillStyle = 'rgba(0,0,0,.22)';
  ctx.beginPath(); ctx.ellipse(o.x + 8, o.y + 10, r * 0.95, r * 0.5, 0, 0, TAU); ctx.fill();

  ctx.fillStyle = '#6b4a2b';
  ctx.beginPath(); ctx.arc(o.x + sway * 0.25, o.y + 2, r * 0.24, 0, TAU); ctx.fill();

  ctx.fillStyle = '#5d7a34';
  ctx.beginPath(); ctx.arc(o.x - r * 0.3 + sway, o.y - r * 0.18, r * 0.72, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.arc(o.x + r * 0.36 + sway, o.y - r * 0.1, r * 0.62, 0, TAU); ctx.fill();
  ctx.fillStyle = '#7f963c';
  ctx.beginPath(); ctx.arc(o.x - r * 0.06 + sway, o.y - r * 0.42, r * 0.7, 0, TAU); ctx.fill();
  ctx.fillStyle = '#9cae4e';
  ctx.beginPath(); ctx.arc(o.x - r * 0.22 + sway * 1.3, o.y - r * 0.55, r * 0.42, 0, TAU); ctx.fill();
  ctx.fillStyle = 'rgba(220,232,150,.35)';
  ctx.beginPath(); ctx.arc(o.x - r * 0.36 + sway * 1.4, o.y - r * 0.66, r * 0.22, 0, TAU); ctx.fill();
}

function drawRock(o) {
  ctx.fillStyle = 'rgba(0,0,0,.22)';
  ctx.beginPath(); ctx.ellipse(o.x + 6, o.y + 8, o.r * 0.95, o.r * 0.5, 0, 0, TAU); ctx.fill();
  ctx.beginPath();
  for (let k = 0; k < 7; k++) {
    const a = o.seed + (k / 7) * TAU;
    const rr = o.r * (0.82 + 0.22 * Math.sin(k * 2.1 + o.seed));
    const px = o.x + Math.cos(a) * rr, py = o.y + Math.sin(a) * rr * 0.85;
    if (k === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.fillStyle = '#8b9199'; ctx.fill();
  ctx.strokeStyle = 'rgba(30,36,44,.55)'; ctx.lineWidth = 3; ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,.18)';
  ctx.beginPath(); ctx.ellipse(o.x - o.r * 0.25, o.y - o.r * 0.3, o.r * 0.42, o.r * 0.26, o.seed, 0, TAU); ctx.fill();
}

function drawCrate(o) {
  ctx.save();
  ctx.translate(o.x, o.y);
  ctx.rotate(o.rot);
  ctx.fillStyle = 'rgba(0,0,0,.22)';
  ctx.fillRect(-18, -12, 40, 34);
  ctx.fillStyle = o.opened ? '#4c3a24' : '#7a5a30';
  rrect(ctx, -19, -19, 38, 38, 4); ctx.fill();
  ctx.strokeStyle = 'rgba(20,12,4,.55)'; ctx.lineWidth = 3; ctx.stroke();
  if (!o.opened) {
    ctx.strokeStyle = '#a8804a'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(-15, -15); ctx.lineTo(15, 15); ctx.moveTo(15, -15); ctx.lineTo(-15, 15); ctx.stroke();
    ctx.fillStyle = 'rgba(255,220,150,.15)'; rrect(ctx, -14, -14, 28, 28, 3); ctx.fill();
  }
  ctx.restore();
}

function drawChest(ch, time) {
  const pulse = 0.5 + 0.5 * Math.sin(time * 3 + ch.pulse);
  if (!ch.opened) {
    const g = ctx.createRadialGradient(ch.x, ch.y, 3, ch.x, ch.y, 52);
    g.addColorStop(0, 'rgba(255,200,70,.30)');
    g.addColorStop(1, 'rgba(255,200,70,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(ch.x, ch.y, 52, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(255,214,90,' + (0.25 + pulse * 0.3) + ')';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(ch.x, ch.y, 22 + pulse * 10, 0, TAU); ctx.stroke();
  }
  ctx.fillStyle = 'rgba(0,0,0,.25)';
  ctx.beginPath(); ctx.ellipse(ch.x + 3, ch.y + 10, 22, 11, 0, 0, TAU); ctx.fill();

  ctx.save();
  ctx.translate(ch.x, ch.y);
  ctx.fillStyle = ch.opened ? '#7a5a24' : '#c9962e';
  rrect(ctx, -18, -14, 36, 27, 4); ctx.fill();
  ctx.strokeStyle = 'rgba(40,24,0,.6)'; ctx.lineWidth = 3; ctx.stroke();
  if (ch.opened) {
    ctx.fillStyle = '#2f2513';
    rrect(ctx, -14, -10, 28, 18, 3); ctx.fill();
    ctx.fillStyle = '#8a6a2a';
    rrect(ctx, -19, -30, 38, 9, 3); ctx.fill();
  } else {
    ctx.fillStyle = '#f0c65a';
    rrect(ctx, -18, -7, 36, 8, 3); ctx.fill();
    ctx.fillStyle = '#6b4a10';
    ctx.beginPath(); ctx.arc(0, 1, 4, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.4)';
    ctx.fillRect(-16, -12, 32, 3);
  }
  ctx.restore();
}

function drawSupply(s, time) {
  const lift = s.z * 240;
  const baseY = s.y;
  const y = s.y - lift;
  ctx.fillStyle = 'rgba(0,0,0,' + (0.25 - s.z * 0.12) + ')';
  ctx.beginPath(); ctx.ellipse(s.x, baseY + 12, 24 * (1 - s.z * 0.3), 12 * (1 - s.z * 0.3), 0, 0, TAU); ctx.fill();

  if (s.z > 0) {
    const cy = y - 62;
    ctx.strokeStyle = 'rgba(220,235,255,.7)'; ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(s.x - 18, y - 12); ctx.lineTo(s.x - 34, cy + 12);
    ctx.moveTo(s.x + 18, y - 12); ctx.lineTo(s.x + 34, cy + 12);
    ctx.stroke();
    ctx.fillStyle = '#dfe9ff';
    ctx.beginPath(); ctx.ellipse(s.x, cy, 50, 24, 0, Math.PI, TAU); ctx.fill();
    ctx.strokeStyle = '#9fb4d8'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(s.x, cy, 50, 24, 0, Math.PI, TAU); ctx.stroke();
    ctx.fillStyle = '#b7c9ea';
    ctx.beginPath(); ctx.ellipse(s.x, cy, 26, 12, 0, Math.PI, TAU); ctx.fill();
  }

  // smoke puffs
  if (!s.opened) {
    for (let i = 0; i < 3; i++) {
      const a = time * 0.8 + i * 2.1;
      ctx.fillStyle = 'rgba(120,200,255,' + (0.10 + i * 0.03) + ')';
      ctx.beginPath();
      ctx.arc(s.x + Math.sin(a) * 18, y - 12 - ((time * 22 + i * 20) % 60), 12 + i * 4, 0, TAU);
      ctx.fill();
    }
  }

  ctx.save();
  ctx.translate(s.x, y);
  ctx.fillStyle = 'rgba(0,0,0,.25)';
  ctx.fillRect(-19, -15, 42, 36);
  ctx.fillStyle = s.opened ? '#254055' : '#2f5f7d';
  rrect(ctx, -22, -22, 44, 44, 5); ctx.fill();
  ctx.strokeStyle = 'rgba(10,25,40,.7)'; ctx.lineWidth = 3; ctx.stroke();
  ctx.strokeStyle = '#7fd8ff'; ctx.lineWidth = 3;
  ctx.beginPath(); ctx.moveTo(-22, 0); ctx.lineTo(22, 0); ctx.moveTo(0, -22); ctx.lineTo(0, 22); ctx.stroke();
  ctx.fillStyle = '#9fe8ff';
  rrect(ctx, -8, -8, 16, 16, 3); ctx.fill();
  ctx.restore();
}

/* ---------------------------- fighters --------------------------- */
function drawBackbling(f, sk) {
  const bb = BACKBLING_BY_ID[f.backbling] || BACKBLINGS[0];
  const c = bb.color;
  ctx.save();
  if (bb.style === 'cape') {
    ctx.fillStyle = c;
    ctx.globalAlpha = 0.94;
    ctx.beginPath();
    ctx.moveTo(-8, -7.5);
    ctx.quadraticCurveTo(-20, -8, -24, -3);
    ctx.lineTo(-24, 8);
    ctx.quadraticCurveTo(-18, 6, -8, 7.5);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(-9, -3); ctx.lineTo(-22, -4); ctx.moveTo(-9, 3); ctx.lineTo(-22, 5); ctx.stroke();
  } else if (bb.style === 'wings') {
    ctx.fillStyle = c;
    ctx.beginPath();
    ctx.moveTo(-8, -6); ctx.quadraticCurveTo(-27, -19, -30, -8);
    ctx.quadraticCurveTo(-20, -6, -8, 0);
    ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-8, 6); ctx.quadraticCurveTo(-27, 19, -30, 8);
    ctx.quadraticCurveTo(-20, 6, -8, 0);
    ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.28)';
    ctx.beginPath(); ctx.ellipse(-17, -9.5, 5, 2.4, -0.5, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.ellipse(-17, 9.5, 5, 2.4, 0.5, 0, TAU); ctx.fill();
  } else if (bb.style === 'reactor') {
    ctx.fillStyle = '#222b42';
    rrect(ctx, -17, -8.5, 10, 17, 4); ctx.fill();
    const g = ctx.createRadialGradient(-12, 0, 0, -12, 0, 10);
    g.addColorStop(0, c); g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(-12, 0, 10, 0, TAU); ctx.fill();
    ctx.fillStyle = c;
    ctx.beginPath(); ctx.arc(-12, 0, 3.4, 0, TAU); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.85)';
    ctx.beginPath(); ctx.arc(-12, 0, 1.5, 0, TAU); ctx.fill();
  } else if (bb.style === 'llama') {
    ctx.fillStyle = c;
    rrect(ctx, -18, -7, 10, 14, 5); ctx.fill();
    ctx.beginPath(); ctx.arc(-19, -6.5, 4.4, 0, TAU); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-22, -9); ctx.lineTo(-25, -13); ctx.lineTo(-19, -10.5); ctx.closePath(); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-17, -9.5); ctx.lineTo(-17, -14); ctx.lineTo(-13.5, -10); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#2a1d00';
    ctx.beginPath(); ctx.arc(-21.4, -7, 0.9, 0, TAU); ctx.fill();
  } else if (bb.style === 'shark') {
    ctx.fillStyle = c;
    ctx.beginPath();
    ctx.moveTo(-9, -2); ctx.quadraticCurveTo(-19, -4, -26, -13);
    ctx.quadraticCurveTo(-22, -2, -20, 2); ctx.closePath(); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.3)';
    ctx.beginPath(); ctx.arc(-10, 0, 4.6, 0, TAU); ctx.fill();
  } else {
    ctx.fillStyle = c;
    rrect(ctx, -16, -7.5, 8.5, 15, 3.5); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.14)';
    rrect(ctx, -14.4, -5, 4.5, 10, 2.5); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,.22)';
    rrect(ctx, -11.5, -6, 2, 12, 1); ctx.fill();
  }
  ctx.restore();
}

function drawFighter(f, time) {
  const isDrop = f.isPlayer && game.state === 'drop';
  const z = isDrop ? f.z : 0;
  const drawY = f.y - z * 200;
  const scale = 1 + z * 0.3;

  if (z > 0) drawChute(f.x, drawY - 40 * scale, scale, f.glider);

  ctx.fillStyle = 'rgba(0,0,0,' + (0.24 - z * 0.14) + ')';
  ctx.beginPath();
  ctx.ellipse(f.x, f.y + 9, 16 * (1 - z * 0.35), 8.5 * (1 - z * 0.35), 0, 0, TAU);
  ctx.fill();

  if (f.isPlayer && !isDrop) {
    ctx.strokeStyle = 'rgba(80,230,255,.35)';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(f.x, f.y, 23, 0, TAU); ctx.stroke();
  }

  ctx.save();
  ctx.translate(f.x, drawY);
  ctx.scale(scale, scale);
  ctx.rotate(f.aim);

  // emote pose (a little bounce / wiggle while dancing)
  if (f.emoteT > 0 && f.emote && f.emote !== 'none') {
    const p = (3.4 - f.emoteT) * 5;
    if (f.emote === 'floss') {
      ctx.translate(Math.sin(p) * 2.4, 0);
      ctx.rotate(Math.sin(p) * 0.22);
    } else if (f.emote === 'robot') {
      ctx.rotate(Math.sin(p * 0.9) * 0.13);
    } else if (f.emote === 'wave') {
      ctx.rotate(Math.sin(p * 0.8) * 0.09);
    } else if (f.emote === 'groove') {
      ctx.scale(1, 1 + Math.sin(p) * 0.06);
    } else if (f.emote === 'safari') {
      ctx.translate(Math.sin(p * 0.6) * 2.2, -Math.abs(Math.sin(p * 0.9)) * 2.4);
      ctx.rotate(Math.sin(p * 0.6) * 0.08);
    } else if (f.emote === 'gold') {
      ctx.translate(Math.sin(p * 0.55) * 3, -Math.abs(Math.sin(p * 1.1)) * 3);
      ctx.rotate(Math.sin(p * 0.55) * 0.12);
    } else if (f.emote === 'victory') {
      const s = 1 + Math.abs(Math.sin(p * 0.5)) * 0.07;
      ctx.scale(s, s);
    }
  }

  const sk = f.skin || SKINS[0];
  const gait = Math.sin(f.walkT * 12) * 2;

  // back bling (drawn behind the body)
  drawBackbling(f, sk);

  // legs (swing while walking)
  ctx.fillStyle = sk.pants;
  rrect(ctx, -13 + gait, -7.5, 12, 6, 3); ctx.fill();
  rrect(ctx, -13 - gait, 1.5, 12, 6, 3); ctx.fill();
  ctx.fillStyle = sk.accent;
  rrect(ctx, -14.6 + gait, -7, 3.6, 5, 1.7); ctx.fill();
  rrect(ctx, -14.6 - gait, 2, 3.6, 5, 1.7); ctx.fill();

  // torso
  ctx.fillStyle = sk.outfit;
  rrect(ctx, -8.5, -9.5, 17, 19, 6); ctx.fill();
  ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(6,10,20,.55)'; ctx.stroke();
  // accent spine + shoulder pads (visible around the head)
  ctx.fillStyle = sk.accent;
  rrect(ctx, -7, -1.7, 5.5, 3.4, 1.6); ctx.fill();

  if (fighterHasStyle(f, 'robot')) {
    // mech chassis the pilot sits inside
    ctx.fillStyle = '#5d6c74';
    rrect(ctx, -10, -11, 20, 22, 7); ctx.fill();
    ctx.fillStyle = '#7c8d96';
    rrect(ctx, -8, -9, 16, 6, 3.5); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,.3)';
    rrect(ctx, -7, 2, 14, 3, 1.5); ctx.fill();
    ctx.fillStyle = sk.accent;
    rrect(ctx, -6.5, -8, 3.6, 2.2, 1.1); ctx.fill();
    ctx.fillStyle = '#8fa1aa';
    rrect(ctx, -13, -11.5, 7, 5, 2.5); ctx.fill();
    rrect(ctx, -13, 6.5, 7, 5, 2.5); ctx.fill();
  }

  // harvesting tool strapped diagonally across the back
  ctx.save();
  ctx.translate(-8.5, 0);
  ctx.rotate(0.55);
  ctx.fillStyle = '#7a5433';
  rrect(ctx, -1.2, -11, 2.4, 22, 1.2); ctx.fill();
  if (f.tool === 'books') {
    // school books lashed to the handle
    ctx.fillStyle = '#d0453f';
    rrect(ctx, -6.4, -13.4, 12.8, 3.6, 1.2); ctx.fill();
    ctx.fillStyle = '#3f6fc9';
    rrect(ctx, -5.6, -9.6, 11.2, 3.4, 1.1); ctx.fill();
    ctx.fillStyle = '#e8b93a';
    rrect(ctx, -6, -6, 12, 3.2, 1.1); ctx.fill();
    ctx.fillStyle = '#f4edda';
    ctx.fillRect(4.6, -12.8, 1.4, 2.4);
    ctx.fillRect(4, -9, 1.2, 2.2);
    ctx.fillRect(4.2, -5.4, 1.2, 2);
  } else {
    ctx.fillStyle = '#b9c4d0';
    ctx.beginPath();
    ctx.moveTo(-6, -10);
    ctx.quadraticCurveTo(0, -13, 6, -10);
    ctx.lineTo(4.4, -7.2);
    ctx.quadraticCurveTo(0, -9.8, -4.4, -7.2);
    ctx.closePath(); ctx.fill();
  }
  ctx.restore();

  // rifle held forward on the right
  ctx.fillStyle = '#12161f';
  rrect(ctx, 2, 6, 10, 4.6, 1.8); ctx.fill();
  ctx.fillStyle = '#1b2130';
  rrect(ctx, 8, 5.6, 25, 5, 1.8); ctx.fill();
  ctx.fillStyle = '#3c4a66';
  rrect(ctx, 8, 5.6, 25, 1.8, .9); ctx.fill();
  ctx.fillStyle = '#12161f';
  rrect(ctx, 16, 10, 6, 4, 1.5); ctx.fill();

  // arms gripping the rifle
  ctx.strokeStyle = sk.outfit; ctx.lineWidth = 6; ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, -8); ctx.lineTo(10, 3.5);
  ctx.moveTo(0, 8); ctx.lineTo(11, 8);
  ctx.stroke();
  ctx.fillStyle = sk.skin;
  ctx.beginPath(); ctx.arc(10.3, 3.6, 3.1, 0, TAU); ctx.fill();
  ctx.beginPath(); ctx.arc(11.6, 8, 3.1, 0, TAU); ctx.fill();

  if (fighterHasStyle(f, 'robot')) {
    // mech claw arms over the pilot's arms
    ctx.strokeStyle = '#66767e'; ctx.lineWidth = 7.4; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(0, -8); ctx.lineTo(10, 3.5);
    ctx.moveTo(0, 8); ctx.lineTo(11, 8);
    ctx.stroke();
    ctx.fillStyle = '#8fa1aa';
    ctx.beginPath(); ctx.arc(10.3, 3.6, 3.6, 0, TAU); ctx.fill();
    ctx.beginPath(); ctx.arc(11.6, 8, 3.6, 0, TAU); ctx.fill();
  }

  // shoulder pads sit on top of the arms
  ctx.fillStyle = sk.accent;
  rrect(ctx, -2.5, -11, 6.5, 3.8, 1.9); ctx.fill();
  rrect(ctx, -2.5, 7.2, 6.5, 3.8, 1.9); ctx.fill();

  // neck + head (seen from above: hair at back, face forward)
  ctx.fillStyle = sk.skin;
  rrect(ctx, -0.5, -3.5, 5.5, 7, 2); ctx.fill();
  ctx.fillStyle = sk.hair;
  ctx.beginPath(); ctx.arc(2.8, 0, 6.6, 0, TAU); ctx.fill();
  if (sk.hairStyle === 'spiky') {
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * TAU;
      const r1 = i % 2 ? 9.2 : 8.2;
      ctx.beginPath();
      ctx.moveTo(2.8 + Math.cos(a - 0.42) * 6.2, Math.sin(a - 0.42) * 6.2);
      ctx.lineTo(2.8 + Math.cos(a) * r1, Math.sin(a) * r1);
      ctx.lineTo(2.8 + Math.cos(a + 0.42) * 6.2, Math.sin(a + 0.42) * 6.2);
      ctx.closePath(); ctx.fill();
    }
  }
  ctx.fillStyle = sk.skin;
  ctx.beginPath(); ctx.arc(5.9, 0, 5.0, 0, TAU); ctx.fill();
  // visor / face
  ctx.fillStyle = 'rgba(10,16,28,.82)';
  rrect(ctx, 6.6, -3.9, 2.9, 7.8, 1.3); ctx.fill();
  ctx.fillStyle = sk.accent;
  rrect(ctx, 7.2, -3, 1.5, 2.2, .7); ctx.fill();
  rrect(ctx, 7.2, .8, 1.5, 2.2, .7); ctx.fill();
  if (fighterHasStyle(f, 'patch')) {
    // eyepatch strap over the head + patch over one lens
    ctx.fillStyle = '#22262b';
    rrect(ctx, 1.2, -7.8, 3.4, 15.6, 1.7); ctx.fill();
    ctx.fillStyle = '#15181c';
    rrect(ctx, 6.3, -4.3, 3.6, 4.6, 1.5); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.22)';
    rrect(ctx, 6.9, -3.7, 1.3, 1.5, .5); ctx.fill();
  }
  if (fighterHasStyle(f, 'robot')) {
    // cockpit glass dome over the pilot
    ctx.strokeStyle = 'rgba(207,221,229,.9)'; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(4.2, 0, 8.2, 0, TAU); ctx.stroke();
    ctx.strokeStyle = 'rgba(120,215,255,.6)'; ctx.lineWidth = .9;
    ctx.beginPath(); ctx.arc(4.2, 0, 7.1, -2.4, -0.9); ctx.stroke();
  }

  if (f.hitFlash > 0) {
    ctx.beginPath(); ctx.arc(0, 0, 17, 0, TAU);
    ctx.fillStyle = 'rgba(255,255,255,' + Math.min(0.75, f.hitFlash * 4) + ')';
    ctx.fill();
  }
  ctx.restore();

  // muzzle flash (rifle sits to the right of the body)
  if (f.muzzle > 0) {
    const ca = Math.cos(f.aim), sa = Math.sin(f.aim);
    const mx = f.x + ca * 34 - sa * 8.2;
    const my = drawY + sa * 34 + ca * 8.2;
    const g = ctx.createRadialGradient(mx, my, 0, mx, my, 20);
    g.addColorStop(0, 'rgba(255,246,200,.95)');
    g.addColorStop(1, 'rgba(255,190,60,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(mx, my, 20, 0, TAU); ctx.fill();
  }

  // reload / use progress
  if (f.reloadT > 0) {
    const p = 1 - f.reloadT / f.reloadDur;
    ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(f.x, f.y, 25, -Math.PI / 2, -Math.PI / 2 + p * TAU); ctx.stroke();
  }
  if (f.useT > 0) {
    const p = 1 - f.useT / f.useDur;
    ctx.strokeStyle = f.useType === 'shield' ? '#63d6ff' : '#7bffa8'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(f.x, f.y, 25, -Math.PI / 2, -Math.PI / 2 + p * TAU); ctx.stroke();
  }

  // nameplates + health for bots
  if (!f.isPlayer && player) {
    const d = dist(f.x, f.y, player.x, player.y);
    if (d < 720) {
      ctx.textAlign = 'center';
      ctx.font = '700 10px "Segoe UI", system-ui, sans-serif';
      ctx.fillStyle = 'rgba(0,0,0,.55)';
      ctx.fillText(f.name, f.x + 1, f.y - 37);
      ctx.fillStyle = 'rgba(226,238,255,.9)';
      ctx.fillText(f.name, f.x, f.y - 38);

      if (f.hp < 100 || f.shield > 0) {
        const bw = 38, bh = 4, bx = f.x - bw / 2, by = f.y - 33;
        ctx.fillStyle = 'rgba(0,0,0,.55)';
        ctx.fillRect(bx - 1, by - 1, bw + 2, bh + 2);
        ctx.fillStyle = '#4be07a';
        ctx.fillRect(bx, by, bw * clamp(f.hp / 100, 0, 1), bh);
        if (f.shield > 0) {
          ctx.fillStyle = '#4fb7ff';
          ctx.fillRect(bx, by - 4, bw * clamp(f.shield / 100, 0, 1), 2.5);
        }
      }
    }
  }
}

function drawChute(x, y, scale, glider) {
  const canopy = (glider && glider.canopy) || '#e9f2ff';
  const stripe = (glider && glider.stripe) || '#9bb2d6';
  ctx.save();
  ctx.translate(x, y - 34 * scale);
  ctx.fillStyle = canopy;
  ctx.beginPath(); ctx.ellipse(0, 0, 46 * scale, 22 * scale, 0, Math.PI, TAU); ctx.fill();
  ctx.strokeStyle = stripe; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.ellipse(0, 0, 46 * scale, 22 * scale, 0, Math.PI, TAU); ctx.stroke();
  ctx.fillStyle = stripe;
  ctx.globalAlpha = 0.55;
  ctx.beginPath(); ctx.ellipse(0, 0, 22 * scale, 10 * scale, 0, Math.PI, TAU); ctx.fill();
  ctx.globalAlpha = 1;
  ctx.strokeStyle = 'rgba(220,235,255,.8)'; ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-40 * scale, 0); ctx.lineTo(-14, 56 * scale);
  ctx.moveTo(40 * scale, 0); ctx.lineTo(14, 56 * scale);
  ctx.stroke();
  ctx.restore();
}

/* ------------------------------ loot ----------------------------- */
function itemColor(it) {
  if (it.type === 'weapon') return RARITY[it.rarity].color;
  if (it.type === 'shield') return '#55c8ff';
  if (it.type === 'med') return '#ffffff';
  return '#d9a05a';
}

function drawGroundLoot(view, time) {
  for (const l of world.loot) {
    if (l.x < view.x0 || l.x > view.x1 || l.y < view.y0 || l.y > view.y1) continue;
    const it = l.item;
    const col = itemColor(it);
    const y = l.y + Math.sin(time * 2.4 + l.bob) * 2;

    const g = ctx.createRadialGradient(l.x, y, 2, l.x, y, 28);
    g.addColorStop(0, hexA(col, 0.42));
    g.addColorStop(1, hexA(col, 0));
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(l.x, y, 28, 0, TAU); ctx.fill();

    ctx.save();
    ctx.translate(l.x, y);

    if (it.type === 'weapon') {
      ctx.rotate(-0.5);
      ctx.fillStyle = '#171d2a';
      ctx.fillRect(-15, -4, 30, 8);
      ctx.fillStyle = col;
      ctx.fillRect(-15, -4, 30, 2.5);
      ctx.fillStyle = '#2a3346';
      ctx.fillRect(-4, 3, 8, 6);
      ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 1.5;
      ctx.strokeRect(-15, -4, 30, 8);
    } else if (it.type === 'shield') {
      ctx.fillStyle = '#1d4d74';
      rrect(ctx, -8, -8, 16, 19, 4); ctx.fill();
      ctx.fillStyle = col;
      rrect(ctx, -6, -4, 12, 15, 3); ctx.fill();
      ctx.fillStyle = '#dff6ff';
      ctx.fillRect(-4, -12, 8, 6);
      ctx.fillStyle = 'rgba(255,255,255,.55)';
      ctx.fillRect(-4, -2, 3, 10);
    } else if (it.type === 'med') {
      ctx.fillStyle = '#e8eef7';
      rrect(ctx, -9, -8, 18, 17, 3); ctx.fill();
      ctx.fillStyle = '#e73b4c';
      ctx.fillRect(-2, -5, 4, 11);
      ctx.fillRect(-6, -1, 12, 4);
    } else {
      ctx.fillStyle = '#a8763f';
      rrect(ctx, -11, -7, 22, 6, 2); ctx.fill();
      ctx.fillStyle = '#c28c4e';
      rrect(ctx, -11, -1, 22, 6, 2); ctx.fill();
      ctx.fillStyle = '#8d5f31';
      rrect(ctx, -11, 5, 22, 5, 2); ctx.fill();
    }
    ctx.restore();

    ctx.strokeStyle = hexA(col, 0.55);
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(l.x, y, 13, 0, TAU); ctx.stroke();
  }
}

/* ----------------------------- effects --------------------------- */
function drawBullets() {
  for (const b of bullets) {
    const tx = b.x - b.vx * 0.015, ty = b.y - b.vy * 0.015;
    ctx.strokeStyle = b.color;
    ctx.globalAlpha = 0.95;
    ctx.lineWidth = b.size;
    ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(b.x, b.y); ctx.stroke();
    ctx.globalAlpha = 1;
  }
}

function drawParticles() {
  for (const p of particles) {
    ctx.globalAlpha = clamp(p.life / p.max, 0, 1);
    ctx.fillStyle = p.color;
    ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, TAU); ctx.fill();
  }
  ctx.globalAlpha = 1;
}

function drawTexts() {
  ctx.textAlign = 'center';
  for (const t of texts) {
    ctx.globalAlpha = clamp(t.life / t.max, 0, 1);
    ctx.font = 'italic 800 ' + t.size + 'px "Segoe UI", system-ui, sans-serif';
    ctx.lineWidth = 3;
    ctx.strokeStyle = 'rgba(0,0,0,.65)';
    ctx.strokeText(t.text, t.x, t.y);
    ctx.fillStyle = t.color;
    ctx.fillText(t.text, t.x, t.y);
  }
  ctx.globalAlpha = 1;
}

/* ------------------------------ storm ---------------------------- */
function drawStormOverlay(view, time) {
  ctx.save();
  ctx.beginPath();
  ctx.rect(view.x0 - 400, view.y0 - 400, view.x1 - view.x0 + 800, view.y1 - view.y0 + 800);
  ctx.arc(storm.x, storm.y, storm.r, 0, TAU, true);
  ctx.fillStyle = 'rgba(108,38,206,.40)';
  ctx.fill('evenodd');

  ctx.strokeStyle = 'rgba(214,163,255,.9)';
  ctx.lineWidth = 9;
  ctx.shadowColor = 'rgba(190,110,255,.9)';
  ctx.shadowBlur = 26;
  ctx.beginPath(); ctx.arc(storm.x, storm.y, storm.r, 0, TAU); ctx.stroke();
  ctx.shadowBlur = 0;

  ctx.strokeStyle = 'rgba(255,255,255,.5)';
  ctx.lineWidth = 2.5;
  ctx.setLineDash([34, 26]);
  ctx.lineDashOffset = -time * 70;
  ctx.beginPath(); ctx.arc(storm.x, storm.y, storm.r, 0, TAU); ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();
}

/* ----------------------------- minimap --------------------------- */
function drawMinimap() {
  const S = ui.mini.width;
  const s = S / WORLD;
  mctx.clearRect(0, 0, S, S);
  mctx.fillStyle = '#26482f';
  mctx.fillRect(0, 0, S, S);

  // storm-filled area
  mctx.save();
  mctx.beginPath();
  mctx.rect(0, 0, S, S);
  mctx.arc(storm.x * s, storm.y * s, storm.r * s, 0, TAU, true);
  mctx.fillStyle = 'rgba(120,44,214,.62)';
  mctx.fill('evenodd');
  mctx.restore();

  // safe circle
  mctx.strokeStyle = 'rgba(210,155,255,.95)';
  mctx.lineWidth = 2;
  mctx.beginPath(); mctx.arc(storm.x * s, storm.y * s, storm.r * s, 0, TAU); mctx.stroke();

  // next circle
  if (storm.state === 'shrink') {
    mctx.setLineDash([4, 4]);
    mctx.strokeStyle = 'rgba(255,255,255,.75)';
    mctx.beginPath(); mctx.arc(storm.tx * s, storm.ty * s, storm.tr * s, 0, TAU); mctx.stroke();
    mctx.setLineDash([]);
  }

  // supply drops
  mctx.fillStyle = '#ffd24a';
  for (const sp of world.supplies) {
    if (sp.opened) continue;
    mctx.beginPath(); mctx.arc(sp.x * s, sp.y * s, 2.6, 0, TAU); mctx.fill();
  }

  // player arrow
  if (player) {
    mctx.save();
    mctx.translate(player.x * s, player.y * s);
    mctx.rotate(player.aim + Math.PI / 2);
    mctx.beginPath();
    mctx.moveTo(0, -7); mctx.lineTo(5, 5); mctx.lineTo(0, 2); mctx.lineTo(-5, 5);
    mctx.closePath();
    mctx.fillStyle = '#6ef0ff';
    mctx.strokeStyle = 'rgba(0,20,30,.9)';
    mctx.lineWidth = 1.5;
    mctx.fill(); mctx.stroke();
    mctx.restore();
  }

  // border
  mctx.strokeStyle = 'rgba(150,190,255,.25)';
  mctx.lineWidth = 2;
  mctx.strokeRect(1, 1, S - 2, S - 2);
}
