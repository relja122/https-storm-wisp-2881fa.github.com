'use strict';
/* ==================================================================
   STORM ROYALE — update loop + boot
   ================================================================== */

function resize() {
  dpr = Math.min(2, window.devicePixelRatio || 1);
  viewW = window.innerWidth;
  viewH = window.innerHeight;
  ui.canvas.width = Math.floor(viewW * dpr);
  ui.canvas.height = Math.floor(viewH * dpr);
  clampCamera();
}

function separateFighters() {
  for (let i = 0; i < fighters.length; i++) {
    const a = fighters[i];
    if (!a.alive) continue;
    for (let j = i + 1; j < fighters.length; j++) {
      const b = fighters[j];
      if (!b.alive) continue;
      const dx = b.x - a.x, dy = b.y - a.y;
      const d = Math.hypot(dx, dy);
      const min = a.r + b.r;
      if (d < min && d > 0.001) {
        const push = (min - d) * 0.5;
        const ux = dx / d, uy = dy / d;
        a.x -= ux * push; a.y -= uy * push;
        b.x += ux * push; b.y += uy * push;
      }
    }
  }
}

let autoPickT = 0;

/* Easy-controls auto pickup: grabs nearby loot without pressing E. Weapons
   are only auto-grabbed when there's a free slot so good guns aren't swapped. */
function autoPickup(dt) {
  if (!player || !player.alive || !profile || profile.easy === false) return;
  autoPickT -= dt;
  if (autoPickT > 0) return;
  autoPickT = 0.22;
  let best = null, bestD = 44;
  for (const l of world.loot) {
    const d = dist(player.x, player.y, l.x, l.y);
    if (d >= bestD) continue;
    const it = l.item;
    if (it.type === 'weapon') {
      if (!player.weapons.some((w) => !w)) continue;
    } else if (it.type === 'shield') {
      if (player.shieldPots >= 5) continue;
    } else if (it.type === 'med') {
      if (player.medkits >= 3) continue;
    }
    best = l; bestD = d;
  }
  if (best) pickupLoot(best);
}

function updatePlayer(dt) {
  if (!player || !player.alive) return;
  const third = game.view === 'third';
  const sens = clamp(profile.sensitivity || 1.2, 0.4, 2.6);

  if (third) {
    game.yaw -= (mouse.moveX || 0) * 0.0026 * sens;
    game.pitch = clamp(game.pitch - (mouse.moveY || 0) * 0.0019 * sens, -0.55, 0.62);
    player.aim = game.yaw;
  }

  tickWeapon(player, dt);

  if (player.useT > 0) {
    player.useT -= dt;
    if (player.useT <= 0) finishUse();
  }

  let dx = 0, dy = 0;
  if (keys['w'] || keys['arrowup']) dy--;
  if (keys['s'] || keys['arrowdown']) dy++;
  if (keys['a'] || keys['arrowleft']) dx--;
  if (keys['d'] || keys['arrowright']) dx++;

  if (third) {
    const fwd = -dy, str = dx;
    const cy = Math.cos(game.yaw), sy = Math.sin(game.yaw);
    dx = cy * fwd - sy * str;
    dy = sy * fwd + cy * str;
  }

  moveFighter(player, dt, dx, dy);
  autoPickup(dt);

  if (third) {
    player.aim = game.yaw;
  } else {
    const wx = game.camX + (mouse.x - viewW / 2) / game.camZoom;
    const wy = game.camY + (mouse.y - viewH / 2) / game.camZoom;
    player.aim = Math.atan2(wy - player.y, wx - player.x);
  }

  if (mouse.down) playerShoot();

  const cur = player.weapons[player.slot];
  if (!player.melee && cur && cur.ammo <= 0 && player.reloadT <= 0) startReload(player);
}

function updateDrop(dt) {
  if (!player) return;
  player.z = Math.max(0, player.z - dt / 2.8);

  const third = game.view === 'third';
  const sens = clamp(profile.sensitivity || 1.2, 0.4, 2.6);
  if (third) {
    game.yaw -= (mouse.moveX || 0) * 0.0026 * sens;
    game.pitch = clamp(game.pitch - (mouse.moveY || 0) * 0.0019 * sens, -0.55, 0.62);
  }

  let dx = 0, dy = 0;
  if (keys['w'] || keys['arrowup']) dy--;
  if (keys['s'] || keys['arrowdown']) dy++;
  if (keys['a'] || keys['arrowleft']) dx--;
  if (keys['d'] || keys['arrowright']) dx++;
  const len = Math.hypot(dx, dy);
  if (len > 0) { dx /= len; dy /= len; }

  if (third) {
    const fwd = -dy, str = dx;
    const cy = Math.cos(game.yaw), sy = Math.sin(game.yaw);
    dx = cy * fwd - sy * str;
    dy = sy * fwd + cy * str;
    player.aim = game.yaw;
  } else {
    const wx = game.camX + (mouse.x - viewW / 2) / game.camZoom;
    const wy = game.camY + (mouse.y - viewH / 2) / game.camZoom;
    player.aim = Math.atan2(wy - player.y, wx - player.x);
  }

  player.x = clamp(player.x + dx * 300 * dt, 70, WORLD - 70);
  player.y = clamp(player.y + dy * 300 * dt, 70, WORLD - 70);

  if (player.z <= 0) land();
}

function land() {
  player.z = 0;
  game.state = 'playing';
  game.camZoom = 1;
  game.stormTick = 0;
  storm.timer = PHASES[0].wait;
  for (let i = 0; i < 26; i++) spawnParticle(player.x, player.y, '#d9c9a3', 150, 3.4, 0.7);
  addText(player.x, player.y - 46, 'LANDED', '#ffffff', 18, 1.2);
  toast('50 PLAYERS · LAST ONE STANDING', 'gold');
  sfx('storm');
}

function update(dt) {
  game.hitT = Math.max(0, (game.hitT || 0) - dt);
  game.shake = Math.max(0, game.shake - dt * 40);

  if (game.state === 'menu') { updateCamera(dt); return; }
  if (game.state === 'paused' || game.state === 'dead' || game.state === 'won') return;

  if (game.state === 'drop') {
    updateDrop(dt);
  } else if (game.state === 'playing') {
    game.time += dt;
    updatePlayer(dt);
    updateBots(dt);
    updateStorm(dt);
    supplyTimer -= dt;
    if (supplyTimer <= 0 && game.time > 25) {
      spawnSupply();
      supplyTimer = rnd(45, 65);
    }
    separateFighters();
  }

  if (game.state === 'playing' || game.state === 'drop') {
    updateBullets(dt);
    updateParticles(dt);
    updateSupplies(dt);
    if (world.walls.some((w) => w.dead)) world.walls = world.walls.filter((w) => !w.dead);
    updateCamera(dt);
    updateHUD();
  }
}

let lastT = 0;
function frame(now) {
  const dt = lastT ? Math.min(0.05, (now - lastT) / 1000) : 0.016;
  lastT = now;
  update(dt);
  render();
  mouse.clicked = false;
  mouse.moveX = 0;
  mouse.moveY = 0;
  requestAnimationFrame(frame);
}

function init() {
  resize();
  generateWorld();
  initStorm();
  game.state = 'menu';
  ui.hud.classList.add('hidden');
  const seasonGrant = syncSeason();
  bindInput();
  if (seasonGrant > 0) showBanner('SEASON ' + SEASON.number + ' · ' + SEASON.name + ' · +' + seasonGrant + ' TOKENS');
  refreshPreviews();
  renderQuest();
  updateCamera(0.016);
  window.addEventListener('resize', resize);
  requestAnimationFrame(frame);
}

init();
