'use strict';
/* ==================================================================
   STORM ROYALE — bot brains
   ================================================================== */

let botSfxBudget = 3;

function botName(used) {
  for (let i = 0; i < 80; i++) {
    const n = pick(BOT_FIRST) + ' ' + pick(BOT_LAST);
    if (!used.has(n)) { used.add(n); return n; }
  }
  let n = 'Rookie ' + (used.size + 1);
  used.add(n);
  return n;
}

function spawnBots(count) {
  const used = new Set();
  for (let i = 0; i < count; i++) {
    let x = 0, y = 0, ok = false;
    for (let tries = 0; tries < 90; tries++) {
      x = rnd(180, WORLD - 180);
      y = rnd(180, WORLD - 180);
      const farEnough = !player || dist(x, y, player.x, player.y) > (tries < 60 ? 1150 : 700);
      if (farEnough && !insideAnyBuilding(x, y, 20) && !nearLake(x, y, -10)) { ok = true; break; }
    }
    if (!ok) { x = rnd(180, WORLD - 180); y = rnd(180, WORLD - 180); }
    const b = makeFighter(x, y, false);
    b.name = botName(used);
    b.skin = pick(SKINS.slice(0, BASE_SKIN_COUNT));
    b.color = b.skin.accent;
    b.backbling = pick(BACKBLINGS).id;
    b.glider = pick(GLIDERS);
    b.skill = rnd(0.32, 0.95);
    b.speed = rnd(212, 250);
    b.vision = rnd(330, 580);
    b.weapons[0] = rollWeapon(irnd(0, 2));
    b.slot = 0;
    const def = WEAPONS[b.weapons[0].kind];
    b.pref = def.pellets > 1 ? rnd(130, 250) : def.range > 2000 ? rnd(480, 720) : rnd(230, 430);
    b.shield = Math.random() < 0.4 ? irnd(25, 75) : 0;
    b.aim = rnd(0, TAU);
    b.thinkCd = rnd(0, 0.6);
    b.strafeT = rnd(0.5, 2);
    b.strafe = Math.random() < 0.5 ? -1 : 1;
    b.objective = randomInZone(HALF, HALF, 900);
    b.losCd = rnd(0, 0.3);
    b.reactT = rnd(0.3, 1.0);
    b.waitT = 0;
    bots.push(b);
    fighters.push(b);
  }
}

function randomInZone(x, y, r) {
  const a = Math.random() * TAU;
  const d = Math.sqrt(Math.random()) * r;
  return {
    x: clamp(x + Math.cos(a) * d, 80, WORLD - 80),
    y: clamp(y + Math.sin(a) * d, 80, WORLD - 80)
  };
}

function hasLOS(a, b) {
  const minX = Math.min(a.x, b.x), maxX = Math.max(a.x, b.x);
  const minY = Math.min(a.y, b.y), maxY = Math.max(a.y, b.y);
  for (const w of world.walls) {
    if (w.dead) continue;
    if (w.maxX < minX || w.minX > maxX || w.maxY < minY || w.minY > maxY) continue;
    if (segSeg(a.x, a.y, b.x, b.y, w.ax, w.ay, w.bx, w.by)) return false;
  }
  return true;
}

function findTarget(b) {
  let best = null, bestD = b.vision;
  for (const f of fighters) {
    if (!f.alive || f === b) continue;
    if (f.isPlayer && game.time < 6) continue;
    const d = dist(b.x, b.y, f.x, f.y);
    if (d < bestD && hasLOS(b, f)) { best = f; bestD = d; }
  }
  return best;
}

function updateBots(dt) {
  botSfxBudget = 3;
  for (const b of bots) {
    if (!b.alive) continue;
    tickWeapon(b, dt);
    updateBot(b, dt);
  }
}

function updateBot(b, dt) {
  b.thinkCd -= dt;
  b.strafeT -= dt;
  if (b.losCd > 0) b.losCd -= dt;

  const dStorm = dist(b.x, b.y, storm.x, storm.y);
  const stormDanger = dStorm > storm.r - 110;

  if (b.strafeT <= 0) { b.strafe *= -1; b.strafeT = rnd(0.6, 2.2); }

  if (b.thinkCd <= 0) {
    b.thinkCd = rnd(0.35, 0.75);
    const nt = findTarget(b);
    if (nt && nt !== b.target) b.reactT = rnd(0.35, 0.95);
    b.target = nt;
    if (!b.objective && b.waitT <= 0) {
      b.objective = randomInZone(storm.x, storm.y, Math.max(120, storm.r * 0.7));
    }
  }
  if (b.reactT > 0) b.reactT -= dt;

  let mx = 0, my = 0, sprint = 1;

  if (stormDanger) {
    const a = Math.atan2(storm.y - b.y, storm.x - b.x);
    mx = Math.cos(a); my = Math.sin(a);
    sprint = 1.42;
    b.aim = angLerp(b.aim, a, 0.25);
    b.wantFire = false;
  } else {
    const t = b.target;
    if (t && t.alive) {
      const d = dist(b.x, b.y, t.x, t.y);
      const aimA = Math.atan2(t.y - b.y, t.x - b.x);
      b.aim = angLerp(b.aim, aimA, 0.24);
      b.wantFire = d < Math.min(b.vision, 950);
      let forward = 0;
      if (d > b.pref * 1.18) forward = 1;
      else if (d < b.pref * 0.55) forward = -1;
      mx = Math.cos(aimA) * forward + Math.cos(aimA + Math.PI / 2) * b.strafe * 0.9;
      my = Math.sin(aimA) * forward + Math.sin(aimA + Math.PI / 2) * b.strafe * 0.9;
      sprint = forward < 0 ? 1.02 : 1.1;
    } else {
      b.wantFire = false;
      if (b.waitT > 0) {
        b.waitT -= dt;
        b.aim = angLerp(b.aim, b.aim + 0.25, 0.02);
      } else if (b.objective) {
        const dd = dist(b.x, b.y, b.objective.x, b.objective.y);
        if (dd < 90) {
          b.objective = null;
          b.waitT = rnd(0.8, 2.6);
        } else {
          mx = b.objective.x - b.x;
          my = b.objective.y - b.y;
          sprint = 1.12;
          b.aim = angLerp(b.aim, Math.atan2(my, mx), 0.1);
        }
      }
    }
  }

  moveFighter(b, dt, mx, my);

  if (b.wantFire && b.target && b.target.alive) botShoot(b, dt);
}

function botShoot(b, dt) {
  const w = b.weapons[b.slot];
  if (!w) return;
  const def = WEAPONS[w.kind];
  if (b.fireCd > 0 || b.reloadT > 0) return;
  if (w.ammo <= 0) { startReload(b); return; }

  const t = b.target;
  if (!t || !t.alive) return;
  if (b.reactT > 0) return;
  const d = dist(b.x, b.y, t.x, t.y);
  if (d > Math.min(760, b.vision)) return;

  if (b.losCd <= 0) {
    b.losCd = 0.22;
    if (!hasLOS(b, t)) return;
  }

  const lead = d / def.speed;
  const aimPoint = Math.atan2((t.y + Math.sin(t.aim) * 40 * lead) - b.y, (t.x + Math.cos(t.aim) * 40 * lead) - b.x);
  const inacc = (1 - b.skill) * 0.16 + def.spread * 1.3;

  w.ammo--;
  fireWeapon(b, def, aimPoint + rnd(-inacc, inacc));
  b.fireCd *= rnd(1.25, 2.1);

  if (d < 1300 && botSfxBudget > 0) {
    botSfxBudget--;
    sfx('shoot', w.kind);
  }
  if (w.ammo <= 0) startReload(b);
}
