'use strict';
/* ==================================================================
   STORM ROYALE — shared helpers, config, globals, audio
   ================================================================== */

/* ----------------------------- math ------------------------------ */
const TAU = Math.PI * 2;
const WORLD = 3200;
const HALF = WORLD / 2;

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const lerp = (a, b, t) => a + (b - a) * t;
const dist = (x1, y1, x2, y2) => Math.hypot(x2 - x1, y2 - y1);
const rnd = (a = 0, b = 1) => a + Math.random() * (b - a);
const irnd = (a, b) => Math.floor(rnd(a, b + 1));
const pick = (a) => a[(Math.random() * a.length) | 0];
const norm = (a) => { while (a > Math.PI) a -= TAU; while (a < -Math.PI) a += TAU; return a; };
const angLerp = (a, b, t) => a + norm(b - a) * t;
const easeInOut = (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
const fmtTime = (s) => {
  s = Math.max(0, Math.round(s));
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
};

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function closestOnSeg(px, py, x1, y1, x2, y2) {
  const dx = x2 - x1, dy = y2 - y1;
  const l2 = dx * dx + dy * dy;
  let t = l2 > 0 ? ((px - x1) * dx + (py - y1) * dy) / l2 : 0;
  t = clamp(t, 0, 1);
  return { x: x1 + t * dx, y: y1 + t * dy, t };
}
function distToSeg(px, py, x1, y1, x2, y2) {
  const c = closestOnSeg(px, py, x1, y1, x2, y2);
  return Math.hypot(px - c.x, py - c.y);
}
function segSeg(x1, y1, x2, y2, x3, y3, x4, y4) {
  const d = (x2 - x1) * (y4 - y3) - (y2 - y1) * (x4 - x3);
  if (Math.abs(d) < 1e-6) return false;
  const t = ((x3 - x1) * (y4 - y3) - (y3 - y1) * (x4 - x3)) / d;
  const u = ((x3 - x1) * (y2 - y1) - (y3 - y1) * (x2 - x1)) / d;
  return t >= 0 && t <= 1 && u >= 0 && u <= 1;
}

/* --------------------------- game config ------------------------- */
const WEAPONS = {
  ar:      { name: 'Assault Rifle', short: 'AR',     dmg: 30, rpm: 340, mag: 30, reload: 2.2, spread: 0.030, speed: 2100, auto: true,  pellets: 1, range: 1250, botMul: 0.38 },
  shotgun: { name: 'Pump Shotgun',  short: 'PUMP',   dmg: 11, rpm: 75,  mag: 5,  reload: 3.0, spread: 0.20,  speed: 1700, auto: false, pellets: 9, range: 520,  botMul: 0.26 },
  smg:     { name: 'SMG',           short: 'SMG',    dmg: 15, rpm: 780, mag: 32, reload: 2.0, spread: 0.075, speed: 1800, auto: true,  pellets: 1, range: 900,  botMul: 0.34 },
  sniper:  { name: 'Sniper Rifle',  short: 'SNIPER', dmg: 100, rpm: 32, mag: 1,  reload: 2.7, spread: 0.003, speed: 3200, auto: false, pellets: 1, range: 2600, botMul: 0.52 },
  pistol:  { name: 'Pistol',        short: 'PISTOL', dmg: 23, rpm: 400, mag: 16, reload: 1.5, spread: 0.045, speed: 1900, auto: false, pellets: 1, range: 950,  botMul: 0.44 }
};

/* Gun slots in the hotbar. The pickaxe is a side weapon: it is always
   available on its own key and never takes one of these slots. */
const WEAPON_SLOTS = 5;
const PICK_KEY = '6';

const RARITY = [
  { name: 'Common',    color: '#b9c2cc', mult: 1.00 },
  { name: 'Uncommon',  color: '#5ad34f', mult: 1.12 },
  { name: 'Rare',      color: '#3ea9ff', mult: 1.26 },
  { name: 'Epic',      color: '#b45cff', mult: 1.42 },
  { name: 'Legendary', color: '#ffb83e', mult: 1.62 }
];

const PHASES = [
  { wait: 38, shrink: 30, r: 1250, dps: 1 },
  { wait: 22, shrink: 24, r: 840,  dps: 2 },
  { wait: 16, shrink: 20, r: 540,  dps: 4 },
  { wait: 13, shrink: 17, r: 320,  dps: 7 },
  { wait: 11, shrink: 14, r: 165,  dps: 10 },
  { wait: 9,  shrink: 12, r: 70,   dps: 14 }
];

const ZONE_DEFS = [
  { name: 'ACACIA CITY',    x: 2010, y: 1180, r: 360, tier: 2, buildings: 5 },
  { name: 'MIRAGE OASIS',   x: 1000, y: 880,  r: 300, tier: 1, buildings: 3 },
  { name: 'DUNE DOCKS',     x: 2500, y: 2470, r: 330, tier: 2, buildings: 4 },
  { name: 'DUSTY DEPOT',    x: 720,  y: 2400, r: 300, tier: 1, buildings: 3 },
  { name: 'SAVANNA FLATS',  x: 1560, y: 2660, r: 320, tier: 1, buildings: 3 },
  { name: 'BAOBAB NOOK',    x: 1130, y: 1640, r: 280, tier: 2, buildings: 3 },
  { name: 'SERENGETI FARM', x: 2520, y: 880,  r: 290, tier: 0, buildings: 2 }
];

const SKINS = [
  { name: 'RAPTOR',   outfit: '#2f6fd0', accent: '#43e8ff', skin: '#e8b48c', hair: '#2a2320', pants: '#1b2740' },
  { name: 'SUNBURST', outfit: '#e8833a', accent: '#ffd24a', skin: '#c98a5e', hair: '#3a2216', pants: '#3a2a20' },
  { name: 'FROST',    outfit: '#cddff0', accent: '#7fd8ff', skin: '#f0c49c', hair: '#cfe6ff', pants: '#4a6076' },
  { name: 'VIPER',    outfit: '#2f7a45', accent: '#a3e36b', skin: '#8a5a3c', hair: '#141c14', pants: '#1c3324' },
  { name: 'NEON',     outfit: '#7b3bd6', accent: '#ff86c8', skin: '#f2c6a0', hair: '#2a1240', pants: '#2a1a44' },
  { name: 'GHOST',    outfit: '#3a4250', accent: '#ffffff', skin: '#d9b08c', hair: '#8a94a6', pants: '#222833' },
  { name: 'BLAZE',    outfit: '#c93a3a', accent: '#ffb83e', skin: '#b97a4e', hair: '#1c1210', pants: '#33201c' },
  { name: 'TIDE',     outfit: '#1f8a8a', accent: '#8ef0e0', skin: '#e0b08a', hair: '#183034', pants: '#173a3a' }
];

/* --------------------------- locker catalog ---------------------- */
const ITEM_RARITY = {
  common:    { name: 'COMMON',    color: '#9aa7bd' },
  rare:      { name: 'RARE',      color: '#4fa8ff' },
  epic:      { name: 'EPIC',      color: '#b45cff' },
  legendary: { name: 'LEGENDARY', color: '#ffab2e' }
};

// premium outfits live in the same list so they render with the same code
SKINS.push(
  { name: 'SHADOW OPS', rarity: 'epic',      price: 100, outfit: '#242a3a', accent: '#ff3f6e', skin: '#c98a5e', hair: '#10131c', pants: '#151a26' },
  { name: 'GILDED',     rarity: 'legendary', price: 150, outfit: '#c9a227', accent: '#fff3b0', skin: '#e0b08a', hair: '#2a1e0a', pants: '#4a3a12' },
  { name: 'CIRCUIT',    rarity: 'rare',      price: 60,  outfit: '#20262e', accent: '#39ff9e', skin: '#d9b08c', hair: '#0d1412', pants: '#151f1b' },
  { name: 'VALOR',      rarity: 'epic',      price: 100, outfit: '#3b4a8f', accent: '#ffe066', skin: '#b97a4e', hair: '#1a1a2e', pants: '#22284a' },
  { name: 'TOXIC',      rarity: 'rare',      price: 60,  outfit: '#5a8f2a', accent: '#d8ff5e', skin: '#8a5a3c', hair: '#1c2410', pants: '#2a3a18' },
  { name: 'CRIMSON',    rarity: 'legendary', price: 150, outfit: '#7a1626', accent: '#ff6b78', skin: '#f0c49c', hair: '#2a0d12', pants: '#3a1018' }
);
const BASE_SKIN_COUNT = 8;

/* ---- season 2 battle pass outfits (pass-only, never sold) ---- */
SKINS.push(
  { name: 'ACACIA RANGER', rarity: 'epic',      pass: true, price: 0, outfit: '#7d6b3f', accent: '#e8c46a', skin: '#c98a5e', hair: '#2a2010', pants: '#3f3a22' },
  { name: 'DUNE RAIDER',   rarity: 'epic',      pass: true, price: 0, outfit: '#b98a4a', accent: '#ffdf8a', skin: '#8a5a3c', hair: '#241a0e', pants: '#4a3820' },
  { name: 'GOLDEN OASIS',  rarity: 'legendary', pass: true, price: 0, outfit: '#d9b23c', accent: '#fff2b0', skin: '#e0b08a', hair: '#2a1e0a', pants: '#6b5320' }
);

/* ---- free-skin quest reward (never sold in the shop) ---- */
const QUEST_SKIN_INDEX = SKINS.length;
SKINS.push({
  name: 'STORM RIDER', rarity: 'legendary', quest: true, price: 0,
  outfit: '#18213a', accent: '#ffc93c', skin: '#e8b48c', hair: '#e7efff', pants: '#101828'
});

/* ---- season 2 GOLD track outfits (800-token gold pass, never sold) ---- */
SKINS.push(
  { name: 'GILDED PHARAOH', rarity: 'legendary', pass: true, gold: true, price: 0, outfit: '#d8a52c', accent: '#fff9d6', skin: '#e6bb92', hair: '#2b1d06', pants: '#7a5a12' },
  { name: 'SUN CROWN',      rarity: 'legendary', pass: true, gold: true, price: 0, outfit: '#c8762a', accent: '#ffe27a', skin: '#b97a4e', hair: '#241304', pants: '#5c3410' },
  { name: 'BLACK GOLD',     rarity: 'legendary', pass: true, gold: true, price: 0, outfit: '#241f16', accent: '#ffcf4a', skin: '#8a5a3c', hair: '#120d05', pants: '#171310' },
  { name: 'MIDAS RANGER',   rarity: 'legendary', pass: true, gold: true, price: 0, outfit: '#e8c040', accent: '#fffbe0', skin: '#f0c49c', hair: '#4a3208', pants: '#8a6a1c' }
);

/* ---- limited time collab outfit (sold in the shop only) ---- */
const COLLAB_SKIN_INDEX = SKINS.length;
SKINS.push({
  name: 'MORTY', rarity: 'legendary', collab: true, price: 1500,
  outfit: '#eed23c', accent: '#5ad2ff', skin: '#f4d3b0', hair: '#7a4a22', pants: '#2f5fa8',
  hairStyle: 'spiky',
  styles: [
    { id: 'robot', name: 'ROBOT', hint: 'MECH SUIT' },
    { id: 'patch', name: 'EYEPATCH', hint: 'COLLAB EDIT STYLE' }
  ]
});

/* ---- outfit edit styles (owned with the outfit, combinable) ---- */
function skinEditStyles(index) {
  const s = SKINS[index];
  if (!s || !s.styles || !s.styles.length) return [];
  return [{ id: 'default', name: 'DEFAULT' }].concat(s.styles);
}

function equippedStyleIds(index) {
  if (index === undefined || index === null) index = profile.equipped.outfit;
  const list = skinEditStyles(index);
  if (!list.length) return [];
  const saved = profile.styles && profile.styles['o:' + index];
  const ids = Array.isArray(saved) ? saved : (typeof saved === 'string' ? [saved] : []);
  return list.filter((st) => ids.indexOf(st.id) >= 0).map((st) => st.id);
}

function hasEditStyle(index, id) {
  return equippedStyleIds(index).indexOf(id) >= 0;
}

function toggleEquippedStyle(index, id) {
  const list = skinEditStyles(index);
  if (!list.some((st) => st.id === id)) return;
  let ids = equippedStyleIds(index);
  ids = ids.indexOf(id) >= 0 ? ids.filter((x) => x !== id) : ids.concat(id);
  if (!profile.styles) profile.styles = {};
  const key = 'o:' + index;
  if (ids.length) profile.styles[key] = ids;
  else delete profile.styles[key];
  saveProfile();
  if (typeof player !== 'undefined' && player && player.isPlayer &&
      profile.equipped.outfit === index) {
    player.editStyles = equippedStyleIds(index);
  }
}

function clearEquippedStyles(index) {
  if (!profile.styles) profile.styles = {};
  delete profile.styles['o:' + index];
  saveProfile();
  if (typeof player !== 'undefined' && player && player.isPlayer &&
      profile.equipped.outfit === index) {
    player.editStyles = [];
  }
}

function fighterHasStyle(f, id) {
  if (!f) return false;
  if (Array.isArray(f.editStyles)) return f.editStyles.indexOf(id) >= 0;
  return f.editStyle === id;
}

const QUEST_STEPS = [
  { key: 'matches', label: 'PLAY MATCHES', need: 2 },
  { key: 'kills',   label: 'ELIMINATIONS', need: 3 },
  { key: 'chests',  label: 'CHESTS OPENED', need: 4 }
];

/* ---- token packs (demo checkout) ---- */
const TOKEN_PACKS = [
  { id: 'p500',  tokens: 500,  price: '$4.99',  tag: '' },
  { id: 'p1200', tokens: 1200, price: '$9.99',  tag: 'POPULAR' },
  { id: 'p2500', tokens: 2500, price: '$19.99', tag: '' },
  { id: 'p6500', tokens: 6500, price: '$49.99', tag: 'BEST VALUE' }
];

const BACKBLINGS = [
  { id: 'pack',    name: 'STANDARD PACK', rarity: 'common',    price: 0,   free: true, style: 'pack',    color: '#3a4a6b' },
  { id: 'cape',    name: 'STORM CAPE',    rarity: 'rare',      price: 60,  style: 'cape',    color: '#7b3bd6' },
  { id: 'wings',   name: 'VOLT WINGS',    rarity: 'epic',      price: 100, style: 'wings',   color: '#43e8ff' },
  { id: 'reactor', name: 'REACTOR CORE',  rarity: 'epic',      price: 100, style: 'reactor', color: '#ff86c8' },
  { id: 'llama',   name: 'LLAMA BUDDY',   rarity: 'rare',      price: 60,  style: 'llama',   color: '#ffd24a' },
  { id: 'shark',   name: 'SHARK FIN',     rarity: 'legendary', price: 150, style: 'shark',   color: '#8ea7c9' },
  { id: 'canteen', name: 'SAFARI CANTEEN', rarity: 'rare',     price: 0, pass: true, style: 'canteen', color: '#5f8a4a' },
  { id: 'binos',   name: 'FIELD BINOCULARS', rarity: 'epic',   price: 0, pass: true, style: 'binos',   color: '#39412a' },
  { id: 'idol',    name: 'GOLDEN IDOL',   rarity: 'legendary', price: 0, pass: true, gold: true, style: 'idol',  color: '#ffcf4a' },
  { id: 'vault',   name: 'TREASURE VAULT', rarity: 'legendary', price: 0, pass: true, gold: true, style: 'vault', color: '#c99a2e' }
];

const EMOTES = [
  { id: 'none',    name: 'NO EMOTE',      rarity: 'common',    price: 0,   free: true },
  { id: 'wave',    name: 'FRIENDLY WAVE', rarity: 'rare',      price: 60 },
  { id: 'floss',   name: 'FLOSS',         rarity: 'rare',      price: 60 },
  { id: 'robot',   name: 'ROBOT',         rarity: 'epic',      price: 100 },
  { id: 'groove',  name: 'GROOVE JAM',    rarity: 'epic',      price: 100 },
  { id: 'victory', name: 'VICTORY ROAR',  rarity: 'legendary', price: 150 },
  { id: 'safari',  name: 'SAFARI STRUT',  rarity: 'epic',      price: 0, pass: true },
  { id: 'gold',    name: 'GOLD SHUFFLE',  rarity: 'legendary', price: 0, pass: true, gold: true }
];

const GLIDERS = [
  { id: 'standard', name: 'STANDARD GLIDER', rarity: 'common',    price: 0,   free: true, canopy: '#e9f2ff', stripe: '#9bb2d6' },
  { id: 'sunset',   name: 'SUNSET DRIFT',    rarity: 'rare',      price: 60,  canopy: '#ffb454', stripe: '#e8833a' },
  { id: 'neon',     name: 'NEON DROP',       rarity: 'epic',      price: 100, canopy: '#43e8ff', stripe: '#7b3bd6' },
  { id: 'shadow',   name: 'SHADOW WING',     rarity: 'epic',      price: 100, canopy: '#3a4250', stripe: '#ff3f6e' },
  { id: 'gold',     name: 'GOLD RUSH',       rarity: 'legendary', price: 150, canopy: '#ffe066', stripe: '#ffab2e' },
  { id: 'dune',     name: 'DUNE DRIFTER',    rarity: 'epic',      price: 0, pass: true, canopy: '#e8c46a', stripe: '#b07a2e' },
  { id: 'sun',      name: 'GOLDEN SUN',      rarity: 'legendary', price: 0, pass: true, gold: true, canopy: '#ffe066', stripe: '#ff9b2e' }
];

const TOOLS = [
  { id: 'standard', name: 'STANDARD PICKAXE', short: 'PICKAXE', rarity: 'common', price: 0, free: true, style: 'standard' },
  { id: 'books',    name: 'SCHOOL BOOKS',     short: 'BOOKS',   rarity: 'legendary', price: 800, collab: true, style: 'books' }
];

const BACKBLING_BY_ID = {};
for (const b of BACKBLINGS) BACKBLING_BY_ID[b.id] = b;
const EMOTE_BY_ID = {};
for (const e of EMOTES) EMOTE_BY_ID[e.id] = e;
const GLIDER_BY_ID = {};
for (const g of GLIDERS) GLIDER_BY_ID[g.id] = g;
const TOOL_BY_ID = {};
for (const t of TOOLS) TOOL_BY_ID[t.id] = t;

/* ------------------------ season / battle pass ------------------- */
const SEASON = {
  id: 2,
  name: 'SAFARI SANDS',
  number: '02',
  grant: 300,
  xpPerTier: 200,
  tiers: 12,
  goldPrice: 800
};

const PASS_OUTFIT = {
  acacia: SKINS.findIndex((s) => s.name === 'ACACIA RANGER'),
  raider: SKINS.findIndex((s) => s.name === 'DUNE RAIDER'),
  oasis:  SKINS.findIndex((s) => s.name === 'GOLDEN OASIS')
};

/* 12 tiers — one reward each, claimed individually once unlocked */
const PASS_TIERS = [
  { tier: 1,  reward: { type: 'tokens', amount: 50,  label: '50 TOKENS' } },
  { tier: 2,  reward: { type: 'item', id: 'b:canteen', label: 'SAFARI CANTEEN' } },
  { tier: 3,  reward: { type: 'item', id: 'e:safari',  label: 'SAFARI STRUT' } },
  { tier: 4,  reward: { type: 'tokens', amount: 75,  label: '75 TOKENS' } },
  { tier: 5,  reward: { type: 'item', id: 'o:' + PASS_OUTFIT.acacia, label: 'ACACIA RANGER' } },
  { tier: 6,  reward: { type: 'item', id: 'g:dune',    label: 'DUNE DRIFTER' } },
  { tier: 7,  reward: { type: 'tokens', amount: 100, label: '100 TOKENS' } },
  { tier: 8,  reward: { type: 'item', id: 'b:binos',   label: 'FIELD BINOCULARS' } },
  { tier: 9,  reward: { type: 'tokens', amount: 125, label: '125 TOKENS' } },
  { tier: 10, reward: { type: 'item', id: 'o:' + PASS_OUTFIT.raider, label: 'DUNE RAIDER' } },
  { tier: 11, reward: { type: 'tokens', amount: 150, label: '150 TOKENS' } },
  { tier: 12, reward: { type: 'item', id: 'o:' + PASS_OUTFIT.oasis, label: 'GOLDEN OASIS' } }
];

/* ---- GOLD track: same tier ladder, better rewards (800 tokens) ---- */
const GOLD_OUTFIT = {
  pharaoh: SKINS.findIndex((s) => s.name === 'GILDED PHARAOH'),
  crown:   SKINS.findIndex((s) => s.name === 'SUN CROWN'),
  black:   SKINS.findIndex((s) => s.name === 'BLACK GOLD'),
  midas:   SKINS.findIndex((s) => s.name === 'MIDAS RANGER')
};

const GOLD_PASS_TIERS = [
  { tier: 1,  reward: { type: 'tokens', amount: 100, label: '100 TOKENS' } },
  { tier: 2,  reward: { type: 'item', id: 'e:gold',   label: 'GOLD SHUFFLE' } },
  { tier: 3,  reward: { type: 'item', id: 'b:idol',   label: 'GOLDEN IDOL' } },
  { tier: 4,  reward: { type: 'tokens', amount: 200, label: '200 TOKENS' } },
  { tier: 5,  reward: { type: 'item', id: 'o:' + GOLD_OUTFIT.pharaoh, label: 'GILDED PHARAOH' } },
  { tier: 6,  reward: { type: 'item', id: 'g:sun',    label: 'GOLDEN SUN' } },
  { tier: 7,  reward: { type: 'tokens', amount: 300, label: '300 TOKENS' } },
  { tier: 8,  reward: { type: 'item', id: 'b:vault',  label: 'TREASURE VAULT' } },
  { tier: 9,  reward: { type: 'tokens', amount: 400, label: '400 TOKENS' } },
  { tier: 10, reward: { type: 'item', id: 'o:' + GOLD_OUTFIT.crown, label: 'SUN CROWN' } },
  { tier: 11, reward: { type: 'item', id: 'o:' + GOLD_OUTFIT.black, label: 'BLACK GOLD' } },
  { tier: 12, reward: { type: 'item', id: 'o:' + GOLD_OUTFIT.midas, label: 'MIDAS RANGER' } }
];

/* --------------------------- player profile ---------------------- */
const PROFILE_KEY = 'stormroyale.profile';

function defaultProfile() {
  return {
    tokens: 0,
    season: { id: 0, xp: 0, claimed: [], gold: false, goldClaimed: [] },
    owned: ['o:0', 'o:1', 'o:2', 'o:3', 'o:4', 'o:5', 'o:6', 'o:7', 'b:pack', 'e:none', 'g:standard', 'p:standard'],
    equipped: { outfit: 0, backbling: 'pack', emote: 'none', glider: 'standard', tool: 'standard' },
    styles: {},
    quest: { matches: 0, kills: 0, chests: 0, claimed: false },
    sensitivity: 1.2,
    easy: true
  };
}

let profile = null;

function loadProfile() {
  const p = defaultProfile();
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (raw) {
      const saved = JSON.parse(raw);
      p.tokens = Math.max(0, saved.tokens | 0);
      if (Array.isArray(saved.owned)) {
        for (const id of saved.owned) if (typeof id === 'string' && p.owned.indexOf(id) < 0) p.owned.push(id);
      }
      const eq = saved.equipped || {};
      if (Number.isInteger(eq.outfit) && eq.outfit >= 0 && eq.outfit < SKINS.length) p.equipped.outfit = eq.outfit;
      if (BACKBLING_BY_ID[eq.backbling]) p.equipped.backbling = eq.backbling;
      if (EMOTE_BY_ID[eq.emote]) p.equipped.emote = eq.emote;
      if (GLIDER_BY_ID[eq.glider]) p.equipped.glider = eq.glider;
      if (TOOL_BY_ID[eq.tool]) p.equipped.tool = eq.tool;
      const st = saved.styles || {};
      for (const key of Object.keys(st)) {
        const m = /^o:(\d+)$/.exec(key);
        if (!m) continue;
        const idx = Number(m[1]);
        if (idx < 0 || idx >= SKINS.length) continue;
        const raw = st[key];
        const ids = Array.isArray(raw) ? raw : (typeof raw === 'string' ? [raw] : []);
        const keep = ids.filter((id) => skinEditStyles(idx).some((x) => x.id === id));
        if (keep.length) p.styles[key] = keep;
      }
      const q = saved.quest || {};
      for (const st of QUEST_STEPS) {
        if (typeof q[st.key] === 'number' && q[st.key] >= 0) p.quest[st.key] = Math.min(9999, q[st.key] | 0);
      }
      p.quest.claimed = !!q.claimed;
      const s = saved.season || {};
      if (s.id === SEASON.id) {
        p.season.id = SEASON.id;
        p.season.xp = Math.max(0, s.xp | 0);
        if (Array.isArray(s.claimed)) {
          for (const t of s.claimed) if (Number.isInteger(t) && t >= 1 && t <= SEASON.tiers) p.season.claimed.push(t);
        }
        p.season.gold = !!s.gold;
        if (Array.isArray(s.goldClaimed)) {
          for (const t of s.goldClaimed) if (Number.isInteger(t) && t >= 1 && t <= SEASON.tiers) p.season.goldClaimed.push(t);
        }
      }
      if (typeof saved.sensitivity === 'number') p.sensitivity = clamp(saved.sensitivity, 0.4, 2.6);
      if (typeof saved.easy === 'boolean') p.easy = saved.easy;
    } else {
      const legacy = parseInt(localStorage.getItem('stormroyale.skin'), 10);
      if (legacy >= 0 && legacy < SKINS.length) p.equipped.outfit = legacy;
    }
  } catch (e) { /* storage unavailable */ }
  profile = p;
  return p;
}

function saveProfile() {
  try { localStorage.setItem(PROFILE_KEY, JSON.stringify(profile)); } catch (e) { /* ignore */ }
}

function hasItem(id) { return profile.owned.indexOf(id) >= 0; }

function ownItem(id) {
  if (!hasItem(id)) { profile.owned.push(id); saveProfile(); }
}

function localDayKey(d) {
  d = d || new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

/** Migrates the profile into the current season. Returns tokens granted (0 if already on this season). */
function syncSeason() {
  if (!profile.season || profile.season.id !== SEASON.id) {
    profile.season = { id: SEASON.id, xp: 0, claimed: [], gold: false, goldClaimed: [] };
    profile.tokens += SEASON.grant;
    saveProfile();
    return SEASON.grant;
  }
  return 0;
}

loadProfile();

const BOT_FIRST = ['Sweaty', 'Cracked', 'Silent', 'Tilted', 'Golden', 'Rapid', 'Neon', 'Frosty', 'Lucky', 'Salty', 'Sneaky', 'Turbo', 'Cosmic', 'Rogue', 'Wild', 'Mellow', 'Angry', 'Spicy', 'Shadow', 'Blazing', 'Chill', 'Hyper', 'Fuzzy', 'Slick'];
const BOT_LAST = ['Llama', 'Taco', 'Pine', 'Falcon', 'Noodle', 'Cactus', 'Comet', 'Waffle', 'Viper', 'Muffin', 'Dragon', 'Penguin', 'Goblin', 'Sparrow', 'Yeti', 'Bandit', 'Wizard', 'Biscuit', 'Raptor', 'Turtle', 'Ninja', 'Bagel', 'Wolf', 'Rocket'];

/* ----------------------------- dom ------------------------------- */
const $ = (id) => document.getElementById(id);
const ui = {
  canvas: $('game'), mini: $('minimap'),
  hud: $('hud'), menu: $('menu'), dead: $('dead'), won: $('won'), pause: $('pause'),
  lobby: $('lobby'), skinGrid: $('skinGrid'), skinName: $('skinName'), charSvg: $('charSvg'),
  lobbyStyles: $('lobbyStyles'),
  dropBtn: $('dropBtn'), backBtn: $('backBtn'), lobbyLockerBtn: $('lobbyLockerBtn'), lobbyTokens: $('lobbyTokens'),
  locker: $('locker'), lockerSvg: $('lockerSvg'), lockerTabs: $('lockerTabs'), lockerGrid: $('lockerGrid'),
  lockerOutfitName: $('lockerOutfitName'), lockerItemName: $('lockerItemName'), lockerStyles: $('lockerStyles'),
  lockerEmoteBtn: $('lockerEmoteBtn'), lockerClose: $('lockerClose'), lockerTokens: $('lockerTokens'),
  shop: $('shop'), shopGrid: $('shopGrid'), shopGridAll: $('shopGridAll'), shopGridCollab: $('shopGridCollab'), shopReset: $('shopReset'),
  shopClose: $('shopClose'), shopTokens: $('shopTokens'), menuTokens: $('menuTokens'),
  banner: $('banner'),
  aliveNum: $('aliveNum'), elimsNum: $('elimsNum'),
  stormLabel: $('stormLabel'), stormTimer: $('stormTimer'),
  killfeed: $('killfeed'), poiLabel: $('poiLabel'),
  healthFill: $('healthFill'), healthText: $('healthText'),
  shieldFill: $('shieldFill'), shieldText: $('shieldText'),
  shieldPots: $('shieldPots'), medKits: $('medKits'),
  slots: $('slots'), ammoMag: $('ammoMag'), ammoRes: $('ammoRes'), woodNum: $('woodNum'),
  prompt: $('prompt'), promptText: $('promptText'), toasts: $('toasts'),
  vignette: $('damageVignette'), lowHealth: $('lowHealth'),
  crosshair: $('crosshair'), scope: $('scope'), fixedCursor: $('fixedCursor'),
  leaveHold: $('leaveHold'), leaveFill: $('leaveFill'),
  emoteWheel: $('emoteWheel'), emoteRing: $('emoteRing'),
  emoteHub: $('emoteHub'), emoteHubName: $('emoteHubName'),
  deadPlace: $('deadPlace'), deadKills: $('deadKills'), deadTime: $('deadTime'), deadDmg: $('deadDmg'), deadXp: $('deadXp'),
  wonKills: $('wonKills'), wonTime: $('wonTime'), wonDmg: $('wonDmg'), wonXp: $('wonXp'),
  confetti: $('confetti'),
  owner: $('owner'), ownerBalance: $('ownerBalance'), ownerAmount: $('ownerAmount'),
  ownerMsg: $('ownerMsg'),
  checkout: $('checkout'), checkoutPack: $('checkoutPack'), checkoutPrice: $('checkoutPrice'),
  checkoutTokens: $('checkoutTokens'), checkoutForm: $('checkoutForm'), checkoutDone: $('checkoutDone'),
  checkoutGain: $('checkoutGain'),
  ccName: $('ccName'), ccNum: $('ccNum'), ccExp: $('ccExp'), ccCvc: $('ccCvc'), ccError: $('ccError'),
  ccPay: $('ccPay'), ccCollect: $('ccCollect'),
  questSteps: $('questSteps'), questClaim: $('questClaim'), questCard: $('questCard'),
  tokenPacks: $('tokenPacks'),
  pass: $('pass'), passGrid: $('passGrid'), passClose: $('passClose'), passTokens: $('passTokens'),
  passTabFree: $('passTabFree'), passTabGold: $('passTabGold'), passGoldTag: $('passGoldTag'),
  passGoldCta: $('passGoldCta'), passGoldBuy: $('passGoldBuy'), passGoldPrice: $('passGoldPrice'),
  passTierText: $('passTierText'), passXpFill: $('passXpFill'), passXpText: $('passXpText'),
  passXpNote: $('passXpNote'),
  sensRange: $('sensRange'), sensVal: $('sensVal'), easyToggle: $('easyToggle')
};
const ctx = ui.canvas.getContext('2d');
const mctx = ui.mini.getContext('2d');

/* ---------------------------- runtime ---------------------------- */
let dpr = 1, viewW = 0, viewH = 0;
let terrain = null;
let world = null;
let fighters = [], bots = [], bullets = [], particles = [], texts = [];
let storm = null, player = null, supplyTimer = 0;

const game = {
  state: 'menu',          // menu | drop | playing | paused | dead | won
  time: 0,
  alive: 50,
  total: 50,
  placement: 0,
  shake: 0,
  camX: HALF, camY: HALF, camZoom: 1,
  view: 'third',
  yaw: -Math.PI / 2,
  pitch: 0.1,
  menuT: 0,
  interact: null,
  stormTick: 0,
  chests: 0,
  rulesOpen: false
};

const keys = Object.create(null);
const mouse = { x: 0, y: 0, down: false, clicked: false, right: false, moveX: 0, moveY: 0 };

/* ----------------------------- audio ----------------------------- */
const Sound = {
  ctx: null, master: null, noiseBuf: null,
  init() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try { this.ctx = new AC(); } catch (e) { return; }
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.5;
    this.master.connect(this.ctx.destination);
    const len = Math.floor(this.ctx.sampleRate * 0.35);
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.noiseBuf = buf;
  },
  tone(freq, dur, type, vol, endFreq, delay) {
    if (!this.ctx) return;
    const t0 = this.ctx.currentTime + (delay || 0);
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, t0);
    if (endFreq) o.frequency.exponentialRampToValueAtTime(Math.max(25, endFreq), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, vol), t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(this.master);
    o.start(t0); o.stop(t0 + dur + 0.03);
  },
  noise(dur, vol, freq, q) {
    if (!this.ctx) return;
    const t0 = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q || 1;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f); f.connect(g); g.connect(this.master);
    src.start(t0); src.stop(t0 + dur + 0.02);
  }
};

function sfx(name, arg) {
  if (!Sound.ctx) return;
  switch (name) {
    case 'shoot': {
      const k = arg || 'ar';
      if (k === 'shotgun') {
        Sound.noise(0.16, 0.26, 650, 0.7); Sound.tone(95, 0.13, 'sawtooth', 0.12, 48);
      } else if (k === 'sniper') {
        Sound.noise(0.24, 0.30, 560, 0.6); Sound.tone(70, 0.22, 'sawtooth', 0.15, 32);
      } else if (k === 'smg') {
        Sound.noise(0.045, 0.11, 1900, 1.3); Sound.tone(200, 0.04, 'square', 0.05, 120);
      } else if (k === 'pistol') {
        Sound.noise(0.06, 0.13, 1250, 1); Sound.tone(170, 0.05, 'square', 0.06, 100);
      } else {
        Sound.noise(0.07, 0.16, 1350, 0.9); Sound.tone(140, 0.07, 'square', 0.09, 70);
      }
      break;
    }
    case 'hit': Sound.tone(1050, 0.045, 'square', 0.07, 1500); break;
    case 'hurt': Sound.tone(190, 0.16, 'sawtooth', 0.13, 90); Sound.noise(0.1, 0.1, 400, 1); break;
    case 'pickup': Sound.tone(680, 0.06, 'sine', 0.11, 900); Sound.tone(1020, 0.07, 'sine', 0.09, 1200, 0.05); break;
    case 'chest':
      Sound.tone(520, 0.09, 'triangle', 0.12, 660);
      Sound.tone(780, 0.1, 'triangle', 0.11, 980, 0.08);
      Sound.tone(1040, 0.14, 'triangle', 0.1, 1320, 0.16);
      break;
    case 'build': Sound.tone(320, 0.06, 'square', 0.09, 220); Sound.noise(0.06, 0.08, 900, 1); break;
    case 'reload': Sound.tone(240, 0.05, 'square', 0.07, 180); Sound.tone(300, 0.05, 'square', 0.06, 220, 0.12); break;
    case 'elim': Sound.tone(880, 0.1, 'triangle', 0.12, 1100); Sound.tone(1320, 0.16, 'triangle', 0.1, 1600, 0.08); break;
    case 'win':
      [523, 659, 784, 1046, 1318].forEach((f, i) => Sound.tone(f, 0.5, 'triangle', 0.13, f, i * 0.13));
      break;
    case 'death':
      Sound.tone(320, 0.5, 'sawtooth', 0.13, 70);
      break;
    case 'error': Sound.tone(150, 0.1, 'square', 0.09, 110); break;
    case 'tick': Sound.tone(520, 0.03, 'sine', 0.05, 620); break;
    case 'storm': Sound.tone(60, 0.6, 'sine', 0.09, 42); break;
  }
}
