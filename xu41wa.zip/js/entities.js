'use strict';
/* ==================================================================
   STORM ROYALE — fighters, weapons, bullets, loot, storm, FX
   ================================================================== */

/* --------------------------- fighters ---------------------------- */
function makeFighter(x, y, isPlayer) {
  return {
    x, y, r: 16, hp: 100, maxHp: 100, shield: 0, maxShield: 100,
    alive: true, isPlayer: !!isPlayer,
    aim: 0, speed: 258, sprint: 1, fireCd: 0, reloadT: 0, reloadDur: 1,
    weapons: new Array(WEAPON_SLOTS).fill(null), slot: 0,
    wood: 0, kills: 0, dmgDealt: 0, shieldPots: 0, medkits: 0,
    useT: 0, useDur: 0, useType: null,
    hitFlash: 0, walkT: 0, walkAmp: 0, z: 0, name: 'YOU', color: '#4ee6ff',
    emote: 'none', emoteT: 0, emoteTick: 0, backbling: 'pack', glider: null,
    skill: 1, target: null, thinkCd: 0, objective: null, vision: 700,
    strafe: 1, strafeT: 0, pref: 420, wantFire: false, muzzle: 0,
    looted: false
  };
}

function makeWeapon(kind, rarity, ammo) {
  return {
    type: 'weapon', kind, rarity,
    ammo: ammo == null ? WEAPONS[kind].mag : ammo
  };
}

function rollWeaponKind() {
  const r = Math.random() * 100;
  if (r < 29) return 'ar';
  if (r < 51) return 'shotgun';
  if (r < 71) return 'smg';
  if (r < 81) return 'pistol';
  return 'sniper';
}
function rollRarity(tier) {
  const r = Math.random() * 100 + (tier || 0) * 17;
  if (r < 40) return 0;
  if (r < 71) return 1;
  if (r < 87) return 2;
  if (r < 96) return 3;
  return 4;
}
function rollWeapon(tier) {
  return makeWeapon(rollWeaponKind(), rollRarity(tier));
}

/* --------------------------- movement ---------------------------- */
function circlePush(f, o, min) {
  const dx = f.x - o.x, dy = f.y - o.y;
  const d = Math.hypot(dx, dy);
  if (d < min && d > 0.0001) {
    const p = min - d;
    f.x += (dx / d) * p;
    f.y += (dy / d) * p;
  }
}

function collide(f) {
  for (const w of world.walls) {
    if (w.dead) continue;
    if (f.x < w.minX - f.r || f.x > w.maxX + f.r || f.y < w.minY - f.r || f.y > w.maxY + f.r) continue;
    const c = closestOnSeg(f.x, f.y, w.ax, w.ay, w.bx, w.by);
    let dx = f.x - c.x, dy = f.y - c.y;
    let d = Math.hypot(dx, dy);
    const min = f.r + w.r;
    if (d < min) {
      if (d < 0.0001) { dx = 0; dy = -1; d = 1; }
      const push = min - d;
      f.x += (dx / d) * push;
      f.y += (dy / d) * push;
    }
  }
  for (const o of world.trees) if (!o.dead) circlePush(f, o, f.r + o.r * 0.62);
  for (const o of world.rocks) circlePush(f, o, f.r + o.r * 0.78);
}

function moveFighter(f, dt, dx, dy) {
  const len = Math.hypot(dx, dy);
  let sp = f.speed * (f.sprint || 1);
  if (f.isPlayer && keys['shift']) sp *= 1.36;
  if (f.useT > 0) sp *= 0.55;
  if (len > 0.0001) { dx /= len; dy /= len; } else { dx = 0; dy = 0; }
  if (dx || dy) { f.walkT += dt; f.walkAmp = Math.min(1, (f.walkAmp || 0) + dt * 8); if (f.emoteT > 0) { f.emoteT = 0; f.emote = 'none'; } }
  else f.walkAmp = Math.max(0, (f.walkAmp || 0) - dt * 8);
  f.x += dx * sp * dt;
  f.y += dy * sp * dt;
  collide(f);
  f.x = clamp(f.x, f.r + 4, WORLD - f.r - 4);
  f.y = clamp(f.y, f.r + 4, WORLD - f.r - 4);
}

/* ---------------------------- weapons ---------------------------- */
function startReload(f) {
  const w = f.weapons[f.slot];
  if (!w || f.reloadT > 0) return;
  if (w.ammo >= WEAPONS[w.kind].mag) return;
  f.reloadT = WEAPONS[w.kind].reload;
  f.reloadDur = f.reloadT;
  if (f.isPlayer) sfx('reload');
}

function tickWeapon(f, dt) {
  if (f.fireCd > 0) f.fireCd -= dt;
  if (f.hitFlash > 0) f.hitFlash -= dt;
  if (f.muzzle > 0) f.muzzle -= dt;
  if (f.swing > 0) f.swing -= dt;
  if (f.emoteT > 0) {
    f.emoteT -= dt;
    f.emoteTick = (f.emoteTick || 0) - dt;
    if (f.emoteTick <= 0) {
      f.emoteTick = 0.46;
      addText(f.x + rnd(-13, 13), f.y - 46 - rnd(0, 12),
        Math.random() < 0.5 ? '♪' : '♫', f.color || '#fff', 17, 1.0);
    }
    if (f.emoteT <= 0) f.emote = 'none';
  }
  if (f.reloadT > 0) {
    f.reloadT -= dt;
    if (f.reloadT <= 0) {
      const w = f.weapons[f.slot];
      if (w) w.ammo = WEAPONS[w.kind].mag;
    }
  }
}

function fireWeapon(f, def, angle) {
  const w = f.weapons[f.slot];
  if (!w) return;
  if (f.emoteT > 0) { f.emoteT = 0; f.emote = 'none'; }
  const rar = RARITY[w.rarity];
  const n = def.pellets;
  const dmgMul = f.isPlayer ? 1 : def.botMul;
  let spread = def.spread;
  if (f.isPlayer) {
    if (mouse.right) spread *= 0.45;
    if (f.isPlayer && keys['shift']) spread *= 1.25;
    if (w.kind === 'sniper' && mouse.right) spread = 0.0015;
  } else {
    spread *= 2.2;
  }
  for (let i = 0; i < n; i++) {
    const a = angle + (Math.random() - 0.5) * spread * 2;
    const spd = def.speed * rnd(0.94, 1.06);
    const life = def.range / def.speed;
    bullets.push({
      x: f.x + Math.cos(angle) * 26,
      y: f.y + Math.sin(angle) * 26,
      vx: Math.cos(a) * spd, vy: Math.sin(a) * spd,
      dmg: def.dmg * rar.mult * dmgMul,
      owner: f, life, maxLife: life, color: rar.color,
      size: n > 1 ? 2.4 : 3, kind: w.kind
    });
  }
  f.muzzle = 0.06;
  f.fireCd = 60 / def.rpm;
  if (f.isPlayer) {
    game.shake = Math.min(10, game.shake + (w.kind === 'sniper' ? 6 : w.kind === 'shotgun' ? 3 : 1.3));
    spawnMuzzle(f.x + Math.cos(angle) * 24, f.y + Math.sin(angle) * 24, angle);
  }
}

/* Soft aim assist (easy controls): pulls the shot toward the nearest enemy
   inside a narrow cone of the aim direction. */
function assistAim(angle, range, cone) {
  if (!player || !profile || profile.easy === false) return angle;
  let best = null, bestD = range;
  for (const f of fighters) {
    if (f === player || !f.alive) continue;
    const d = dist(player.x, player.y, f.x, f.y);
    if (d >= bestD) continue;
    const a = Math.atan2(f.y - player.y, f.x - player.x);
    const off = Math.abs(norm(a - angle));
    const window = d < 160 ? 0.6 : cone;
    if (off < window) { best = a; bestD = d; }
  }
  return best == null ? angle : angle + norm(best - angle) * 0.9;
}

function playerShoot() {
  if (player.melee) { pickaxeSwing(); return; }
  const w = player.weapons[player.slot];
  if (!w || player.reloadT > 0 || player.fireCd > 0 || player.useT > 0) return;
  const def = WEAPONS[w.kind];
  if (w.ammo <= 0) { startReload(player); return; }
  if (!def.auto && !mouse.clicked) return;
  w.ammo--;
  const cone = w.kind === 'shotgun' ? 0.30 : w.kind === 'sniper' ? 0.11 : 0.17;
  fireWeapon(player, def, assistAim(player.aim, def.range, cone));
  sfx('shoot', w.kind);
  if (!def.auto) mouse.clicked = false;
}

/* Harvesting tool — every player carries one. */
function pickaxeSwing() {
  if (!player || !player.alive || player.fireCd > 0 || player.useT > 0) return;
  player.fireCd = 0.42;
  player.swing = 0.22;
  sfx('build');

  const a = player.aim;
  const cx = player.x + Math.cos(a) * 34;
  const cy = player.y + Math.sin(a) * 34;

  for (const f of fighters) {
    if (f === player || !f.alive) continue;
    if (dist(cx, cy, f.x, f.y) < 54) {
      damage(f, 42, player);
      spawnBlood(f.x, f.y, '#ff5566');
    }
  }
  for (const w of world.walls) {
    if (w.dead) continue;
    if (distToSeg(cx, cy, w.ax, w.ay, w.bx, w.by) < 48 + w.r) {
      damageWall(w, { dmg: 90, x: cx, y: cy, owner: player });
    }
  }
  for (const o of world.trees) {
    if (o.dead) continue;
    if (dist(cx, cy, o.x, o.y) < 48 + o.r) {
      o.hp -= 60;
      player.wood = Math.min(999, player.wood + 5);
      spawnSparks(o.x, o.y, '#8fdc6a');
      if (o.hp <= 0) {
        o.dead = true;
        player.wood = Math.min(999, player.wood + 24);
        addText(o.x, o.y - 26, '+24 WOOD', '#ffd08a', 15, 1.1);
        spawnLeaves(o.x, o.y);
      }
    }
  }
  for (const o of world.rocks) {
    if (dist(cx, cy, o.x, o.y) < 48 + o.r) {
      spawnSparks(o.x, o.y, '#d5d5d5');
      player.wood = Math.min(999, player.wood + 2);
    }
  }
}

function buildWall() {
  if (player.wood < 10) { toast('NEED 10 WOOD', 'red'); sfx('error'); return; }
  const a = player.aim;
  const cx = player.x + Math.cos(a) * 82;
  const cy = player.y + Math.sin(a) * 82;
  const half = 58;
  const nx = -Math.sin(a), ny = Math.cos(a);
  const ax = cx - nx * half, ay = cy - ny * half;
  const bx = cx + nx * half, by = cy + ny * half;
  for (const w of world.walls) {
    if (w.dead) continue;
    if (distToSeg(w.ax, w.ay, ax, ay, bx, by) < 18 || distToSeg(w.bx, w.by, ax, ay, bx, by) < 18) {
      toast('TOO CLOSE TO A WALL', 'red'); sfx('error'); return;
    }
  }
  world.walls.push(makeWall(ax, ay, bx, by, 220, 'built', player, 8));
  player.wood -= 10;
  sfx('build');
  for (let i = 0; i < 8; i++) spawnParticle(cx, cy, '#c99a5a', 90, 3, 0.4);
}

/* ----------------------------- bullets --------------------------- */
function damageWall(w, b) {
  w.hp -= b.dmg * 0.5;
  w.hitFlash = 0.12;
  spawnSparks(b.x, b.y, '#e6d7b0');
  if (w.hp <= 0) {
    w.dead = true;
    for (let i = 0; i < 8; i++) spawnParticle((w.ax + w.bx) / 2, (w.ay + w.by) / 2, w.kind === 'built' ? '#c99a5a' : '#c3b39a', 130, 4, 0.5);
  }
}

function hitObstacle(b) {
  for (const o of world.trees) {
    if (o.dead) continue;
    if (dist(b.x, b.y, o.x, o.y) < o.r * 0.66 + b.size) {
      o.hp -= b.dmg;
      if (b.owner && b.owner.isPlayer) {
        b.owner.wood = Math.min(999, b.owner.wood + 3);
        spawnSparks(b.x, b.y, '#8fdc6a');
        if (o.hp <= 0) {
          o.dead = true;
          b.owner.wood = Math.min(999, b.owner.wood + 24);
          addText(o.x, o.y - 26, '+24 WOOD', '#ffd08a', 15, 1.1);
          spawnLeaves(o.x, o.y);
        }
      }
      return true;
    }
  }
  for (const o of world.rocks) {
    if (dist(b.x, b.y, o.x, o.y) < o.r * 0.8 + b.size) {
      spawnSparks(b.x, b.y, '#d5d5d5');
      return true;
    }
  }
  return false;
}

function updateBullets(dt) {
  for (let i = bullets.length - 1; i >= 0; i--) {
    const b = bullets[i];
    const travel = Math.hypot(b.vx, b.vy) * dt;
    const steps = Math.max(1, Math.ceil(travel / 12));
    let hit = false;
    for (let s = 0; s < steps && !hit; s++) {
      b.x += (b.vx * dt) / steps;
      b.y += (b.vy * dt) / steps;

      for (const w of world.walls) {
        if (w.dead) continue;
        if (b.x < w.minX || b.x > w.maxX || b.y < w.minY || b.y > w.maxY) continue;
        if (distToSeg(b.x, b.y, w.ax, w.ay, w.bx, w.by) < w.r + b.size) {
          damageWall(w, b); hit = true; break;
        }
      }
      if (hit) break;

      if (hitObstacle(b)) { hit = true; break; }

      for (const f of fighters) {
        if (!f.alive || f === b.owner) continue;
        if (dist(b.x, b.y, f.x, f.y) < f.r + b.size) {
          damage(f, b.dmg, b.owner, b);
          hit = true; break;
        }
      }
    }
    b.life -= dt;
    if (hit || b.life <= 0 || b.x < 0 || b.y < 0 || b.x > WORLD || b.y > WORLD) bullets.splice(i, 1);
  }
}

/* ----------------------------- damage ---------------------------- */
function damage(t, amt, src, bullet) {
  if (!t.alive) return;
  // bots trading shots with each other are deliberately less lethal so the
  // lobby thins out over the match instead of collapsing in the first minute
  if (src && !src.isPlayer && !t.isPlayer) amt *= 0.28;
  let remaining = amt;
  if (t.shield > 0) {
    const absorbed = Math.min(t.shield, remaining);
    t.shield -= absorbed;
    remaining -= absorbed;
  }
  if (remaining > 0) t.hp -= remaining;
  t.hitFlash = 0.16;

  if (t.isPlayer) {
    game.shake = Math.min(18, game.shake + amt * 0.3);
    flashDamage();
    if (t.useT > 0) { t.useT = 0; t.useType = null; toast('ITEM CANCELED', 'red'); }
    sfx('hurt');
  }
  if (src && src.isPlayer) {
    src.dmgDealt += amt;
    hitMarker();
    addText(t.x + rnd(-10, 10), t.y - 22, String(Math.round(amt)), t.shield > 0 ? '#8fd8ff' : '#ffffff', 15, 0.75);
    sfx('hit');
  }
  spawnBlood(t.x, t.y, src && src.isPlayer ? '#ffe08a' : '#ff6b6b');
  if (t.hp <= 0) kill(t, src);
}

function kill(t, src) {
  if (!t.alive) return;
  const aliveBefore = fighters.reduce((n, f) => n + (f.alive ? 1 : 0), 0);
  t.alive = false;
  t.hp = 0;
  game.alive = aliveBefore - 1;

  if (t.isPlayer) {
    game.placement = aliveBefore;
    if (src && !src.isPlayer) addFeed(src.name, 'YOU', false);
    else if (!src) addFeed('THE STORM', 'YOU', false);
    spawnDeath(t.x, t.y, t.color);
    endMatch(false);
  } else {
    dropLootFrom(t);
    const killer = src && src.name ? src : null;
    const killerName = killer ? (killer.isPlayer ? 'YOU' : killer.name) : 'THE STORM';
    addFeed(killerName, t.name, !!(killer && killer.isPlayer));
    spawnDeath(t.x, t.y, t.color);
    if (killer && killer.isPlayer) {
      killer.kills++;
      questAdd('kills', 1);
      toast('ELIMINATED ' + t.name.toUpperCase(), 'gold');
      sfx('elim');
      game.shake = Math.min(14, game.shake + 4);
    }
  }

  if (game.state === 'playing' && player && player.alive) {
    const alive = fighters.reduce((n, f) => n + (f.alive ? 1 : 0), 0);
    game.alive = alive;
    if (alive <= 1) endMatch(true);
  }
}

/* ------------------------------ loot ----------------------------- */
function dropLootFrom(t) {
  const w = t.weapons.find((x) => x);
  if (w) world.loot.push({ x: t.x + rnd(-16, 16), y: t.y + rnd(-16, 16), item: makeWeapon(w.kind, w.rarity, WEAPONS[w.kind].mag), bob: rnd(0, TAU) });
  if (t.wood > 0) world.loot.push({ x: t.x + rnd(-18, 18), y: t.y + rnd(-18, 18), item: { type: 'wood', amount: t.wood }, bob: rnd(0, TAU) });
  if (Math.random() < 0.4) world.loot.push({ x: t.x + rnd(-20, 20), y: t.y + rnd(-20, 20), item: { type: 'shield' }, bob: rnd(0, TAU) });
}

function spawnLootItems(x, y, n, tier) {
  for (let i = 0; i < n; i++) {
    const a = rnd(0, TAU), d = rnd(30, 56);
    const r = Math.random();
    let item;
    if (r < 0.68) item = rollWeapon(tier);
    else if (r < 0.92) item = { type: 'shield' };
    else item = { type: 'med' };
    world.loot.push({ x: clamp(x + Math.cos(a) * d, 30, WORLD - 30), y: clamp(y + Math.sin(a) * d, 30, WORLD - 30), item, bob: rnd(0, TAU) });
  }
}

function openChest(ch) {
  if (ch.opened) return;
  ch.opened = true;
  game.chests = (game.chests || 0) + 1;
  questAdd('chests', 1);
  sfx('chest');
  spawnLootItems(ch.x, ch.y, ch.isSupply ? 3 : 2, ch.tier || 0);
  for (let i = 0; i < 22; i++) spawnParticle(ch.x, ch.y, i % 3 === 0 ? '#fff3b0' : '#ffc93c', 150, 3, 0.7);
  addText(ch.x, ch.y - 30, ch.isSupply ? 'SUPPLY DROP' : 'CHEST', '#ffd75e', 14, 1);
}

function openCrate(c) {
  if (c.opened) return;
  c.opened = true;
  player.wood = Math.min(999, player.wood + c.wood);
  addText(c.x, c.y - 26, '+' + c.wood + ' WOOD', '#ffd08a', 15, 1);
  sfx('pickup');
  for (let i = 0; i < 10; i++) spawnParticle(c.x, c.y, '#c99a5a', 90, 3, 0.5);
}

/* ------------------------------ storm ---------------------------- */
function initStorm() {
  storm = {
    x: HALF, y: HALF, r: 1850, dps: PHASES[0].dps, phase: 0,
    state: 'wait', timer: PHASES[0].wait, shrinkT: 0, shrinkDur: 1,
    sx: HALF, sy: HALF, sr: 1850, tx: HALF, ty: HALF, tr: 1850
  };
}

function beginShrink() {
  const p = storm.phase < PHASES.length ? PHASES[storm.phase] : null;
  const targetR = p ? p.r : Math.max(26, storm.r * 0.55);
  const maxOff = Math.max(0, storm.r - targetR - 12);
  const a = Math.random() * TAU, d = Math.sqrt(Math.random()) * maxOff;
  storm.sx = storm.x; storm.sy = storm.y; storm.sr = storm.r;
  storm.tx = storm.x + Math.cos(a) * d;
  storm.ty = storm.y + Math.sin(a) * d;
  storm.tr = targetR;
  if (targetR + 60 < HALF) {
    storm.tx = clamp(storm.tx, targetR + 60, WORLD - targetR - 60);
    storm.ty = clamp(storm.ty, targetR + 60, WORLD - targetR - 60);
  }
  storm.state = 'shrink';
  storm.shrinkT = 0;
  storm.shrinkDur = p ? p.shrink : 22;
  storm.dps = p ? p.dps : 18;
  sfx('storm');
  if (game.state === 'playing') toast('THE STORM IS CLOSING IN', 'blue');
}

function updateStorm(dt) {
  if (game.state !== 'playing') return;

  if (storm.state === 'wait') {
    storm.timer -= dt;
    if (storm.timer <= 0) beginShrink();
  } else {
    storm.shrinkT += dt;
    const t = clamp(storm.shrinkT / storm.shrinkDur, 0, 1);
    const e = easeInOut(t);
    storm.r = lerp(storm.sr, storm.tr, e);
    storm.x = lerp(storm.sx, storm.tx, e);
    storm.y = lerp(storm.sy, storm.ty, e);
    storm.timer = Math.max(0, storm.shrinkDur - storm.shrinkT);
    if (t >= 1) {
      storm.phase++;
      storm.state = 'wait';
      storm.timer = storm.phase < PHASES.length ? PHASES[storm.phase].wait : 16;
      storm.dps = storm.phase < PHASES.length ? PHASES[storm.phase].dps : 20;
    }
  }

  game.stormTick -= dt;
  if (game.stormTick <= 0) {
    game.stormTick = 0.5;
    const dmg = storm.dps * 0.5;
    for (const f of fighters) {
      if (!f.alive) continue;
      if (dist(f.x, f.y, storm.x, storm.y) > storm.r) {
        f.hp -= dmg;
        f.hitFlash = 0.1;
        if (f.isPlayer) flashDamage();
        if (f.hp <= 0) kill(f, null);
      }
    }
  }
}

function spawnSupply() {
  if (!storm) return;
  const a = Math.random() * TAU;
  const d = Math.sqrt(Math.random()) * Math.max(120, storm.r * 0.85);
  const x = clamp(storm.x + Math.cos(a) * d, 130, WORLD - 130);
  const y = clamp(storm.y + Math.sin(a) * d, 130, WORLD - 130);
  world.supplies.push({ x, y, r: 26, opened: false, z: 1, isSupply: true, tier: 4, pulse: 0 });
  toast('SUPPLY DROP INBOUND', 'gold');
  sfx('storm');
}

function updateSupplies(dt) {
  for (const s of world.supplies) {
    if (s.z > 0) s.z = Math.max(0, s.z - dt * 0.55);
  }
}

/* ----------------------------- effects --------------------------- */
function spawnParticle(x, y, color, spd, size, life) {
  if (particles.length > 900) return;
  const a = Math.random() * TAU, s = rnd(spd * 0.3, spd);
  const lf = life || rnd(0.3, 0.7);
  particles.push({
    x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
    life: lf, max: lf, color, size: size || rnd(2, 4.5)
  });
}

function spawnBurst(x, y, color, n, spd) {
  for (let i = 0; i < n; i++) spawnParticle(x, y, color, spd || 160);
}

function spawnSparks(x, y, color) {
  for (let i = 0; i < 4; i++) spawnParticle(x, y, color, 130, 2, 0.25);
}
function spawnBlood(x, y, color) {
  for (let i = 0; i < 5; i++) spawnParticle(x, y, color, 120, 2.5, 0.35);
}
function spawnLeaves(x, y) {
  for (let i = 0; i < 18; i++) spawnParticle(x, y, i % 2 ? '#4f9e43' : '#7bc45e', 100, 4, 0.8);
}
function spawnMuzzle(x, y, angle) {
  for (let i = 0; i < 5; i++) {
    const a = angle + rnd(-0.5, 0.5), s = rnd(70, 190);
    const lf = rnd(0.06, 0.16);
    particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: lf, max: lf, color: '#ffe6a1', size: rnd(2, 4) });
  }
}
function spawnDeath(x, y, color) {
  for (let i = 0; i < 26; i++) spawnParticle(x, y, i % 3 ? color : '#ffffff', 220, 4, 0.8);
}

function addText(x, y, text, color, size, life) {
  const lf = life || 0.9;
  if (texts.length > 60) texts.shift();
  texts.push({ x, y, text, color: color || '#fff', size: size || 14, life: lf, max: lf });
}

function updateParticles(dt) {
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vx *= 0.93;
    p.vy *= 0.93;
    p.life -= dt;
    if (p.life <= 0) particles.splice(i, 1);
  }
  for (let i = texts.length - 1; i >= 0; i--) {
    const t = texts[i];
    t.y -= 34 * dt;
    t.life -= dt;
    if (t.life <= 0) texts.splice(i, 1);
  }
}
