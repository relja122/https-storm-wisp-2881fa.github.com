'use strict';
/* ==================================================================
   STORM ROYALE — island generation + pre-rendered terrain
   ================================================================== */

let wrng = mulberry32(1);
const wr = (a = 0, b = 1) => a + wrng() * (b - a);
const wi = (a, b) => Math.floor(wr(a, b + 1));
const wpick = (arr) => arr[Math.floor(wrng() * arr.length)];

function newWorld() {
  world = {
    walls: [], buildings: [], trees: [], rocks: [], crates: [],
    chests: [], supplies: [], loot: [], zones: [], lakes: [], roads: []
  };
}

function makeWall(ax, ay, bx, by, hp, kind, owner, r) {
  return {
    ax, ay, bx, by, hp, maxHp: hp, kind, owner: owner || null,
    r: r || 8, dead: false, hitFlash: 0,
    minX: Math.min(ax, bx) - r - 2, maxX: Math.max(ax, bx) + r + 2,
    minY: Math.min(ay, by) - r - 2, maxY: Math.max(ay, by) + r + 2
  };
}

function rectOverlaps(x0, y0, x1, y1, pad) {
  pad = pad || 0;
  for (const b of world.buildings) {
    if (x0 < b.x1 + pad && x1 > b.x0 - pad && y0 < b.y1 + pad && y1 > b.y0 - pad) return true;
  }
  return false;
}

function insideAnyBuilding(x, y, pad) {
  for (const b of world.buildings) {
    if (x > b.x0 - pad && x < b.x1 + pad && y > b.y0 - pad && y < b.y1 + pad) return true;
  }
  return false;
}

function nearLake(x, y, pad) {
  for (const l of world.lakes) {
    const dx = (x - l.x) / (l.rx + pad), dy = (y - l.y) / (l.ry + pad);
    if (dx * dx + dy * dy < 1) return true;
  }
  return false;
}

/* --------------------------- buildings --------------------------- */
function addBuilding(cx, cy, w, h, tier, label) {
  const x0 = cx - w / 2, y0 = cy - h / 2, x1 = cx + w / 2, y1 = cy + h / 2;
  if (rectOverlaps(x0, y0, x1, y1, 70)) return false;
  if (x0 < 90 || y0 < 90 || x1 > WORLD - 90 || y1 > WORLD - 90) return false;
  if (nearLake(cx, cy, 30)) return false;

  const doorSide = wi(0, 3);
  const doorW = 92;
  const hp = 450;
  const r = 9;
  const mk = (ax, ay, bx, by) => world.walls.push(makeWall(ax, ay, bx, by, hp, 'house', null, r));

  function side(ax, ay, bx, by, door) {
    if (!door) { mk(ax, ay, bx, by); return; }
    const mx = (ax + bx) / 2, my = (ay + by) / 2;
    const dx = bx - ax, dy = by - ay;
    const len = Math.hypot(dx, dy) || 1;
    const ux = dx / len, uy = dy / len;
    mk(ax, ay, mx - ux * doorW / 2, my - uy * doorW / 2);
    mk(mx + ux * doorW / 2, my + uy * doorW / 2, bx, by);
  }
  side(x0, y0, x1, y0, doorSide === 0);
  side(x1, y0, x1, y1, doorSide === 1);
  side(x1, y1, x0, y1, doorSide === 2);
  side(x0, y1, x0, y0, doorSide === 3);

  const b = {
    x0, y0, x1, y1, cx, cy, tier: tier || 0, label: label || '',
    color: wpick(['#6b5744', '#5a5760', '#6a5949', '#545a67', '#635043'])
  };
  world.buildings.push(b);

  const nChests = w * h > 62000 ? 2 : 1;
  for (let i = 0; i < nChests; i++) {
    world.chests.push({
      x: cx + wr(-w * 0.26, w * 0.26),
      y: cy + wr(-h * 0.26, h * 0.26),
      opened: false, tier: b.tier, r: 26, pulse: wrng() * TAU, isSupply: false
    });
  }
  if (wrng() < 0.55) {
    world.crates.push({
      x: cx + wr(-w * 0.3, w * 0.3),
      y: cy + wr(-h * 0.3, h * 0.3),
      opened: false, r: 22, wood: irnd(25, 55), rot: wr(-0.4, 0.4)
    });
  }
  return true;
}

/* ---------------------------- terrain ---------------------------- */
const TS = 0.5; // terrain texture scale

function generateWorld() {
  newWorld();
  wrng = mulberry32((Math.random() * 1e9) | 0);

  // zones / points of interest
  world.zones = ZONE_DEFS.map((z) => ({ ...z, x: clamp(z.x, 380, WORLD - 380), y: clamp(z.y, 380, WORLD - 380) }));

  // lakes
  for (let i = 0; i < 3; i++) {
    let lx = 0, ly = 0, ok = false;
    for (let tries = 0; tries < 30 && !ok; tries++) {
      lx = wr(520, WORLD - 520); ly = wr(520, WORLD - 520);
      ok = true;
      for (const z of world.zones) if (dist(lx, ly, z.x, z.y) < z.r + 320) ok = false;
      for (const l of world.lakes) if (dist(lx, ly, l.x, l.y) < 600) ok = false;
    }
    if (ok) world.lakes.push({ x: lx, y: ly, rx: wr(180, 300), ry: wr(130, 220), rot: wr(0, TAU) });
  }

  // buildings around the named zones
  for (const z of world.zones) {
    const want = z.buildings;
    let made = 0;
    for (let tries = 0; tries < 90 && made < want; tries++) {
      const a = wr(0, TAU), d = wr(40, z.r * 0.72);
      const bw = wr(180, 300), bh = wr(160, 280);
      if (addBuilding(z.x + Math.cos(a) * d, z.y + Math.sin(a) * d, bw, bh, z.tier, z.name)) made++;
    }
  }
  // scattered buildings
  let made = 0;
  for (let tries = 0; tries < 200 && made < 14; tries++) {
    const bw = wr(170, 300), bh = wr(150, 250);
    if (addBuilding(wr(260, WORLD - 260), wr(260, WORLD - 260), bw, bh, wi(0, 2), 'THE SAVANNA')) made++;
  }

  // roads: winding route through zones
  const order = [0, 6, 1, 5, 3, 4, 2, 0];
  world.roads = order.map((i) => ({ x: world.zones[i].x, y: world.zones[i].y }));

  // outdoor chests
  for (let i = 0; i < 12; i++) {
    let x, y, ok = false;
    for (let tries = 0; tries < 40 && !ok; tries++) {
      x = wr(200, WORLD - 200); y = wr(200, WORLD - 200);
      ok = !nearLake(x, y, 40);
    }
    if (ok) world.chests.push({ x, y, opened: false, tier: wi(0, 2), r: 26, pulse: wrng() * TAU, isSupply: false });
  }

  // trees
  let t = 0;
  for (let tries = 0; tries < 4000 && t < 270; tries++) {
    const x = wr(90, WORLD - 90), y = wr(90, WORLD - 90);
    if (insideAnyBuilding(x, y, 55) || nearLake(x, y, 20)) continue;
    if (dist(x, y, HALF, HALF) < 120) continue;
    world.trees.push({
      x, y, r: wr(17, 24), hp: 150, type: 'tree',
      seed: wrng() * TAU, scale: wr(0.85, 1.25)
    });
    t++;
  }
  // rocks
  let rk = 0;
  for (let tries = 0; tries < 2000 && rk < 80; tries++) {
    const x = wr(90, WORLD - 90), y = wr(90, WORLD - 90);
    if (insideAnyBuilding(x, y, 45) || nearLake(x, y, 10)) continue;
    world.rocks.push({ x, y, r: wr(22, 34), type: 'rock', seed: wrng() * TAU });
    rk++;
  }
  // crates
  let cr = 0;
  for (let tries = 0; tries < 1500 && cr < 75; tries++) {
    const x = wr(120, WORLD - 120), y = wr(120, WORLD - 120);
    if (insideAnyBuilding(x, y, 20) || nearLake(x, y, 15)) continue;
    world.crates.push({ x, y, opened: false, r: 22, wood: irnd(20, 50), rot: wr(-0.4, 0.4) });
    cr++;
  }

  renderTerrain();
}

function renderTerrain() {
  terrain = document.createElement('canvas');
  terrain.width = Math.floor(WORLD * TS);
  terrain.height = Math.floor(WORLD * TS);
  const t = terrain.getContext('2d');
  t.scale(TS, TS);

  // base sand
  const base = t.createLinearGradient(0, 0, WORLD, WORLD);
  base.addColorStop(0, '#c9a765');
  base.addColorStop(0.45, '#d8ba79');
  base.addColorStop(1, '#bd9958');
  t.fillStyle = base;
  t.fillRect(0, 0, WORLD, WORLD);

  // organic color blotches
  const blot = ['#b58f52', '#dcc089', '#e6d29c', '#c7a76b', '#a98a4e', '#d8c07a'];
  for (let i = 0; i < 620; i++) {
    const x = wr(0, WORLD), y = wr(0, WORLD), r = wr(70, 320);
    const c = wpick(blot);
    const g = t.createRadialGradient(x, y, r * 0.05, x, y, r);
    g.addColorStop(0, c);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    t.globalAlpha = 0.32;
    t.fillStyle = g;
    t.beginPath(); t.arc(x, y, r, 0, TAU); t.fill();
  }
  t.globalAlpha = 1;

  // lakes
  for (const l of world.lakes) {
    t.save();
    t.translate(l.x, l.y); t.rotate(l.rot);
    t.fillStyle = 'rgba(226,208,150,.55)';
    t.beginPath(); t.ellipse(0, 0, l.rx + 26, l.ry + 26, 0, 0, TAU); t.fill();
    const wg = t.createRadialGradient(0, 0, 10, 0, 0, Math.max(l.rx, l.ry));
    wg.addColorStop(0, '#45b3b8');
    wg.addColorStop(0.7, '#2b909b');
    wg.addColorStop(1, '#1d6f7c');
    t.fillStyle = wg;
    t.beginPath(); t.ellipse(0, 0, l.rx, l.ry, 0, 0, TAU); t.fill();
    t.globalAlpha = 0.18; t.strokeStyle = '#bfe9ff'; t.lineWidth = 6;
    t.beginPath(); t.ellipse(0, 0, l.rx * 0.6, l.ry * 0.55, 0, 0, TAU); t.stroke();
    t.restore();
    t.globalAlpha = 1;
  }

  // zone dirt pads
  for (const z of world.zones) {
    const g = t.createRadialGradient(z.x, z.y, z.r * 0.15, z.x, z.y, z.r * 1.15);
    g.addColorStop(0, 'rgba(190,168,120,.62)');
    g.addColorStop(0.7, 'rgba(176,158,112,.4)');
    g.addColorStop(1, 'rgba(176,158,112,0)');
    t.fillStyle = g;
    t.beginPath(); t.arc(z.x, z.y, z.r * 1.15, 0, TAU); t.fill();
  }

  // roads
  if (world.roads.length > 1) {
    t.lineCap = 'round'; t.lineJoin = 'round';
    t.beginPath();
    t.moveTo(world.roads[0].x, world.roads[0].y);
    for (let i = 1; i < world.roads.length; i++) t.lineTo(world.roads[i].x, world.roads[i].y);
    t.strokeStyle = 'rgba(92,70,42,.55)'; t.lineWidth = 104; t.stroke();
    t.strokeStyle = '#a2814f'; t.lineWidth = 88; t.stroke();
    t.strokeStyle = '#c2a468'; t.lineWidth = 78; t.stroke();
    t.setLineDash([46, 40]); t.strokeStyle = 'rgba(248,232,190,.55)'; t.lineWidth = 5; t.stroke();
    t.setLineDash([]);
  }

  // building plots
  for (const b of world.buildings) {
    t.fillStyle = 'rgba(120,104,84,.5)';
    t.beginPath();
    t.roundRect ? t.roundRect(b.x0 - 26, b.y0 - 26, b.x1 - b.x0 + 52, b.y1 - b.y0 + 52, 16)
                : t.rect(b.x0 - 26, b.y0 - 26, b.x1 - b.x0 + 52, b.y1 - b.y0 + 52);
    t.fill();
  }

  // subtle speckle texture
  t.globalAlpha = 0.12;
  for (let i = 0; i < 9000; i++) {
    const x = wr(0, WORLD), y = wr(0, WORLD);
    t.fillStyle = wrng() < 0.5 ? '#8a6a34' : '#f0dda8';
    t.fillRect(x, y, 3, 3);
  }
  t.globalAlpha = 1;

  // dark map border
  t.strokeStyle = 'rgba(20,26,32,.55)';
  t.lineWidth = 90;
  t.strokeRect(-45, -45, WORLD + 90, WORLD + 90);
}
